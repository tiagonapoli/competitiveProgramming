#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

ll val[1000];
ll maxi = 0;

void pre() {
	val[0] = 0;
	for(int i=0;val[i] < 1LL << 60; i++) {
		val[i+1] = 4LL*val[i] + 1LL;
		maxi = i+1;
	}
}

ll qtd(ll x) {
	if(x >= maxi) return val[maxi];
	return val[x];
}

ll sol(ll n, ll k) {

	bool res = 1;
	k--;
	ll maxop = qtd(n-1);


	ll nextValid = 3;
	ll livre = 0;
	prin(maxop);
	n--;
	while(n > 0 && k >= 0) {
		
		if(maxop >= k) {
			return n;
		}

		n--;
		k -= nextValid;
		livre = nextValid * 4;; 
		nextValid = (nextValid+1)*2 - 1LL;
		livre -= nextValid;


		prin(k);
		prin(n);
		prin(nextValid);
		prin(livre);
		prin(livre * qtd(n));
		maxop += livre * qtd(n);
		prin(maxop);
		separa();
	}

	if(k >= 0 and maxop >= k) return n;
	return -1LL;
}

int main () {
	
	pre();
	int t;
	ll n,k;

	cin >> t;

	while(t--) {

		cin >> n >> k;
		ll aux = sol(n,k);
		if(aux < 0) {
			cout << "NO" << endl;
		} else cout << "YES " << aux << endl;

	}



	return 0;

}



