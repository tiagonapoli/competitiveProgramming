#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 300100

typedef pair<pair<ll, int>, int> node;
typedef pair<pii, int> edge;

set<node> sdist;
int n,m;
vector<edge> adj[N];
vector<int> res;
ll d[N];

int dijkstra() {

	for(int i=0;i<=n;i++) d[i] = -1LL;

	sdist.insert({{0,1}, -1});
	d[1] = 0;
	while(!sdist.empty()) {
		node x = *sdist.begin();
		sdist.erase(sdist.begin());
		if(x.se != -1) res.pb(x.se);
		prin(x.fi.fi);
		prin(x.fi.se);
		prin(x.se);
		separa();
		for(edge u : adj[x.fi.se]) {
			ll aux = x.fi.fi + u.fi.se;
			if(d[u.fi.fi] > aux or d[u.fi.fi] == -1LL) {
				auto it = sdist.lower_bound({{d[u.fi.fi], u.fi.fi}, -1});
				if(d[u.fi.fi] > aux) sdist.erase(it);
				sdist.insert({{aux, u.fi.fi}, u.se});
				d[u.fi.fi] = aux;
			}
		}
	
	}

}

int main () {
	int k;
	
	scanf("%d %d %d", &n, &m, &k);

	int a,b,w;
	fr(i,1,m+1) {
		scanf("%d %d %d", &a, &b, &w);
		adj[a].pb({{b,w},i});
		adj[b].pb({{a,w},i});
	}

	dijkstra();
	
	cout << min((int)res.size(), k) << endl;
	fr(i,0,min((int)res.size(),k)) {
		printf("%d ", res[i]);
	}


	return 0;

}



