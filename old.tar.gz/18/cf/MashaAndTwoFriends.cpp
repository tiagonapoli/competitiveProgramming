#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

pll qtd(pll lo, pll hi) {
	ll p,b;
	b = p = (hi.se - lo.se + 1) * (hi.fi - lo.fi + 1)/2;
	if((hi.se - lo.se + 1) % 2 == 1 and (hi.fi - lo.fi + 1) % 2 == 1) {
		if((lo.fi + lo.se) % 2 == 1) {
			p++;
		} else {
			b++;
		}
	}
	return {b,p};
}

pll inter1(ll lo1, ll hi1, ll lo2, ll hi2) {
	if(lo1 > lo2) {
		swap(lo1,lo2);
		swap(hi1,hi2);
	}
	if(hi1 < lo2) return {-1LL, -1LL};
	pll r;
	r.fi = lo2;
	r.se = min(hi1, hi2);
	return r;
}

pair<pll,pll> inter(pll lo1, pll hi1, pll lo2, pll hi2) {
	pll lo,hi, aux;
	aux = inter1(lo1.fi, hi1.fi, lo2.fi, hi2.fi);
	lo.fi = aux.fi;
	hi.fi = aux.se;

	aux = inter1(lo1.se, hi1.se, lo2.se, hi2.se);
	lo.se = aux.fi;
	hi.se = aux.se;
	return {lo,hi};
}

void read(pll &a, pll &b) {
	cin >> a.fi >> a.se >> b.fi >> b.se;
}

pll print(pll x) {
	printf("%lld %lld\n", x.fi, x.se);
}

int main () {

	int n,m;
	int t;

	cin >> t;

	pll lo1,hi1, lo2,hi2;

	while(t--) {
		cin >> n >> m;
		
		read(lo1, hi1);
		read(lo2, hi2);
		
		auto aux = inter(lo1, hi1, lo2, hi2);
		
		pll r = qtd({1LL,1LL}, {m,n});
		if(debug) print(r);
		
		r.fi += qtd(lo1, hi1).se;
		r.se -= qtd(lo1, hi1).se;
		if(debug) print(qtd(lo1,hi1));

		r.fi -= qtd(lo2, hi2).fi;
		r.se += qtd(lo2, hi2).fi;
		if(debug) print(qtd(lo2,hi2));

		if(debug) {
			printf("aux: ");
			print(aux.fi);
			print(aux.se);
		}

		if(aux.fi.fi != -1 and aux.fi.se != -1 and aux.se.fi != -1 and aux.se.se != -1) {
			r.fi -= qtd(aux.fi,aux.se).se;
			r.se += qtd(aux.fi,aux.se).se;
			if(debug) print(qtd(aux.fi,aux.se));
		}


		print(r);


	}

	return 0;

}



