#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 400100

ll inf = 1000000000000000LL;
ll n,k;
ll val[N][2];
pll dp[N][2];

pll lastCnt(ll a, ll b, ll antA, ll antB, bool initA) {

	prin(a);
	prin(antA);
	prin(b);
	prin(antB);
	prin(initA);


	pll ret = {inf,inf};
	if(initA and antA < k and a > 0) {
		ll box = min(a,b);
		if(box == 0) {
			ret.fi = a + antA;
			ret.se = 0;
		} else if(a > box) {
			ret.fi = max(0LL, a - (k-antA + (box-1)*k));
			ret.se = (ret.fi == 0) ? 1 : 0;
		} else if(b > box) {
			ret.fi = 0;
			ret.se = max(1LL, b - (box-1)*k);
		}

	} else if(!initA and antB < k and b > 0) {
		ll box = min(a, b-1);
		if(box == 0 and a == 0) {
			ret.fi = 0;
			ret.se = antB + b;
		} else if(box == 0 and b-1 == 0) {
			ret.fi = a;
			ret.se = 0;
		} else if (a > box) {
			ret.fi = max(0LL, a - (box * k));
			ret.se = (ret.fi == 0) ? 1 : 0;
		} else if(b > box) {
			ret.se = max(1LL, b - (k - antB + (box-1) * k));
			ret.fi = 0;
		}	
	}

	prin(ret.fi);
	prin(ret.se);
	if(ret.fi > k or ret.se > k) ret = {inf,inf};
	prin(ret.fi);
	prin(ret.se);
	separa();
	return ret;
}

pll sol() {
	
	dp[0][0] = dp[0][1] = {0,0};
	for(int i=1;i<=n;i++) {

		prin(i);
		
		dp[i][0] = dp[i][1] = {inf,inf};
		pll r1,r2;
		for(int ant=0;ant<2;ant++) {
			if(dp[i-1][ant].fi == inf) continue;
			r1 = lastCnt(val[i][0], val[i][1], dp[i-1][ant].fi, dp[i-1][ant].se, 1);
			r2 = lastCnt(val[i][0], val[i][1], dp[i-1][ant].fi, dp[i-1][ant].se, 0);
			dp[i][0] = min(dp[i][0], min(r1,r2));
		}
		
		prin(dp[i][0].fi);
		prin(dp[i][0].se);
		
		for(int ant=0;ant<2;ant++) {
			if(dp[i-1][ant].fi == inf) continue;
			r1 = lastCnt(val[i][1], val[i][0], dp[i-1][ant].se, dp[i-1][ant].fi, 1);
			r2 = lastCnt(val[i][1], val[i][0], dp[i-1][ant].se, dp[i-1][ant].fi, 0);
			dp[i][1] = min(dp[i][1], min(r1,r2));
		}
		swap(dp[i][1].fi, dp[i][1].se);
		prin(dp[i][1].fi);
		prin(dp[i][1].se);
		separa();
	}

	return min(dp[n][0], dp[n][1]);
	

}

int main () {

	scanf("%lld %lld", &n, &k);

	fr(i,1,n+1) {
		scanf("%lld", &val[i][0]);
	}
	fr(i,1,n+1) {
		scanf("%lld", &val[i][1]);
	}
	
	pll res = sol();

	printf("%s\n", res.fi == inf ? "NO" : "YES");

	return 0;

}



