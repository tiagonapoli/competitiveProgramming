#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 300100

ll bit[N];

int upd(int id, ll x) {
	while(id < N) {
		bit[id] += x;
		id += id & (-id);
	}
}

ll query(int id) {
	ll res = 0;
	while(id > 0) {
		res += bit[id];
		id -= id & (-id);
	}
	return res;
}

void addRange(int a, int b, ll x) {
	upd(a,x);
	upd(b+1,-x);
}

void undoAddRange(int a, int b, ll x) {
	upd(a,-x);
	upd(b+1,x);
}

int h[N];
bool vis[N];
ll val[N];
vector<pii> updates[N];
vector<int> adj[N];
int n;
int dfs(int vtx) {
	vis[vtx] = 1;
	
	for(auto x : updates[vtx]) {
		addRange(h[vtx], min(h[vtx] + x.se, N-10), x.fi);
	}
	val[vtx] = query(h[vtx]);

	for(int u : adj[vtx]) {
		if(vis[u] == 0) {
			h[u] = h[vtx] + 1;
			dfs(u);
		}
	}

	for(auto x : updates[vtx]) {
		undoAddRange(h[vtx], min(h[vtx] + x.se, N-10), x.fi);
	}
}

int main () {
	
	scanf("%d", &n);

	int x,y;
	for(int i=0;i<n-1;i++) {
		scanf("%d %d", &x, &y);
		adj[x].pb(y);
		adj[y].pb(x);
	}
	
	int m;

	scanf("%d", &m);
	int vtx;
	fr(i,0,m) {
		scanf("%d %d %d", &vtx, &x, &y);
		updates[vtx].pb({y,x});
	}

	h[1] = 1;
	dfs(1);

	fr(i,1,n+1) {
		printf("%lld ", val[i]);
	}
	

	return 0;

}



