#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

stack<int> tv;
vector<pair<pii, int> > ev;
ll x,y;
ll res = 0;
pii v[N];

void sol() {
	for(pair<pii, int> j : ev) {
		int id = j.se;

		prin(j.fi.fi);
		prin(j.fi.se);
		prin(j.se);
		prin(tv.size());

		if(j.fi.se == 1) {
			tv.push(j.fi.fi);
		} else {
				
			if(!tv.empty() && (ll)(v[id].fi - tv.top()) * y <= x) {
				ll ant = (ll)tv.top();
				tv.pop();
				res += (v[id].se - ant) * y;
				prin(v[id].se);
				prin(ant);
			} else {
				while(!tv.empty()) tv.pop();
				res += x + (v[id].se - v[id].fi) * y; 
			}
		}
		prin(res);
		separa();
		res %= MOD;
	}

}


int main () {

	int n;
	cin >> n >> x >> y;

	fr(i,0,n) {
		scanf("%d %d", &v[i].fi, &v[i].se);
		ev.pb({{v[i].fi, 0}, i});
		ev.pb({{v[i].se, 1}, i});
	}

	sort(ev.begin(), ev.end());

	sol();
	
	cout << res << endl;

	return 0;

}



