#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100


int main () {

	int t;
	double d;

	cin >> t;

	while(t--) {

		cin >> d;
		
		double delta = d*d - 4*d;
		if(delta < 0.0) {
			printf("N\n");
			continue;
		}

		printf("Y %.9lf %.9lf\n", (d + sqrt(delta))/2.0, (d-sqrt(delta))/2.0);

	}


	return 0;

}



