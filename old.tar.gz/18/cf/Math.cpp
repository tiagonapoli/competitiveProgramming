#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

map<int,int> fact;

int main () {

	int n;

	cin >> n;

	if(n == 1) {
		printf("1 0\n");
		return 0;
	}

	for(int i=2;i<=n;i++) {
		while(n % i == 0) {
			n /= i;
			fact[i]++;
		}
	}

	int res = 0;
	int aux = 1;
	int maxi = 0;
	
	set<int> s;
	for(pii x : fact) {
		//prin(x.se);
		aux *= x.fi;
		s.insert(x.se);
		maxi = max(maxi,x.se);
	}

	if(s.size() != 1 or __builtin_popcount(maxi) != 1) res++;
	for(int i=0;i<30;i++) {
		if((1 << i) >= maxi) {
			maxi = 1 << i;
			break;
		}
	}
	
	while(maxi > 1) {
		res++;
		maxi /= 2;
	}

	printf("%d %d\n", aux, res);



	return 0;

}



