#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

ll pot2[N];
int s1[N];

void pre() {

	pot2[0] = 1;
	for(int i=1;i<N;i++) {
		pot2[i] = 2 * pot2[i-1];
		pot2[i] %= MOD;
	}
}

ll solve(int a, int b) {
	int x1,x0;
	
	x1 = s1[b] - s1[a-1];
	x0 = (b-a+1) - x1;
	ll res = ((pot2[x1]-1) + MOD) % MOD;	
	res += ((pot2[x1]-1 + MOD) % MOD) * ((pot2[x0]-1 + MOD) % MOD);
	res %= MOD;
	return res;
}

int v[N];
int main () {
	
	int n,q;

	pre();
	cin >> n >> q;

	string s;

	cin >> s;

	s.insert(0, "x");


	s1[0] = 0;
	for(int i=1;i<=n;i++) {
		s1[i] = s1[i-1] + (s[i] == '1');
	}

	int a,b;
	for(int i=0;i<q;i++) {
		scanf("%d %d", &a, &b);
		printf("%lld\n", solve(a,b));
	}

	return 0;

}



