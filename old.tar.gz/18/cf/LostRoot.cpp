#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

int n, k;

bool check(int a, int b, int c) {
	string s;
	printf("? %d %d %d\n", a, b, c);
	fflush(stdout);
	cin >> s;
	return s == "Yes";
}

bool ehFolha(int x) {
	int y = x + 1;
	if(y > n) y = x-1;
	for(int i=1;i<=n;i++) {
		if(i == x or i == y) continue;
		if(check(y,x,i) == 1) return 0;
	}
	return 1;
}

vector<int> entre(int a, int b) {
	vector<int> r;
	for(int i=1;i<=n;i++) {
		if(i == a or i == b) continue;
		if(check(a,i,b)) r.pb(i);
	}
	

	if(debug) {
		printf("Entre %d %d: ", a,b);
		for(int i : r) {
			printf("%d ", i);
		}
		separa();
	}

	return r;
}

int go(int x, vector<int> v, int leaf) {
	int h = 0;
	for(int i : v) {
		if(i == x or i == leaf) continue;
		if(check(leaf, i, x)) h++;
	}
	return h;
}

int main () {

	srand(time(NULL));

	cin >> n >> k;
	
	int h = 0;

	int res = 0;
	while(res < n) {
		res += pow(k,h);
		h++;
	}

	prin(h);

	int f1 = 1 + rand() % n;

	while(ehFolha(f1) == 0) {
		f1 = 1 + rand() % n;
	}

	prin(f1);

	int f2 = 1 + rand() % n;
	vector<int> r = entre(f1,f2);


	while(r.size() != 2*h - 1 - 2) {
		f2 = 1 + rand() % n;
		r = entre(f1,f2);
	}

	prin(f2);

	for(int i : r) {
		if(go(i,r,f1) == h-2) {
			printf("! %d\n", i);
			fflush(stdout);
			return 0;
		}
	}


	return 0;

}



