#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

ll go(ll a1, ll an) {
	if(a1 > an) return 0;
	ll n = (an-a1)/2LL + 1LL;
	return n * (a1+an)/2LL;
}

ll sol(int a, int b) {
	
	ll r = 0;

	ll a1,an, b1,bn;
	if(a % 2 == 0) {
		a1 = a;
		b1 = (a+1);
	} else {
		a1 = a+1;
		b1 = a;
	}

	if(b % 2 == 0) {
		an = b;
		bn = (b-1LL);
	} else {
		an = b-1LL;
		bn = b;
	}

	r = go(a1,an);
	r -= go(b1,bn);
	return r;

}

int main () {

	int q;
	
	cin >> q;
	
	int a,b;
	fr(i,0,q) {
		cin >> a >> b;
		cout << sol(a,b) << endl;
	}



	return 0;

}



