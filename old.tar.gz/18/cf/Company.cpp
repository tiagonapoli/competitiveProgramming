#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 300100

int h[N];
pii ptree[N];
int t = 0;
int fiT[N], laT[N];
vector<int> adj[N];
bool vis[N];

int dfs(int u) {
	vis[u] = 1;
	ptree[t] = {h[u], u};
	fiT[u] = laT[u] = t;
	for(int x : adj[u]) {
		if(vis[x] == 0) {
			h[x] = h[u] + 1;
			t++;
			dfs(x);
			t++;
			ptree[t] = {h[u], u};
			laT[u] = t;
		}
	}
}

pii minFi[N][20];
pii maxLa[N][20];
pii minH[N][20];
int n, q;

int build() {
	for(int i=1;i<=n;i++) {
		minFi[i][0] = {fiT[i], i};
		maxLa[i][0] = {laT[i], i};
	}

	for(int i=0;i<=t;i++) {
		minH[i][0] = ptree[i];
	}

	int aux = 0;
	for(int p=1;p<20;p++) {
		for(int i=1;i+(1<<p)-1<=n;i++) {
			aux = i + (1 << (p-1));
			minFi[i][p] = min(minFi[i][p-1], minFi[aux][p-1]);
			maxLa[i][p] = max(maxLa[i][p-1], maxLa[aux][p-1]);
		}

		for(int i=0;i+(1<<p)-1<=t;i++) {
			aux = i + (1 << (p-1));
			minH[i][p] = min(minH[i][p-1], minH[aux][p-1]);
		}
	}
}

pii minf(pii a, pii b) {
	return min(a,b);
}

pii maxf(pii a, pii b) {
	return max(a,b);
}

pii query(pii v[N][20], int a, int b, pii (*f)(pii,pii)) {
	int l = b-a+1;
	pii ret = v[a][0];
	int p = 20;
	while(l > 0) {
		if(l >= (1 << p)) {
			ret = (*f)(ret, v[a][p]);
			a += 1 << p;
			l -= 1 << p;
		}
		p--;
	}
	return ret;
}

pii lca(int l, int r) {
	if (r < l) return {9999999,0};
	pii esq = query(minFi,l,r,minf);
	pii dir = query(maxLa,l,r,maxf);
	pii ret = query(minH, esq.fi, dir.fi, minf);
	if(debug) printf("LCA %d->%d esq %d %d  dir %d %d  ret %d %d\n", l,r,esq.fi,esq.se,dir.fi,dir.se,ret.fi,ret.se);

	return ret;
}

pii lca(int l, int r, int remov) {
	if(debug) printf("%d->%d SEM %d\n", l,r,remov);
	pii lca1 = lca(l,remov-1);
	pii lca2 = lca(remov+1,r);
	separa();
	if(lca1.se == 0) {
		return lca2;
	} else if(lca2.se == 0) {
		return lca1;
	} else {
		return query(minH, min(fiT[lca1.se], fiT[lca2.se]), max(laT[lca1.se], laT[lca2.se]), minf);
	}
}

int main () {


	scanf("%d %d", &n, &q);
	int p;
	fr(i,2,n+1) {
		scanf("%d", &p);
		adj[p].pb(i);
		adj[i].pb(p);
	}

	h[1] = 0;
	dfs(1);
	build();

	int l,r;
	pii r1,r2,r3,res;
	fr(i,0,q) {
		scanf("%d %d", &l, &r);
		
		pii esq = query(minFi,l,r,minf);
		pii dir = query(maxLa,l,r,maxf);
		r1 = lca(l,r);
		r2 = lca(l,r,esq.se);
		r3 = lca(l,r,dir.se);
	

		if(r1.fi == r2.fi and r1.fi == r3.fi) {
			res = {l,r1.fi};
		} else if(r2.fi > r3.fi) {
			res = {esq.se,r2.fi};
		} else {
			res = {dir.se,r3.fi};
		}

		printf("%d %d\n", res.fi, res.se);
		
	}

	return 0;

}



