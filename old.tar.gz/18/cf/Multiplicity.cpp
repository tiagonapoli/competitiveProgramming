#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

ll qtd[N*10];
int v[N];
vector<int> d;

int main () {

	int n;

	qtd[0] = 1;
	scanf("%d", &n);

	fr(i,0,n) {
		scanf("%d", &v[i]);
	}

	ll res = 0;
	ll aux = 0;
	fr(i,0,n) {
		
		prin(i);

		d.clear();
		for(int j=1;j*j<=v[i];j++) {
			if(v[i] % j == 0) {
				d.pb(j);
				if(v[i]/j != j) d.pb(v[i]/j);
			}
		}

		for(int x : d) {
			res += qtd[x-1];
			res %= MOD;
		}

		for(int j=d.size()-1;j >= 0; j--) {
			qtd[d[j]] += qtd[d[j]-1];
			qtd[d[j]] %= MOD;
		}

		separa();
	}

	cout << res << endl;
	


	return 0;

}



