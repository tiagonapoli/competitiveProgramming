#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100


ll linha(ll a, ll b) {
	if(a > b) return 0;
	return (b-a + 1) * (b - a);
}

ll qtd(ll x) {
	if(x <= 0) return 0;
	return x * (x-1);
}

ll todas(ll n, ll m) {
		
	return max(0LL, (n*m-1) * (n * m - 2));
}

int main () {

	ll n,m,x,y;

	int t;

	cin >> t;

	while(t--) {
		cin >> n >> m >> x >> y;
	
		ll ataca = linha(1,x-1) + linha(x+1, n) +  
				   linha(1,y-1) + linha(y+1, m) +  
				   qtd(min(x-1,y-1)) + qtd(min(x-1,m-y)) + 							  qtd(min(n-x,y-1)) + qtd(min(n-x,m-y));
		prin(ataca);

		ll aux = 0;
		for(ll i=1;i<=n;i++) {
			for(ll j=1;j<=m;j++) {
				ll now = 0;
				if(i != x) now += m-1;
				prin(now);
				if(j != y) now += n-1;
				prin(now);
				if(i-j != x-y) now += min(i-1,j-1) + min(n-i,m-j);
				prin(now);
				if(i+j != x+y) now += min(i-1,m-j) + min(n-i,j-1);
				prin(now);
				aux += now;
				//printf("%lld,%lld = %lld\n\n", i,j,now);
			}
		}
		prin(aux);
		cout << todas(n,m) - ataca - aux << endl;
	}
	

	



	return 0;

}



