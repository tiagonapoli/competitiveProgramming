#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 1010

ll pascal[2*N][2*N], pot2[N];
int v[N];
int l[N], r[N];
int n;

void pre() {
	pascal[0][0] = 1;
	for(int i=1;i<2*N;i++) {
		pascal[i][0] = pascal[i][i] = 1;
		for(int j=1;j<i;j++) {
			pascal[i][j] = pascal[i-1][j] + pascal[i-1][j-1];
			pascal[i][j] %= MOD;
		}
	}

	pot2[0] = 1;
	fr(i,1,N) {
		pot2[i] = (pot2[i-1] * 2) % MOD;
	}
}

void pre_test() {
	for(int i=0;i<n;i++) {
		l[i] = r[i] = 0;
		for(int j=0;j<i;j++) if(v[j] <= v[i]) l[i]++;
		for(int j=i+1;j<n;j++) if(v[j] >= v[i]) r[i]++; 
	}	
}

int equal_range(int i) {
	int x = v[i];
	while(i < n and v[i] == x) {
		i++;
	}
	return i;
}

ll choose(int a, int b) {
	if(a < 0 or b < 0) return 0;
	return pascal[a][b];
}

int main () {
	
	int t;
	pre();

	cin >> t;

	while(t--) {
		
		cin >> n;
		fr(i,0,n) {
			cin >> v[i];
		}
		sort(v,v+n);
		pre_test();

		int i=0;
		ll res = pot2[n-1];
		prin(res);
		while(i < n) {
			int j = equal_range(i);
			for(int a=i;a<j;a++) {
				for(int b=a+1;b<j;b++) {
				//	for(int k=0;k<min(l[a],r[b]);k++) {
				//		res += choose(l[a], k) * choose(r[b], k);
				//	}
					res += choose(l[a] + r[b], min(l[a],r[b]));
					res %= MOD;
					prin(choose(l[a]+r[b], min(l[a],r[b])));
				}
			}
			i = j;
		}


		cout << res << endl;

	}
	


	return 0;

}



