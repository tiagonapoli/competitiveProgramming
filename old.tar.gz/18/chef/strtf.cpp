#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

int v[N];
int n, q;

int go(int e) {
	if(e % 2 == 0) return 0;
	return v[n];
}

int main () {


	scanf("%d %d", &n, &q);

	for(int i=1;i<=n;i++) {
		scanf("%d", &v[i]);
	}

	int k,x;
	for(int i=0;i<q;i++) {
		scanf("%d %d", &k, &x);

		if(k == 0 or x == n) {
			printf("%d\n", v[x]);
			continue;
		}

		int a,b, ult;
		a = x;
		b = min(x+k, n);
		ult = max(0, x + k - n);
		

		prin(a);
		prin(v[a]);
		prin(b);
		prin(v[b]);
		
		printf("%d\n", v[b] xor v[a] xor go(ult));
	}

	return 0;

}



