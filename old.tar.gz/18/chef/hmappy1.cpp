#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 200100

list<pii> lista;
multiset<int> v;
string s;
int n,q,k;

pii conta(int &i) {
	char now = s[i];
	int cnt =0 ;
	while(i < n && s[i] == now) {
		cnt++;
		i++;
	}
	return make_pair(now - '0', cnt);
}

void del() {
	if(lista.back().fi == 1) {
		v.erase(v.find(lista.back().se));
		if(lista.back().se-1 != 0) {
			v.insert(lista.back().se - 1);
		}
	}
}

void add() {
	if(lista.back().fi == 0) return;
	if(lista.front().fi == 1) {
		v.erase(v.find(lista.front().se));
		v.insert(lista.front().se+1);
	} else {
		v.insert(1);
	}
}

void shift() {
	
	if(lista.size() <= 1) return;
	int fim = lista.back().fi;

	add();
	del();

	lista.back().se--;
	if(lista.back().se == 0) {
		lista.pop_back();
	}


	if(!lista.empty() && lista.front().fi == fim) {
		lista.front().se++;
	} else {
		lista.push_front({fim,1});
	}
}

void print() {
	for(pii x : lista) {
		printf("%d/%d ", x.fi, x.se);
	}
}

int main () {


	scanf("%d %d %d", &n, &q, &k);

	char c;
	fr(i,0,n) {
		scanf(" %c", &c);
		s.pb(c);
	}

	int a = 0;	
	pii aux;

	while(a < n) {
		aux = conta(a);
		lista.pb(aux);
		if(aux.fi == 1) {
			v.insert(aux.se);
		}
	}

//	print();
	char op;
	fr(i,0,q) {
		scanf(" %c", &op);
		if(op == '!') {
			shift();
//			print();
		} else {
			if(v.size() == 0) {
				printf("0\n");
			} else printf("%d\n", min(k,(*(--v.end()))));
		}
	}
	
	return 0;
}



