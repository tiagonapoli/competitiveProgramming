#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

int v[N];

int main () {

	int t;

	v[1] = 1;
	for(int i=2;i<26;i++) {
		v[i] = v[i-1] * 2 + (i % 2 ? 1 : -1);
	}

	cin >>t;

	int n;
	while(t--) {
		cin >> n;
		printf("%d %d ", v[n], 1<<n);
	}
	cout << endl;


	return 0;

}



