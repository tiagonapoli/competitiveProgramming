#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100


int v[N];
int chega[N];

int main () {
	
	int t,n;

	scanf("%d", &t);
	while(t--) {
		bool res = 0;
		cin >> n;
		for(int i=1;i<=n;i++) {
			chega[i] = -1;
			cin >> v[i];
		}
		
		int x;
		for(int i=1;i<=n;i++) {
			if(chega[v[v[i]]] == -1) chega[v[v[i]]] = v[i];
			else if(chega[v[v[i]]] != v[i]) res= 1;
		}

		printf("%s\n", res ? "Truly Happy" : "Poor Chef");

	}


	return 0;

}



