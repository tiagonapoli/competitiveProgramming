#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 300100
const int BIT = 32;

int st[33*N], um[33*N], zero[33*N];
int NODE = 0;

int newnode(int val, int z, int u, int x=0) {
	int p = ++NODE;
	st[p] = val;
	um[p] = u;
	zero[p] = z;
	return p;
}

void print(int p, int bit=BIT) {
	if(p == 0) return;
	if(bit == 0) printf("[%d]: [%d]\n", p, st[p]);
	if(bit == 0) return;
	printf("[%d] %d: %d %d\n", p, st[p], zero[p], um[p]);
	print(zero[p], bit-1);
	print(um[p], bit-1);
}

int getbit(int x, int bit) {
	if(bit < BIT) return (x & (1 << bit)) != 0;
	return -1;
}

int add(int x, int p, int bit) {
	int aux = getbit(x,bit);
	if(bit == 0) return newnode(aux, 0,0,x);
	if(bit == BIT) aux = -1;
	if(getbit(x, bit-1) == 0) return newnode(aux, add(x,zero[p],bit-1), um[p]); 
	else return newnode(aux, zero[p], add(x,um[p], bit-1));	
}

int trieXor(int x, int p, int bit, bool mini) {
	int ret = 0;
	if(bit != BIT) ret = (st[p] ^ getbit(x,bit)) << bit; 
	if(bit == 0) return ret;
	if(getbit(x,bit-1) == 0) {
		if((mini && zero[p] != 0) or (um[p] == 0)) return ret + trieXor(x,zero[p],bit-1,mini);
		else return ret + trieXor(x,um[p],bit-1,mini);
	} else {
		if((mini && um[p] != 0) or (zero[p] == 0)) return ret + trieXor(x,um[p],bit-1,mini);
		else return ret + trieXor(x,zero[p],bit-1,mini);
	}
}

int n,q;
int R, key[N], id[N];
int root[N];
vector<int> adj[N];
bool vis[N];

int dfs(int u, int p) {
	vis[u] = 1;
	root[u] = add(key[u], root[p], BIT);
	for(int v : adj[u]) {
		if(!vis[v]) dfs(v,u);
	}
}

int cnt = 1;
map<int,int> dicio;
int addToDicio(int x) {
	if(dicio.find(x) == dicio.end()) {
		dicio[x] = cnt;
		cnt++;
	}
}

int main () {

	scanf("%d %d", &n, &q);
	scanf("%d %d", &R, &key[1]);
	addToDicio(R);

	int u,v,k;
	fr(i,0,n-1) {
		scanf("%d %d %d", &u, &v, &k);
		addToDicio(u);
		addToDicio(v);
		key[dicio[u]] = k;
		adj[dicio[u]].pb(dicio[v]);
		adj[dicio[v]].pb(dicio[u]);
	}
	
	root[0] = newnode(-1,0,0);
	dfs(1,0);

	/*
	for(int i=0;i<=n;i++) {
		printf("==================== ROOT %d ==============\n", i);
		print(root[i]);
	}
*/

	int t;
	int a,b;
	int last_ans = 0;
	fr(i,0,q) {
		scanf("%d", &t);
		t ^= last_ans;
		if(t == 0) {
			scanf("%d %d %d", &v, &u, &k);
			v ^= last_ans;
			u ^= last_ans;
			k ^= last_ans;
			addToDicio(u);
			key[dicio[u]] = k;
			adj[dicio[u]].pb(dicio[v]);
			adj[dicio[v]].pb(dicio[u]);
			root[dicio[u]] = add(key[dicio[u]], root[dicio[v]], BIT);
		} else {
			scanf("%d %d", &v, &k);
			v ^= last_ans;
			k ^= last_ans;
			a = trieXor(k,root[dicio[v]],BIT,1);
			b = trieXor(k,root[dicio[v]],BIT,0);
			printf("%d %d\n", a,b);

			last_ans = a ^ b;
		}
	}

	return 0;

}



