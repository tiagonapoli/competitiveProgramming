#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100


int main () {

	ll n,k,t;

	cin >> t;

	while(t--) {

		cin >> n >> k;
		
		ll s = k*(k+1)/2;
		ll ini = 1;

		while(s <= n) {
			ini++;
			s += k;
		}
		
		ini--;
		s -= k;
		if(ini == 0) {
			printf("-1\n");
			continue;
		}

		ll falta = n - s;

		ll res = 1;
		for(ll i=0;i<k-falta;i++) {
			res *= ini + i;
			if(debug) printf("[%lld]\n", ini + i);

			res %= MOD;
			res *= ini + i - 1;
			res %= MOD;
		}

		for(ll i=k-falta;i < k;i++) {
			res *= ini + i + 1;
			if(debug) printf("[%lld]\n", ini + i + 1);
			res %= MOD;
			res *= ini + i;
			res %= MOD;
		}

		cout << res << endl;


	}
	return 0;

}



