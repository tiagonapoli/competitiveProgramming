#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

ll n,k;
void special() {
	double res;
	if(n == 1) {
		res = 1.0;
	} else if(n == 2) {
		res = 0.5;
	} else if(n == 3) {
		if(k == 0) {
			res = 1.0/3.0;
		} else if(k == 1) {
			res = 0.5;
		} else if(k >= 2) {
			res = 1.0;
		}
	}
	printf("%lf\n", res);
}

void op1() {
	if(k > 0) {
		if(n % 4 == 0) 
			n = (n/4) * 2;
		else if(n % 4 == 1) 
			n = (n/4) * 2 + 1;
		else 
			n = (n/4) * 2 + 2;
		k--;
	}
}


int main () {

	int t;

	scanf("%d", &t);

	while(t--) {
		scanf("%lld %lld", &n, &k);

		if(k == 0) {
			printf("%lf\n", 1.0/(double)n);
			continue;
		}

		if(n <= 3) {
			special();
			continue;
		}

		op1();

		while(n > 1 and k > 0) {
			n = (n+1)/2;
			k--;
		}
		
		prin(n);
		prin(k);
		printf("%lf\n", 1.0/(double)n);
		separa();
	}

	return 0;

}



