#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;

//codeforces.com/blog/entry/11080
typedef tree<pii,
			 null_type,
			 less<pii>,
			 rb_tree_tag,
			 tree_order_statistics_node_update> ordered_set;


int t, n, k;
pii v[N];
vector<pair<int, pii> > ev;

int sweep() {
	ordered_set line;
	int x, op;
	int id;
	int res = 0;
	for(pair<int, pii> j : ev) {
		x = j.fi;
		op = j.se.fi;
		id = j.se.se;
		if(debug) printf("[%d]: %d %d\n", x, op, id); 
		if(op == 1) {
			line.erase({v[id].se, id});
		} else {
			line.insert({v[id].se, id});
			if(line.size() >= k) { 
				if(debug) printf("%d elementos -> de %d a %d = %d\n", (int) line.size(), v[id].fi, line.find_by_order(line.size() - k)->fi, line.find_by_order(line.size() - k)->fi - v[id].fi); 
				res = max(res, line.find_by_order(line.size() - k)->fi - v[id].fi); 
			}
		}
	}
	return res;
}

int main () {


	scanf("%d", &t);

	while(t--) {

		ev.clear();

		scanf("%d %d", &n, &k);

		for(int i=0;i<n;i++) {
			scanf("%d %d", &v[i].fi, &v[i].se);
			ev.pb({v[i].fi, {-1, i}});
			ev.pb({v[i].se, {1, i}});
		}

		sort(ev.begin(), ev.end());
		
		cout << sweep() << endl;
	}



	return 0;

}



