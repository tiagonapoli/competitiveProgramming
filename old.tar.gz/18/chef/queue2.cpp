#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

ll v[N];

int main () {

	int t;
	
	cin >> t;

	while(t--) {
		
		int n,k;
		ll m,l;

		scanf("%d %lld %d %lld", &n, &m, &k, &l);

		for(int i=0;i<n;i++) {
			scanf("%lld", &v[i]);
		}

		v[n] = k;
		sort(v,v+n+1);
		

		int id = -1;
		ll res = 999999999999999LL;
		for(int i=0;i<=n;i++) {
			prin(v[i]);
			prin(m*l + i*l - v[i]);
			separa();
			if(res >= max(0LL, (m+i+1)*l - v[i])) {
				res =  max(0LL, (m+i+1)*l - v[i]);
				id = v[i];
			}
		}

		printf("%lld\n", res);
	}

	return 0;

}



