#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100
#define M ((L+R)/2)

int l[15*N], r[15*N], root[N], st[15*N], NODES = 0;
int n,m;

int newleaf(int val) {
	int p = ++NODES;
	l[p] = r[p] = 0; //NULL
	st[p] = val;
	return p;
}

int newparent(int lef, int rig) {
	int p = ++NODES;
	l[p] = lef;
	r[p] = rig;
	st[p] = st[lef] + st[rig];
	return p;
}

int upd(int i, int x, int p, int L=1, int R=n) {
	if(L == R) return newleaf(x);
	if(i <= M) return newparent(upd(i,x,l[p],L,M), r[p]);
	else return newparent(l[p], upd(i,x,r[p],M+1,R));
}

void print(int p, int L=1, int R=n) {
	printf("%d->%d %d [%d]\n", L, R, st[p], p);
	if(L == R) return;
	print(l[p], L, M);
	print(r[p], M+1,R);
}

int build(int L=1, int R=n) {
	if(L == R) return newleaf(0);
	return newparent(build(L,M), build(M+1,R));
}

int nodeval(int p1, int p2) {
	return st[p2] - st[p1];
}

int query(int k, int p1, int p2, int L=1, int R=n) {
	int aux = nodeval(l[p1],l[p2]);
	if(L == R) return R;
	if(k > aux) {
		return query(k-aux, r[p1], r[p2], M+1, R);
	} else if(k <= aux) {
		return query(k, l[p1], l[p2], L, M);
	}
}

int v[N], sorted[N];
map<int,int> dict;
map<int,int> invdict;

int main () {


	scanf("%d %d", &n, &m);

	fr(i,1,n+1) {
		scanf("%d", &v[i]);
		sorted[i] = v[i];
	}

	sort(sorted+1, sorted+n+1);
	fr(i,1,n+1) {
		dict[sorted[i]] = i;
		invdict[i] = sorted[i];
	}

	root[0] = build();
	if(debug) {
		printf("==== ROOT %d ====\n", 0);
		print(root[0]);
		separa();
	}
	fr(i,1,n+1) {
		root[i] = upd(dict[v[i]], 1, root[i-1]);
		if(debug) {
			printf("==== ROOT %d ====\n", i);
			print(root[i]);
			separa();
		}
	}

	int a,b,k;
	fr(i,0,m) {
		scanf("%d %d %d", &a, &b, &k);
		printf("%d\n", invdict[query(k, root[a-1], root[b])]);
	}


	return 0;

}



