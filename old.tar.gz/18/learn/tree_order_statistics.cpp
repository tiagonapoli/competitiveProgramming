#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;

//codeforces.com/blog/entry/11080
typedef tree<int,
			 null_type,
			 less<int>,
			 rb_tree_tag,
			 tree_order_statistics_node_update> ordered_set;

int main () {

	ordered_set s;
	
	s.insert(1);
	s.insert(2);
	s.insert(4);
	s.insert(8);
	s.insert(16);

	printf("1 2 4 8 16\n");
	
	printf("%d-esimo: %d\n", 0, *s.find_by_order(0));
	printf("%d-esimo: %d\n", 2, *s.find_by_order(2));
	printf("%d-esimo: %d\n", 4, *s.find_by_order(4));
	printf("%d-esimo: %s\n", 5, s.find_by_order(5) == s.end() ? "nao encontrado" : "encontrado");

	printf("Ordem [%d]: %d\n", 1, (int)s.order_of_key(1));
	printf("Ordem [%d]: %d\n", 3, (int)s.order_of_key(3));
	printf("Ordem [%d]: %d\n", 7, (int)s.order_of_key(7));
	printf("Ordem [%d]: %d\n", 20, (int)s.order_of_key(20));


	return 0;

}



