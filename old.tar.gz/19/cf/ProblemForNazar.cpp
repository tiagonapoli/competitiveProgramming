#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define FOR(i,a,b) for(int i=(a);i<(b);i++)
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>

bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define prinpar(a) if(debug) printf("%d/%d\n", (a.fi), (a.se))
#define separa() if(debug) cout << endl

const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

ll acum[2];

ll mul(ll a, ll b) { return (a*b) % MOD; }
ll sum(ll a, ll b) { return (a+b) % MOD; }
ll sub(ll a, ll b) { return ((a % MOD) - (b % MOD) + MOD) % MOD; }

ll calc(ll a, ll b, bool r) {
	a -= acum[!r];
	b -= acum[!r];
	ll fi = (2*a - (ll) r + MOD) % MOD;
	ll la = (2*b - (ll) r + MOD) % MOD;
	return mul(mul(sum(fi,la), sub(b+1,a)), 500000004LL);
}

ll solve(ll a, ll b, ll pot, bool r) {
	if(a > b) return 0;
	ll i = acum[0] + acum[1] + 1;
	ll j = i + pot - 1;
	//if(debug) printf("%lld->%lld\n", a,b);

	if(i <= a && a <= j) {
		if(b <= j) {
			ll res = calc(a , b, r);
			acum[r] += pot;
			return res;
		} else {
			ll res = calc(a, j, r);
			acum[r] += pot;
			return (res + solve(j+1, b, pot * 2LL, !r)) % MOD;
		}
	}

	acum[r] += pot;
	return solve(a,b,pot*2LL, !r);
}


int main () {
	
	ll l,r;

	cin >> l >> r;

	cout << solve(l, r, 1, 1) << endl;
	return 0;

}



