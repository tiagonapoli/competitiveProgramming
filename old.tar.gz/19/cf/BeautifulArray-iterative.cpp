#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 300100

ll dp[N][5];
ll a[N];
ll inf = 1e17;
// states:
// 0: nao abriu
// 1: o externo foi aberto agora ou anteriormente. O interno nao foi aberto mas sera
// 2: O externo e o interno foram abertos agora ou anteriormente
// 3: O externo foi aberto agora ou anteriormente e o interno foi fechado anteriormente
// 4: o externo e o interno fechararam anteriormente

int main () {

	int n;
	ll x;

	cin >> n >> x;

	for(int i=1;i<=n;i++) cin >> a[i];
	for(int i=0;i<=n+1;i++) {
		dp[i][0] = dp[i][1] = dp[i][2] = dp[i][3] = dp[i][4] = -inf;
	}

	dp[0][0] = 0;
	dp[0][4] = 0;
	for(int i=1;i<=n;i++) {
		dp[i][0] = 0;
		dp[i][1] = a[i] + max({ dp[i-1][1], dp[i-1][0] });
		dp[i][2] = x * a[i] + max({ dp[i-1][0], dp[i-1][1], dp[i-1][2] });
		dp[i][3] = a[i] + max({ dp[i-1][0], dp[i-1][2], dp[i-1][3] });
		dp[i][4] = max({ dp[i-1][0], dp[i-1][2], dp[i-1][3], dp[i-1][4], dp[i][3], dp[i][2]});
	}

	cout << dp[n][4] << endl;

	return 0;

}



