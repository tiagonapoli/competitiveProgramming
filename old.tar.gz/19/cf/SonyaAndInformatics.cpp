#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define FOR(i,a,b) for(int i=(a);i<(b);i++)
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>

bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define prinpar(a) if(debug) printf("%d/%d\n", (a.fi), (a.se))
#define separa() if(debug) cout << endl

const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 110

ll modmul(ll a, ll b) { return (a * b) % MOD; }
ll modsum(ll a, ll b) { return ((a % MOD) + (b % MOD)) % MOD; }
ll modsub(ll a, ll b) { return (((a % MOD) + (b % MOD)) + MOD) % MOD; }
ll div2(ll a) { return (a * 500000004LL) % MOD; }

template <typename T> struct matrix {
	static const int MAXDIM = 110;

	int n,m;
	T mat[matrix::MAXDIM][matrix::MAXDIM];

	matrix(int n, int m) : n(n), m(m) { assert(n < MAXDIM && m < MAXDIM); }
	matrix() : n(0), m(0) {}
	
	static void writeIdent(matrix &I) {
		assert(I.n == I.m);
		FOR(i,0,I.n) FOR(j,0,I.m) {
			I.mat[i][j] = 0;
			if(i == j) I.mat[i][j] = 1;
		}
	}

	static matrix mul(matrix &a, matrix &b, matrix &r) {
		assert(a.m == b.n);
		r.n = a.n; r.m = b.m;
		FOR(i,0,a.n) FOR(j,0,b.m) {
			r.mat[i][j] = 0;
			FOR(k,0,a.m) 
				r.mat[i][j] = modsum(r.mat[i][j], modmul(a.mat[i][k], b.mat[k][j]));
		}
		return r;
	}
	
	static matrix pow(matrix &b, ll e, matrix &raux) {
		assert(b.n == b.m);
		matrix res(b.n, b.m);
		matrix::writeIdent(res);
		while(e > 0) {
			if(e & 1LL) res.cpy(matrix::mul(res, b, raux));
			e >>= 1;
			b.cpy(matrix::mul(b, b, raux));
		}
		return res;
	}


	void cpy(const matrix &b) {
		this->n = b.n; this->m = b.m;
		FOR(i,0,b.n) FOR(j,0,b.m) this->mat[i][j] = b.mat[i][j];
	}	

	void print() {
		const char s1[] = "%lld ", s2[] = "%d ";
		const char *s = is_same<T, ll>::value ? s1 : s2;
		FOR(i,0,this->n) { 
			FOR(j,0,this->m) 
				printf(s, this->mat[i][j]);
			printf("\n");
		}
		printf("\n");
	}
};

int n;
ll totInv;
int z,u;

ll fastPow(ll b, int e) {
	ll res = 1;
	while(e > 0) {
		if(e & 1) res = modmul(res, b);
		b = modmul(b,b);
		e >>= 1;
	}
	return res;
}

inline ll z0(ll z1) { return z-z1; }
inline ll u1(ll z1) { return u-z1; }
inline ll u0(ll z1) { return z1; }

ll probInv(ll x) { return modmul(totInv, x); } 
ll fa(ll z1) { return probInv(modmul(z1, u0(z1))); }
ll fb(ll z1) { 
	return 	probInv( 
		   	modsum( modmul(u1(z1), z1), 
			modsum( modmul(u0(z1), z0(z1)),
			modsum( div2(modmul(z,z-1)), div2(modmul(u,u-1))))));
}
ll fc(ll z1) { return probInv(modmul(z0(z1), u1(z1))); }

ll calc(int k, int z1) {
	int sz = min(z, u) + 1;
	matrix<ll> b(sz,sz);
	FOR(i,0,sz) {
		if(i-1 >= 0) b.mat[i][i-1] = fa(i);
		b.mat[i][i] = fb(i);
		if(i+1 < sz) b.mat[i][i+1] = fc(i);
	}

	matrix<ll> aux, res;
	res = matrix<ll>::pow(b,k,aux);
	return res.mat[z1][0];
}

int main () {

	int k;
	cin >> n >> k;
	totInv = fastPow(div2(modmul(n,n-1)), MOD-2);

	int v[110];
	FOR(i,0,n) {
		cin >> v[i];
		if(v[i] == 0) z++;
		else u++;
	}

	int z1 = 0;
	FOR(i,0,n) {
		if(i >= z) break;
		if(v[i] == 1) z1++;
	}

	cout << calc(k,z1) << endl;
	return 0;
}



