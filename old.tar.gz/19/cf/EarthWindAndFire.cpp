#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define FOR(i,a,b) for(int i=(a);i<(b);i++)
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>

bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define prinpar(a) if(debug) printf("%d/%d\n", (a.fi), (a.se))
#define separa() if(debug) cout << endl

const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 300100

int t[N];
pii r[N];

void fail() {
	printf("NO\n");
	exit(0);
}

inline bool bet(int x, int a, int b) {
	return a <= x && x <= b;
}

int main () {

	int n; scanf("%d", &n);
	int x;

	FOR(i,0,n) {
		scanf("%d", &r[i].fi);
		r[i].se = i+1;
	}
	FOR(i,0,n) scanf("%d", &t[i]);
	sort(r,r+n);
	sort(t,t+n);

	vector<tuple<int,int,int>> res;
	int r1=0, r2=n-1;
	while(r1 <= r2) {
		int v1, v2;
		v1 = r[r1].fi;
		v2 = r[r2].fi;
		if(v1 == t[r1]) { r1++; continue; }
		if(v2 == t[r2]) { r2--; continue; }
		if(!bet(t[r1], v1, v2) or !bet(t[r2], v1, v2)) fail();
		int d = min(t[r1]-v1, v2-t[r2]);
		r[r1].fi += d;
		r[r2].fi -= d;
		res.pb({r[r1].se, r[r2].se, d}); 
	}

	printf("YES\n%d\n", (int) res.size());
	for(auto i : res) {
		printf("%d %d %d\n", get<0>(i), get<1>(i), get<2>(i));
	}

	return 0;

}



