#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 2100

ll v[N];

int main () {

	int n;

	cin >> n;

	for(int i=0;i<n;i++) {
		cin >> v[i];
	}

	ll acum = 0;
	ll add;
	printf("%d\n", n+1);
	for(int i=n-1;i>=0;i--) {
		add = i+1 - (v[i] + acum) % (n+1) + n + 1;
		acum += add;
		printf("1 %d %lld\n", i+1, add);
	}

	printf("2 %d %d\n", n, n+1);

	return 0;

}



