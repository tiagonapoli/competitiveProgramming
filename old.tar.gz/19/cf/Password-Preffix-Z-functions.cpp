#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 1001000

vector<int> prefixF(string s) {
	vector<int> p(s.size() + 1, 0);
	p[0] = 0;
	for(int i=1;i<s.size();i++) {
		int c = p[i-1];
		while(c > 0 and s[c] != s[i]) {
			c = p[c-1];
		}
		p[i] = c;
		if(s[c] == s[i]) {
			p[i]++;
		}
	}
	return p;
}

vector<int> zF(string s) {
	vector<int> z(s.size() + 1, 0);
	z[0] = 0;
	int l,r;
	l = r = 0;
	for(int i=1;i<s.size();i++) {
		if(i <= r) {
			z[i] = min(z[i-l], r-i+1);
		}
		while(z[i] + i < s.size() and s[z[i] + i] == s[z[i]]) {
			z[i]++;
		}
		if(i + z[i] -1 > r) {
			l = i;
			r = i + z[i] - 1;
		}
	}
	return z;
}

int main () {

	string s;
	cin >> s;
	
	vector<int> p = prefixF(s);
	
	int maxP = p[s.size()-1];
	string xs;
	xs = s.substr(0,maxP) + "#" + s.substr(1,max(0, ((int)s.size())-2));

	vector<int> z = zF(xs);
	int res = 0;
	for(int i=maxP;i<xs.size();i++) {
		res = max(res, z[i]);
	}

	while(res < maxP) {
		maxP = p[maxP-1]; 
	}
	res = maxP;
	
	if(res == 0) {
		cout << "Just a legend" << endl; 
	} else {
		cout << s.substr(0, res) << endl;
	}
		


	return 0;

}



