#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

int n,m;
int a[N];
int b[N];

int c1,c2;

int main () {

	cin >> n >> m;

	fr(i,0,n) {
		cin >> a[i];
		c1 += a[i] % 2;
	}

	fr(i,0,m) {
		cin >> b[i];
		c2 += b[i] % 2;
	}

	cout << min(c2,n-c1) + min(m-c2,c1) << endl;

	return 0;

}



