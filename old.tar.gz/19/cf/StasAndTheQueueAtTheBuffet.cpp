#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define FOR(i,a,b) for(int i=(a);i<(b);i++)
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>

bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define prinpar(a) if(debug) printf("%d/%d\n", (a.fi), (a.se))
#define separa() if(debug) cout << endl

const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

pair<int, pii> a[N];

int main () {

	ll n;
	scanf("%lld" ,&n);
	for(int i=0;i<n;i++) {
		scanf("%d %d", &a[i].se.fi, &a[i].se.se);
		a[i].fi = a[i].se.se - a[i].se.fi;
	}

	sort(a, a+n);
	ll res = 0;
	for(ll i=0;i<n;i++) {
		res += (ll)a[i].se.fi * i + (ll)a[i].se.se * (n-i-1);
	}

	printf("%lld\n", res);
	


	return 0;

}



