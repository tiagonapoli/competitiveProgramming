#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define FOR(i,a,b) for(int i=(a);i<(b);i++)
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>

bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define prinpar(a) if(debug) printf("%d/%d\n", (a.fi), (a.se))
#define separa() if(debug) cout << endl

const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 1000100

pii v[4*N];
int lazy[4*N];
int n;
char saux[N];

void prop(int id, int l, int r) {
	if(lazy[id] == 0) return;
	int t = lazy[id];
	lazy[id] = 0;
	v[id].fi += t;
	v[id].se += t;
	if(l == r) return;
	lazy[id*2] += t;
	lazy[id*2+1] += t;
}

pii query(int a, int b, int id=1, int l=1, int r=n) {
	prop(id,l,r);
	if(b < l || a > r) return {2*N,-2*N};
	if(a <= l && r <= b) return v[id];
	int m = (l+r)/2;
	pii esq = query(a,b,id*2,l,m);
	pii dir = query(a,b,id*2+1,m+1,r);
	return {min(esq.fi, dir.fi), max(esq.se, dir.se)};  
}

void upd(int a, int b, int val, int id=1, int l=1, int r=n) {
	prop(id,l,r);
	if(a > r || b < l) return;
	if(a <= l && r <= b) {
		lazy[id] += val;
		prop(id,l,r);
		return;
	}

	int m = (l+r)/2;
	upd(a,b,val,id*2,l,m);
	upd(a,b,val,id*2+1,m+1,r);
	v[id].fi = min(v[id*2].fi, v[id*2+1].fi);
	v[id].se = max(v[id*2].se, v[id*2+1].se);
}


void print() {
	for(int i=1;i<=n;i++) {
		pii a = query(i,i);
		printf("%d/%d ", a.fi, a.se);
	}
	printf("\n");
}

map<char, int> dicio;
int main () {

	dicio['x'] = 0;
	dicio['('] = 1;
	dicio[')'] = -1;

	scanf("%d", &n);
	string s;
	cin >> s;

	for(int i=0;i<s.size();i++) {
		if(s[i] >= 'a' && s[i] <= 'z') s[i] = 'x';
	}

	for(int i=0;i<=s.size();i++) {
		saux[i] = 'x';
	}

	int pos = 1;
	int sum = 0;
	for(int i=0;i<s.size();i++) {
		if(s[i] == 'L') {
			if(pos > 1) pos--;
		} else if(s[i] == 'R') {
			pos++;
		} else {
			int diff = dicio[s[i]] - dicio[saux[pos]];
//			printf("diff %d - [%c] [%c] [%d]\n", diff, s[i], saux[pos], pos);
			sum += diff;
			upd(pos, n, diff);
			saux[pos] = s[i];
		}


		pii res = query(1,n);
//		printf("[%c] - %d - %d/%d\n", s[i], sum, res.fi, res.se);
//		separa();
		if(sum != 0 || res.fi < 0) {
			printf("-1 ");
		} else printf("%d ", res.se); 
	}

	return 0;

}



