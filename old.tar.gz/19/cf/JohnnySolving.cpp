#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define FOR(i,a,b) for(int i =a;i<b;i++)
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 300100

int h[N], f[N];
vector<int> getFather(int x, int to) {
	vector<int> r;
	while(x != to) {
		r.pb(x);
		x = f[x];
	}
	r.pb(to);
	return r;
}

bool vis[N];
vector<int> adj[N], leaf;
void dfs(int u) {
	vis[u] = 1;
	int k = 0;
	for(int v : adj[u]) {
		if(vis[v]) continue;
		k++;
		f[v] = u;
		h[v] = h[u] + 1;
		dfs(v);
	}
	if(!k) leaf.pb(u);
}

int main () {

	int n,m,k;

	scanf("%d %d %d", &n, &m, &k);

	int a,b;
	FOR(i,0,m) {
		scanf("%d %d", &a, &b);
		adj[a].pb(b);
		adj[b].pb(a);
	}

	f[1] = 0;
	h[1] = 1;
	dfs(1);

	FOR(i,1,n+1) {
		if(h[i] >= (n+k-1)/k) {
			vector<int> r = getFather(i, 1);
			printf("PATH\n%d\n", (int)r.size());
			for(int x : r) printf("%d ", x);
			printf("\n");
			exit(0);
		}
	}

	vector< vector<int>> c;
	c.resize(k);

	printf("CYCLES\n");
	for(int i=0;i<k;i++) {
		int v = leaf[i];
		int a=-1,b=-1;
		for(int j=0;j<3;j++) {
			if(adj[v][j] == f[v]) continue;
			if(a != -1) b = adj[v][j];
			else a = adj[v][j];
		}

		if(h[a] < h[b]) swap(a,b);
		
		if((h[v] - h[a] + 1) % 3 != 0) c[i] = getFather(v, a);
		else if((h[v] - h[b] + 1) % 3 != 0) c[i] = getFather(v,b);
		else {
			c[i] = getFather(a,b);
			c[i].insert(c[i].begin(), v);
		}

		printf("%d\n", (int)c[i].size());
		for(int x : c[i]) printf("%d ", x);
		printf("\n");
	}

	return 0;

}



