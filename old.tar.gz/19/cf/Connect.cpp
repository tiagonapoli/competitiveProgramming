#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 1010

int grid[N][N];
int vis[N][N];
int n;
int sqr(int x) {return x*x;}

bool visited(pii x) {
	if(grid[x.fi][x.se] == 1) return 1;
	return vis[x.fi][x.se];
}

int dx[] = {-1, +1, +0, +0};
int dy[] = {+0, +0, -1, +1};
vector<pii> field[2];

int bfs(pii from, int scc) {
	queue<pii> fila;
	fila.push(from);
	vis[from.fi][from.se] = 1;
	while(!fila.empty()) {
		pii now = fila.front();
		//prin(now.fi);
		//prin(now.se);
		//separa();
		fila.pop();
		field[scc].pb(now);
		for(int i=0;i<4;i++) {
			pii next = now;
			next.fi += dx[i];
			next.se += dy[i];
			//prin(next.fi);
			//prin(next.se);
			//prin(visited(next));
			//separa();
			if(!visited(next)) {
				vis[next.fi][next.se] = 1;
				fila.push(next);
			}
		}
	}
}


int main () {

	cin >> n;

	pii from, to;
	cin >> from.fi >> from.se;
	cin >> to.fi >> to.se;

	for(int i=0;i<=n+2;i++) {
		for(int j=0;j<=n+2;j++) {
			vis[i][j] = 1;
		}
	}

	for(int i=1;i<=n;i++) {
		for(int j=1;j<=n;j++) {
			char c;
			vis[i][j] = 0;
			scanf(" %c", &c);
			grid[i][j] = c - '0';
		}
	}

	bfs(from, 0);
	if(vis[to.fi][to.se]) {
		cout << 0 << endl;
		return 0;
	}

	bfs(to, 1);
	int res = 99999999;
	for(pii x : field[0]) {
		for(pii y : field[1]) {
			res = min(res, sqr(x.fi-y.fi) + sqr(x.se-y.se)); 
		}
	}

	/*
	separa();
	for(int i=1;i<=n;i++) {
		for(int j=1;j<=n;j++) {
			printf("%d", vis[i][j]);
		}
		printf("\n");
	}
*/
	cout << res << endl;
	return 0;

}



