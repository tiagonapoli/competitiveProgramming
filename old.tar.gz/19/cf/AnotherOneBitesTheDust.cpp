#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define FOR(i,a,b) for(int i=(a);i<(b);i++)
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>

bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define prinpar(a) if(debug) printf("%d/%d\n", (a.fi), (a.se))
#define separa() if(debug) cout << endl

const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

ll solve(ll a, ll b, ll c) {
	if(b < 0) return -100;
	return 2*c + 2*min(a,b) + (min(a,b) < a);
}

int main () {

	int a,b,c;

	cin >> a >> b >> c;

	cout << max(solve(a,b,c), 1 + solve(a,b-1,c)) << endl;
	


	return 0;

}



