#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define FOR(i,a,b) for(int i=(a);i<(b);i++)
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>

bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define prinpar(a) if(debug) printf("%d/%d\n", (a.fi), (a.se))
#define separa() if(debug) cout << endl

const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 200100


int v[N];
int res[N];
int loc[N];

int main () {

	int t,n;
	
	cin >> t;
	while(t--) {
		cin >> n;
		for(int i=1;i<=n;i++) {
			scanf("%d", &v[i]);
			loc[v[i]] = i;
			res[i] = 0;
		}

		int a,b;
		a=loc[1];
		b=loc[1];

		set<int> num;
		num.insert(1);
		
		for(int i=1;i<=n;i++) {
			int c = loc[i];
			while(a > c) {
				a--;
				num.insert(v[a]);
			}
			
			while(b < c) {
				b++;
				num.insert(v[b]);
			}

			if(*num.end() == i && num.size() == i) {
				res[i] = 1;
			}

			prin(a);
			prin(b);
			separa();
			
		}

		for(int i=1;i<=n;i++) {
			printf("%d", res[i]);
		}
		printf("\n");
	}



	return 0;

}



