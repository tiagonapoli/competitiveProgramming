#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

int in[N], r[N];
priority_queue<int> heap;

int main () {

	int n;

	cin >> n;
	fr(i,0,n) {
		cin >> in[i];
		heap.push(in[i]);
	}

	int i,j;
	i=n-1,j=1;
	r[0] = heap.top(); heap.pop();
	while(!heap.empty()) {
		r[i] = heap.top(); heap.pop();
		i--;
		if(heap.size() >= 1) {
			r[j] = heap.top(); heap.pop();
			j++;
		}
	}

	for(int i=0;i<n;i++) printf("%d ", r[i]);
	return 0;

}



