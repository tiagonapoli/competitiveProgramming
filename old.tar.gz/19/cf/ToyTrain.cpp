#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 5100

vector<int> v[N];
int n, m;
int t[N];

int dist(int a, int b) {
	if(b >= a) return b-a;
	return n-a + b;
}

int main () {

	cin >> n >> m;
	
	int a,b;
	for(int i=0;i<m;i++) {
		cin >> a >> b;
		v[a].pb(b);
	}

	for(int i=1;i<=n;i++) {
		if(v[i].size() == 0) {
			t[i] = 0;
			continue;
		}
		sort(v[i].begin(), v[i].end());
		t[i] += (v[i].size() - 1) * n;
		if((*v[i].rbegin()) > i) {
			int pos = lower_bound(v[i].begin(), v[i].end(), i) - v[i].begin();
			t[i] += v[i][pos] - i;
		} else {
			t[i] += n - i +  v[i][0];
		}
		prin(i);
		prin(t[i]);
		separa();
	}

	for(int i=1;i<=n;i++) {
		int res = 0;
		for(int j=1;j<=n;j++) {
			res = max(res, t[j] == 0 ? 0 : t[j] + dist(i,j));
		}
		printf("%d ", res);
	}
	cout << endl;

	


	return 0;

}



