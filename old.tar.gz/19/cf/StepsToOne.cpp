#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

vector<int> d[N], pd[N];
bool composite[N];
ll pot2[10], m;
ll dp[N];

ll fastPow(ll b, int e) {
	ll res = 1;
	while(e) {
		if(e & 1) {
			res *= b;
			res %= MOD;
		}
		b *= b;
		b %= MOD;
		e >>= 1;
	}
	return res;
}

int divisors() {
	for(int i=1;i<N;i++) {
		for(int j=i;j<N;j+=i) {
			d[j].pb(i);	
		}
	}
}

int primeDivisors() {
	for(int i=2;i<N;i++) {
		if(composite[i] == 1) continue;
		for(int j=i;j<N;j+=i) {
			pd[j].pb(i);
			composite[j] = 1;
		}
	}
}

ll multiplesInRange(vector<int> &numbers, int maxi) {
	ll res = 0, num;
	for(int i=1;i<pot2[numbers.size()]; i++) {
		num = 1;
		for(int j=0;j<numbers.size();j++) {
			if((1<<j) & i) num *= numbers[j]; 
		}
		if(__builtin_popcount(i) % 2 == 1) {
			res += maxi/num;
		} else res -= maxi/num;
	}

	return res;
}

int main () {

	cin >> m;

	divisors();
	primeDivisors();

	pot2[0] = 1;
	for(int i=1;i<10;i++) pot2[i] = pot2[i-1] * 2;

	dp[1] = 0;
	for(int i=2;i<=m;i++) {
		dp[i] = m;
		for(int div : d[i]) {
			if(div == i) continue;
			ll aux = (m/div - multiplesInRange(pd[i/div], m/div) + MOD) % MOD;	
			dp[i] += dp[div] * aux;		
			dp[i] %= MOD;
		}
		dp[i] *= fastPow(m-m/i, MOD - 2);
		dp[i] %= MOD;
	}

	ll res = 1;
	for(int i=1;i<=m;i++) {
		res += dp[i] * fastPow(m, MOD-2);
		res %= MOD;
	}

	cout << res << endl;

	return 0;
}



