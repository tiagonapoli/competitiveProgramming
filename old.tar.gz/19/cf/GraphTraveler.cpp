#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define FOR(i,a,b) for(int i=(a);i<(b);i++)
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>

bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define prinpar(a) if(debug) printf("%d/%d\n", (a.fi), (a.se))
#define separa() if(debug) cout << endl

const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 1100
#define lcm 2520

int pai[N*lcm + 1000], sz[N*lcm + 1000];
int k[N];
int vis[N][2600];
vector<int> adj[N];
int n;

int norm(int x) {
	return ((x % lcm) + lcm) % lcm;
}


int trans(pii x) {
	return x.se + x.fi*lcm;
}

int _find(int x) {
	if(pai[x] == x) return x;
	return pai[x] = _find(pai[x]);
}

int find(pii x) {
	int y = trans(x);
	return _find(y);
}

void join(pii a, pii b) {
	int xa = find(a);
	int xb = find(b);
	pai[xb] = xa;
	sz[xa] = max(sz[xa],sz[xb]);
}

set<int> raux;
stack<pii> a;
int t = 1;
void dfs(pii now) {
	vis[now.fi][now.se] = t;
	a.push(now);
	int nxtnum = norm(now.se + k[now.fi]);
	pii nxt = {adj[now.fi][nxtnum % adj[now.fi].size()], nxtnum};
	join(now,nxt);
	if(vis[nxt.fi][nxt.se] > 0) {
		if(vis[nxt.fi][nxt.se] != t) return;

		while(!a.empty() && a.top() != nxt) {
			raux.insert(a.top().fi);
			a.pop();
		}
		raux.insert(a.top().fi);
		a.pop();
		sz[find(now)] = raux.size();
	} else {
		dfs(nxt);
	}
}

int main () {

	for(int i=0;i<N*lcm;i++) {
		pai[i] = i;
		sz[i] = 0;
	}

	scanf("%d", &n);


	for(int i=0;i<n;i++) {
		scanf("%d", &k[i]);
		k[i] = norm(k[i]);
	}

	int m,x;
	for(int i=0;i<n;i++) {
		scanf("%d", &m);
		for(int j=0;j<m;j++) {
			scanf("%d", &x);
			x--;
			adj[i].pb(x);
		}
	}

	int q,y;
	scanf("%d", &q);
	for(int i=0;i<q;i++) {
		scanf("%d %d", &x, &y);
		x--;
		y = norm(y);
		if(vis[x][y] != 1) {
			while(!a.empty()) a.pop();
			raux.clear();
			dfs({x,y});
		}
		pii now = {x,y};
		printf("%d\n", sz[find(now)]);
		t++;
	}

	return 0;

}



