#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

ll seq[26];

vector<pair<int, ll> > decomp(string &s) {
	vector<pair<int, ll> > dec;
	pair<int, ll> now = { s[0] - 'a', 0 };
	for(char c : s) {
		if(now.fi == c - 'a') {
			now.se++;
		} else {
			dec.pb(now);
			now = { c - 'a', 1 };
		}
	}
	dec.pb(now);
	return dec;
}

ll maxi = 1e9;
void go(string &s) {
	auto d = decomp(s);
	auto a = *d.begin(), b = *d.rbegin(); 
	if(d.size() == 1) {
		seq[a.fi] = seq[a.fi] > 0 ? min(maxi, seq[a.fi] + a.se * (seq[a.fi]+1)) : a.se;
	} else {
		if(a.fi == b.fi) {
			if(seq[a.fi] > 0)
				seq[a.fi] = min(maxi, a.se + b.se + 1);
		} else {
			seq[a.fi] = a.se + (seq[a.fi] > 0);
			seq[b.fi] = b.se + (seq[b.fi] > 0);
		}
	}

	for(int i=0;i<26;i++)
		if(i != a.fi and i != b.fi) seq[i] = seq[i] > 0;
	
	for(auto x : d) 
		seq[x.fi] = max(seq[x.fi], x.se);

}

int main () {

	int n;

	cin >> n;

	string s;
	fr(i,0,n) {
		cin >> s;
		go(s);
		if(debug)
			fr(i,0,3) printf("[%c] %lld\n", 'a' + i, seq[i]);
		separa();
	}

	ll res = 0;
	for(int i=0;i<26;i++) res = max(res, seq[i]);
	cout << res << endl;
	return 0;

}



