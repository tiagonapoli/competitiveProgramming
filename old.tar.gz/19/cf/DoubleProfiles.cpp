#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 1000100

ll MOD1 = 1000000007;
ll MOD2 = 1000000009;
pll pot[N];
pll guyHash[N];
int n, m;

void pre() {
	pot[0] = {1LL, 1LL};
	for(int i=1;i<N;i++) {
		pot[i].fi = pot[i-1].fi * 2;
		pot[i].se = pot[i-1].se * 2;
		pot[i].fi %= MOD1;
		pot[i].se %= MOD2;
	}
}

void add(pll &res, int p) {
	res.fi += pot[p].fi;
	res.se += pot[p].se;
	res.fi %= MOD1;
	res.se %= MOD2;
}

map<pll, ll> hashes;
pii friends[N];

int main () {
	
	pre();
	scanf("%d %d", &n, &m); 

	int a,b;
	fr(i, 0, m) {
		scanf("%d %d", &a, &b);
		friends[i] = {a,b};
		add(guyHash[a], b);
		add(guyHash[b], a);
	}

	fr(i, 1, n+1) {
		hashes[guyHash[i]]++;		
	}

	ll res = 0;
	for(pair<pll, ll> h : hashes) {
		res += h.se * (h.se - 1LL) / 2LL;
	}

	pll hashA, hashB;
	fr(i, 0, m) {
		a = friends[i].fi;
		b = friends[i].se;
		hashA = guyHash[a];
		add(hashA, a);
		hashB = guyHash[b];
		add(hashB, b);
		if(hashA == hashB) res++;
	}

	cout << res << endl;


	return 0;

}



