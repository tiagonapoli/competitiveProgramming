#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 300100

ll dp1[N], dp2[N];
ll a[N], ans = -10000000000LL;
int n;
vector<int> adj[N];

void dfs1(int u, int pai) {
	ll sum = a[u];
	for(int v : adj[u]) {
		if(v != pai) {
			dfs1(v,u);
			sum += dp1[v] > 0 ? dp1[v] : 0;
		}
	}
	dp1[u] = sum;
}

int dfs2(int u, int pai) {
	ll sum = a[u];
	int k = 0;
	for(int v : adj[u]) {
		if(v != pai) {
			k += dfs2(v,u);
			sum += dp2[v] > 0 ? dp2[v] : 0;
		}
	}

	if(sum == ans) dp2[u] = -1000000000000LL;
	else dp2[u] = sum;

	if(sum == ans) {
		assert(a[u] != 0);
		return 1 + k;
	} else return k;
}

int main () {
	
	scanf("%d", &n);

	for(int i=1;i<=n;i++) {
		scanf("%lld", &a[i]);
	}

	int x,y;
	for(int i=0;i<n-1;i++) {
		scanf("%d %d", &x, &y);
		adj[x].pb(y);
		adj[y].pb(x);
	}

	dfs1(1, 0);
	for(int i=1;i<=n;i++) {
		ans = max(ans, dp1[i]);
	}
	prin(ans);

	int k = 0;
	if(ans <= 0) {
		for(int i=1;i<=n;i++) {
			if(a[i] == ans) k++;
		}
	} else {
		k = dfs2(1, 0);
	}
	
	printf("%lld %d\n", ans*k, k);

	return 0;

}



