#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 300100

ll dp[N][4][4], a[N];
ll mul[4][4]; 
ll inf = 100000000000000LL;
int n, x;

ll go(int pos, int seg, int iseg) {
	if(dp[pos][seg][iseg] != -inf) return dp[pos][seg][iseg];
	if(pos == n) return dp[pos][seg][iseg] = 0;
	
	ll r = -inf;
	for(int i=seg;i<=2;i++) {
		for(int j=iseg;j<=2;j++) {
			if(mul[i][j] == -inf) continue;
			r = max(r, a[pos] * mul[i][j] + go(pos+1, i, j));
		}
	}
	prin(pos);
	prin(seg);
	prin(iseg);
	prin(r);
	separa();
	return dp[pos][seg][iseg] = r;
}


int main () {

	cin >> n >> x;

	mul[0][0] = 0;
	mul[0][1] = -inf;
	mul[0][2] = 0;
	mul[1][0] = 1LL;
	mul[1][1] = x;
	mul[1][2] = 1LL;
	mul[2][0] = 0;
	mul[2][1] = -inf;
	mul[2][2] = 0;
	
	fr(i,0,n) scanf("%lld", &a[i]);

	for(int i=0;i<=n+10;i++) {
		for(int j=0;j<4;j++) {
			for(int k=0;k<4;k++) dp[i][j][k] = -inf;
		}
	}

	cout << go(0,0,0) << endl;

	return 0;

}



