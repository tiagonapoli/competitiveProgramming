#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define FOR(i,a,b) for(int i=(a);i<(b);i++)
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>

bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define prinpar(a) if(debug) printf("%d/%d\n", (a.fi), (a.se))
#define separa() if(debug) cout << endl

const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 300100

int a[N];
int n;
vector<pii> res;

int main () {

	int n;

	cin >> n;

	FOR(i,1,n+1) scanf("%d", &a[i]);

	for(int i=1;i<=n;i++) {
		if(i == a[i]) continue;
		int dest = a[i];
		if(abs(dest - i) * 2 >= n) {
			res.pb({i,dest});
			swap(a[i],a[dest]);
			i--;
			continue;
		}

		int x = i,y = a[i];
		if(x > y) swap(x,y);
		
		int aux1, aux2 = x <= n/2 ? n : 1;
		aux1 = aux2;
		if(x <= n/2 && y > n/2) {
			aux1 = 1;
			aux2 = n;
		}

		res.pb({y,aux1});
		if(aux1 != aux2) res.pb({aux1,aux2});
		res.pb({aux2,x});
		if(aux1 != aux2) res.pb({aux2,aux1});
		res.pb({aux1,y});
		
		swap(a[y], a[aux1]);
		swap(a[aux1], a[aux2]);
		swap(a[aux2], a[x]);
		swap(a[aux2], a[aux1]);
		swap(a[aux1], a[y]);
		i--;
	}

	separa();
	if(debug)FOR(i,1,n+1) printf("%d ", a[i]);
	separa();

	printf("%d\n", (int)res.size());
	for(auto x : res) {
		printf("%d %d\n", x.fi, x.se);
	}


	return 0;

}



