#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_fatherr
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii fatherr<int,int>
#define pll fatherr<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 3000

set<int> adj[N];
int father[N], indeg[N], res[N], m, n;
char grid[N][N];

int find(int x) {return father[x] == x ? x : father[x] = find(father[x]);}
void join(int a, int b) {
	a = find(a); b = find(b);
	if(a != b) father[b] = a;
}

void connect(int a, int b) {
	a = find(a); b = find(b);
	if(adj[a].find(b) == adj[a].end()) indeg[b]++;
	adj[a].insert(b);
}

int main () {
	
	scanf("%d %d", &n, &m);
	fr(i,0,n+m+100) father[i] = i;

	fr(i,0,n) {
		fr(j,0,m) {
			scanf(" %c", &grid[i][j]);
			if(grid[i][j] == '=') join(i,n+j); 
		}
	}

	fr(i,0,n) {
		fr(j,0,m) {
			if(grid[i][j] == '<') connect(i, j+n);
			if(grid[i][j] == '>') connect(j+n, i);
		}
	}

	set<int> fila;
	for(int i=0;i<m+n;i++) {
		if(indeg[find(i)] == 0) {
			fila.insert(find(i));	
			res[find(i)] = 1;
		}
	}

	int now;
	while(!fila.empty()) {
		now = *fila.begin(); fila.erase(fila.begin());
		now = find(now);
		prin(now);
		for(int v : adj[now]) {
			prin(find(v));
			indeg[find(v)]--;
			prin(indeg[find(v)]);
			res[find(v)] = max(res[find(v)], 1 + res[now]);
			if(indeg[find(v)] == 0) fila.insert(find(v));
		}
		separa();
	}

	for(int i=0;i<n+m;i++) {
		if(indeg[find(i)] != 0) {
			printf("No\n");
			return 0;
		}
	}

	printf("Yes\n");
	for(int i=0;i<n;i++) {
		printf("%d ", res[find(i)]);
	}
	printf("\n");

	for(int i=0;i<m;i++) {
		printf("%d ", res[find(i+n)]);
	}
	printf("\n");

	



	return 0;

}



