#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 5100

int dp[N][N];
ll sHash[N], invHash[N], pot[N], inv[N];
int res[N];
int p = 31;
string s;

void pre() {
	pot[0] = 1;
	inv[0] = 1;
	for(int i=1;i<N;i++) {
		pot[i] = pot[i-1] * p;
		pot[i] %= MOD;
		inv[i] = inv[i-1] * 129032259;
		inv[i] %= MOD;
	}

	sHash[0] = s[0] - 'a' + 1;
	for(int i=1;i<s.size();i++) {
		sHash[i] = sHash[i-1] + pot[i] * (s[i]-'a'+1);
		sHash[i] %= MOD;
	}

	int n = s.size();
	invHash[n-1] = s[n-1] - 'a' + 1;
	for(int i=n-2;i>=0;i--) {
		invHash[i] = invHash[i+1] + pot[n-1-i] * (s[i] - 'a' + 1);
		invHash[i] %= MOD;
	}
}

ll calcHash(int a, int b) {
	if(a == 0) return sHash[b];
	return ((sHash[b] - sHash[a-1] + MOD) * inv[a]) % MOD;
}

ll calcHashInv(int a, int b) {
	if(b == s.size()-1) return invHash[a];
	return ((invHash[a] - invHash[b+1] + MOD) * inv[(s.size()-1) - b]) % MOD;
}

void solve() {

	for(int i=0;i<s.size();i++) {
		dp[i][i] = 1;
	}

	int a,b,c,d;
	for(int sz=2;sz<=s.size();sz++) {
		for(int i=0;i+sz-1 < s.size();i++) {
			a = i;
			b = i + sz/2 - 1;
			c = (sz % 2) ? b+2 : b+1;
			d = i + sz - 1;
			dp[a][d] = calcHash(a,d) == calcHashInv(a,d);
			if(calcHash(a,b) == calcHash(c,d) and dp[a][b] >= 1) {
				dp[a][d] = dp[a][b] + 1;
			}
		}
	}
}

int main () {

	cin >> s;

	pre();
	solve();
	
	for(int sz=1;sz<=s.size();sz++) {
		for(int i=0;i+sz-1<s.size();i++) {
			res[dp[i][i+sz-1]]++;
			// cout << s.substr(i,sz) << " " << dp[i][i+sz-1];
			// separa();
		}
	}

	int acc = 0;
	for(int i=s.size();i>0;i--) {
		acc += res[i];
		res[i] = acc;
	}

	for(int i=1;i<=s.size();i++) {
		printf("%d ", res[i]);
	}
	cout << endl;

	return 0;

}



