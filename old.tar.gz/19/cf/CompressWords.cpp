#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define FOR(i,a,b) for(int i=(a);i<(b);i++)
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>

bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define prinpar(a) if(debug) printf("%d/%d\n", (a.fi), (a.se))
#define separa() if(debug) cout << endl

const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 1001000

int pf[N];
int solve(string a, string b) {
	string c = a + "#" + b;
	pf[0] = 0;
	for(int i=1;i<c.size();i++) {
		int sz=pf[i-1];
		while(sz > 0 && c[sz] != c[i]) {
			sz = pf[sz-1];
		}

		if(c[sz] == c[i]) {
			sz++;
		}

		pf[i] = sz;
	}

	/*
	FOR(i,0,c.size()) printf("%d", pf[i]);
	cout << endl;
	cout << c << endl;
	*/
	return pf[c.size()-1];
}


string v[N];
int main() {

	int n;
	cin >> n;
	for(int i=0;i<n;i++) {
		cin >> v[i];
	}
	
	string r = v[0];
	for(int i=1;i<n;i++) {
		int sz;
		string sec;
		if(r.size() >= v[i].size()) {
			sec = r.substr(r.size()-v[i].size());
		} else {
			sec = r;
		}
		sz = solve(v[i], sec);
		//cout << r << " " << v[i] << " " << sz << endl << endl;

		r += v[i].substr(sz);
	}

	cout << r << endl;
}



