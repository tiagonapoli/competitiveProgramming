#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define FOR(i,a,b) for(int i=(a);i<(b);i++)
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>

bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define prinpar(a) if(debug) printf("%d/%d\n", (a.fi), (a.se))
#define separa() if(debug) cout << endl

const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 300100

int n;
int a[N];
ll s[N];

int main () {

	int k;
	scanf("%d %d", &n, &k);
	FOR(i,1,n+1) scanf("%d", &a[i]);
	FOR(i,1,n+1) s[i] = s[i-1] + a[i];

	ll res = (ll)k*s[n];
	sort(s+1,s+n);
	for(int i=1;i<k;i++) {
		res -= s[i];	
	}

	cout << res << endl;

	

	return 0;

}



