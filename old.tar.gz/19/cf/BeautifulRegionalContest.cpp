#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define FOR(i,a,b) for(int i=(a);i<(b);i++)
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>

bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define prinpar(a) if(debug) printf("%d/%d\n", (a.fi), (a.se))
#define separa() if(debug) cout << endl

const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 500100

int v[N];

int main () {

	int t, n;

	cin >> t;
	while(t--) {
		cin >> n;

		vector<pii> p;
		scanf("%d", &v[0]);
		p.pb({v[0], 1});
		FOR(i,1,n) {
			scanf("%d", &v[i]);
			if(p.back().fi == v[i]) {
				p.back().se++;	
			} else p.pb({v[i], 1});
		}

		int g=0,s=0,b=0;
		int tot = 0;
		for(int i=0;i<p.size();i++) {
			if(tot + p[i].se > n/2) break;
			tot += p[i].se;
			if(g == 0) {
				g += p[i].se;
			} else if(s <= g) {
				s += p[i].se;
			} else {
				b += p[i].se;
			}
		}

		if(g == 0 || s == 0 || b == 0 || g >= s || g >= b) {
			printf("0 0 0\n");
		} else {
			printf("%d %d %d\n", g,s,b);
		}
	}



	return 0;

}



