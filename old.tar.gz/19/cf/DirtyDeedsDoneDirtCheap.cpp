#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define FOR(i,a,b) for(int i=(a);i<(b);i++)
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>

bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define prinpar(a) if(debug) printf("%d/%d\n", (a.fi), (a.se))
#define separa() if(debug) cout << endl

const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 300100

typedef pair<pii,int> asd;

vector<asd> solve(vector<asd> &s, int cres) {
	vector<asd> res;
	for(asd i : s) {
		if(res.size() == 0) {
			res.pb(i);
			continue;
		} 

		if(cres) {
			if(res.back().fi.fi > i.fi.se) res.pb(i);
		} else {
			if(res.back().fi.fi < i.fi.se) res.pb(i);
		}
	}

	return res;
}

void print(vector<asd> &r) {
	printf("%d\n", (int)r.size());
	for(auto x : r) {
		if(debug) printf("%d/%d\n", x.fi.se, x.fi.fi);
		printf("%d ", x.se);
	}
}

int main () {
	
	int n;

	scanf("%d", &n);

	vector<asd> c, dc;
	int a,b;
	FOR(i,0,n) {
		scanf("%d %d", &a, &b);
		if(a < b) c.pb({{b,a},i+1});
		else dc.pb({{b,a}, i+1});
	}
	
	sort(c.begin(), c.end(), greater<asd>());
	sort(dc.begin(), dc.end());

	auto r1 = solve(c,1);
	auto r2 = solve(dc,0);
	
	if(r1.size() > r2.size()) {
		print(r1);
	} else print(r2);

	

	return 0;

}



