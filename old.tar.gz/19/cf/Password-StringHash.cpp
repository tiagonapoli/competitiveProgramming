#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 1001000

//Dadas as string que sao sufixo e prefixo ao mesmo tempo temos que, se um prefixo de tamanho K eh resposta, ou seja, tb eh uma substring, entao os prefixos de tamanho < K tb sao resposta. Quero encontrar o maior K.

ll sHash[N], p = 31;
ll pot[N];
string s;

int getHash(int a, int b) {
	if(a == 0) return sHash[b];
	return (sHash[b] - ((sHash[a-1] * pot[b-a+1]) % MOD) + 2*MOD) % MOD;
}

void pre() { 
	sHash[0] = s[0] - 'a' + 1;
	pot[0] = 1;
	for(int i=1;i<s.size();i++) {
		sHash[i] = (sHash[i-1] * p) + (s[i] - 'a' + 1);
		sHash[i] %= MOD;
	}

	for(int i=1;i<=s.size()+10;i++) {
		pot[i] = pot[i-1] * p;
		pot[i] %= MOD;
	}
}

bool go(int k, int prefEnd) {
	ll prefHash = getHash(0, prefEnd);
	for(int i=1;i+k-1<s.size()-1;i++) {
		if(getHash(i,i+k-1) == prefHash) return true;
	}
	return false;
}

int bsearch(vector<int> validPref) {
	int i,f,m;
	i = 0;
	f = validPref.size();
	while(i < f) {
		m = (i+f)/2;
		if(go(validPref[m] + 1, validPref[m])) {
			i = m+1;
		} else f = m;
	}

	return i-1;
}




int main () {

	cin >> s;
	pre();

	vector<int> validPref;
	for(int i=0;i<s.size();i++) {
		if(getHash(0,i) == getHash(s.size()-1-i, s.size()-1)) {
			validPref.pb(i);
		}
	}

	// for(int i : validPref) {
	// 	cout << s.substr(0,i+1) << endl;
	// }
	
	int res = bsearch(validPref);
	if(res == -1) {
		cout << "Just a legend" << endl;
	} else {
		cout << s.substr(0, validPref[res] + 1) << endl;
	}
	return 0;

}



