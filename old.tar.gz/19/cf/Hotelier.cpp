#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define FOR(i,a,b) for(int i=(a);i<(b);i++)
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>

bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define prinpar(a) if(debug) printf("%d/%d\n", (a.fi), (a.se))
#define separa() if(debug) cout << endl

const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

int v[11];

int main () {
	
	int n;

	scanf("%d", &n);

	string s;
	cin >> s;
	int inc, ini;

	for(int i=0;i<n;i++) {
		if(s[i] == 'L') {
			ini = 0;
			inc = 1;
		} else if(s[i] == 'R') {
			ini = 9;
			inc = -1;
		} else {
			v[s[i] - '0'] = 0;
			continue;
		}

		for(int i=ini;i<10 && i >=0; i+=inc) {
			if(v[i] == 0) {
				v[i] = 1;
				break;
			}
		}
	}

	for(int i=0;i<10;i++) {
		printf("%d", v[i]);
	}

	return 0;

}



