#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 200100

int pai[N], n;
pii endp[N];
vector<int> adj[N];

int connect(int u, int v) {adj[u].pb(v);adj[v].pb(u);}
int find(int x) {return pai[x] == x ? x : pai[x] = find(pai[x]);}
int join(int a, int b) {
	a = find(a); b = find(b);
	if(a != b) {
		connect(endp[a].se, endp[b].fi);
		endp[a].se = endp[b].se;
		pai[b] = a;
	}
}

bool vis[N];
void dfs(int u) {
	vis[u] = 1;
	printf("%d ", u);
	for(int v : adj[u]) {
		if(!vis[v]) dfs(v);
	}
}

void print() {
	for(int i=1;i<=n;i++) {
		printf("%d: ", i);
		for(int v : adj[i]) printf("%d ", v);
		printf("\n");
	}
}

int main () {

	int a,b;
	cin >> n;

	fr(i,0,n+10) {
		pai[i] = i;
		endp[i].fi = endp[i].se = i;
	}
	fr(i,0,n-1) {
		scanf("%d %d", &a, &b);
		join(a,b);
	}
	
	if(debug) print();

	for(int i=1;i<=n;i++) {
		if(adj[i].size() == 1) {
			dfs(i);
			break;
		}
	}

	return 0;

}



