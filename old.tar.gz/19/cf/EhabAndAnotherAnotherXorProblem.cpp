#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100


int query(int a, int b) {
	int x;
	printf("? %d %d\n", a, b);
	fflush(stdout);
	cin >> x;
	return x;
}

int main () {

	int a,b;

	a = b = 0;
	int r1, r2, ini;
	ini = -2;
	for(int i=29;i>=0;i--) {
		int bit = 1 << i;
		if(ini == -2) ini = query(a, b);
		if(ini == 0) {
			r1 = query(a + bit, b);
			if(r1 < 0) {
				a += bit;
				b += bit;
			}
			ini = -2;
		} else {
			r1 = query(a + bit, b + bit);
			if(r1 != ini) {
				if(ini == 1) {
					a += bit;
				} else b += bit;
				ini = -2;
			} else {
				r2 = query(a + bit, b);
				if(r2 < 0) {
					a += bit;
					b += bit;
				}
			}
		}

		prin(a);
		prin(b);
		separa();
	}
	
	printf("! %d %d\n", a, b);

	return 0;

}



