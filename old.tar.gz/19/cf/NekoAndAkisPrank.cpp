#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 2050

ll dp[N][N];
int n;

ll solve(int pos, int aberto) {
	if(pos < 0) return 0;
	if(aberto == -1 || aberto > n || aberto + pos > 2*n) return 0;
	if(dp[pos][aberto] != -1) return dp[pos][aberto];
	dp[pos][aberto] = solve(pos-1, aberto+1) + solve(pos-1, aberto-1);
	dp[pos][aberto] %= MOD;
	return dp[pos][aberto];
}

int main () {

	cin >> n;

	for(int i=0;i<=2*n+10;i++) {
		for(int j=0;j<=2*n+10;j++) dp[i][j] = -1;
	}
	dp[0][0] = 1;

	ll res = 0;
	for(int i=1;i<=2*n;i+=2) {
		for(int j=0;j<=n;j++) {
			res += solve(i,j);
			res %= MOD;
		}
	}
	
	cout << res << endl;
	return 0;

}



