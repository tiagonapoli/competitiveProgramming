#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define FOR(i,a,b) for(int i=(a);i<(b);i++)
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>

bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define prinpar(a) if(debug) printf("%d/%d\n", (a.fi), (a.se))
#define separa() if(debug) cout << endl

const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 2100

int n, k;
int res = 0;

void solve(char v[N][N], int r[N][N]) {
	pii a[N];
	int s[N];

	for(int i=0;i<n;i++) {
		s[i] = 0;
	}

	for(int i=0;i<n;i++) {
		a[i] = {-1,-1};
		for(int j=0;j<n;j++) {
			if(v[i][j] == 'B') {
				a[i].se = j;
				if(a[i].fi == -1) a[i].fi = j;
			}
		}
		if(a[i].fi == -1) {
			res++;
			continue;
		}

		int sz = a[i].se - a[i].fi + 1;
		if(sz > k) {
			a[i] = {-1,-1};
			continue;
		}

		int diff = k-sz;
		a[i] = {max(0,a[i].fi-diff), a[i].fi+1};
		// printf("%d %d->%d\n", i, a[i].fi, a[i].se);
	}

	int i2 = 0;
	for(int i=0;i<n-k+1;i++) {
		while(i2 < n && i2-i+1 <= k) {
			if(a[i2].fi == -1) {
				i2++;
				continue;
			}
			assert(a[i2].fi <= n && a[i2].fi >= 0);
			assert(a[i2].se <= n && a[i2].se >= 0); 

			s[a[i2].fi]++;
			s[a[i2].se]--;
			i2++;
		}

		int cnt = 0;
		for(int j=0;j<n-k+1;j++) {
			//printf("%d ", s[j]);
			cnt += s[j];
			r[i][j] = cnt;
		}
		//separa();


		if(a[i].fi == -1) continue;
		s[a[i].fi]--;
		s[a[i].se]++;
	}
}

int rl[N][N], rc[N][N];
int main () {
	char v[N][N];

	scanf("%d %d" ,&n, &k);

	FOR(i,0,n) FOR(j,0,n) {
		scanf(" %c", &v[i][j]);
	}
	
	solve(v,rl);

	for(int i=0;i<n;i++) {
		for(int j=0;j<=i;j++) {
			swap(v[i][j], v[j][i]);
		}
	}
	
	solve(v,rc);
	int r = 0;
	FOR(i,0,n) FOR(j,0,n) {
		r = max(r, res + rl[i][j] + rc[j][i]);
	}

	printf("%d\n", r);
	
	return 0;

}



