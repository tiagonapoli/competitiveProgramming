#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100


int main () {

	int a,b,x;

	cin >> x;

	for(int a=1;a<=x;a++) {
		for(int b=1;b<=x;b++) {
			if(a % b == 0 and a * b > x and a < x*b) {
				printf("%d %d\n", a, b);
				return 0;
			}
		}
	}

	cout << -1 << endl;

	return 0;

}



