#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define FOR(i,a,b) for(int i=(a);i<(b);i++)
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>

bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define prinpar(a) if(debug) printf("%d/%d\n", (a.fi), (a.se))
#define separa() if(debug) cout << endl

const ll MOD = 998244353;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 200100

ll v[N];

ll fact(ll b, ll e) {
	ll res = 1;
	while(e > 0) {
		if(e & 1) {
			res *= b;
			res %= MOD;
		}

		e>>=1;
		b*=b;
		b %= MOD;
	}
	
	return res;
}




int main () {

	int n;

	scanf("%d", &n);
	ll mul = 1;
	for(int i=0;i<n;i++) {
		scanf("%lld", &v[i]);
		// 100 modular inverse
		v[i] *= 828542813;
		v[i] %= MOD;
		mul *= v[i];
		mul %= MOD;
	}

	ll sum = 1;
	ll acum = 1;
	for(int i=0;i<n-1;i++) {
		acum *= v[i];
		acum %= MOD;
		sum += acum;
		sum %= MOD;
	}

	ll res = sum * fact(mul, MOD-2);
	res %= MOD;
	cout << res << endl;
	return 0;
}



