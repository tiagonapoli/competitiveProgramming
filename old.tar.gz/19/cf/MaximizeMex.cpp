#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 5100

const int MAXP = 5000;

vector<int> adj[N];
int p[N], c[N], n, m;
set<int> removalSet;
int removalOrder[N];
int match[N];
bool vis[N];

bool dfs(int u) {
	vis[u] = 1;
	assert(u < MAXP);
	for(int v : adj[u]) {
		assert(v-MAXP >= 0);
		assert(v > 5000);

		if(match[v - MAXP] != -1 and vis[match[v - MAXP]] == 1) continue;
		if(match[v - MAXP] == -1 or dfs(match[v - MAXP])) {
			match[v - MAXP] = u;
			return true;
		}
	}
	return false;
}

int mex = 0;
void augment() {
	bool aux;
	aux = dfs(mex);
	for(int j=0;j<MAXP;j++) vis[j] = 0;
	while(aux) {
		mex++;
		aux = mex < m ? dfs(mex) : false;
		for(int j=0;j<MAXP;j++) vis[j] = 0;
	}
}
	
void printMatch() {
	if(!debug) return;
	for(int i=0;i<4;i++) {
		printf("%d: ", i);
		for(int x : adj[i]) {
			printf("%d ", x);
		}
		separa();
	}

	for(int i=1;i<=m;i++) {
		printf("Match %d -> %d\n", i, match[i]);
	}
}

int main () {

	scanf("%d %d", &n, &m);

	for(int i=1;i<=n;i++) {
		scanf("%d", &p[i]);
	}

	for(int i=1;i<=n;i++) {
		scanf("%d", &c[i]);
	}

	int d;
	scanf("%d", &d);

	int x;
	for(int i=0;i<d;i++) {
		scanf("%d", &x);
		removalSet.insert(x);
		removalOrder[i] = x;
	}

	
	for(int i=1;i<=n;i++) {
		if(removalSet.find(i) == removalSet.end()) {
			adj[p[i]].pb(c[i] + MAXP);
		}
	}

	for(int i=1;i<=m;i++) match[i] = -1;
	
	int res[N];
	for(int i=d-1;i>=0;i--) {
		augment();
		res[i] = mex;
		printMatch();
		adj[p[removalOrder[i]]].pb(MAXP + c[removalOrder[i]]);
		separa();
	}

	for(int i=0;i<d;i++) {
		printf("%d\n", res[i]);
	}

	return 0;

}



