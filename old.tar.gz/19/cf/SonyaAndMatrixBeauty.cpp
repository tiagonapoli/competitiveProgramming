#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

ll hash[1000];
ll power[1000], hashBase = 31;
int cval[255];


int getStrHash(ll *hashAcc, int a, int b) {
	if(b < a) swap(a,b);
	return (hashAcc[b] - ((hashAcc[a] * power[b-a+1]) % MOD) + 2*MOD) % MOD;
}

int countPalindromes(string s) {
	
	string str;

	str.pb('#');
	for(char c: s) {
		str.pb(c);
		str.pb('#');
	}

	hash[0] = ('#' - 'a' + MOD) % MOD;
	for(int i=1;i<str.size();i++) {
		hash[i] = (hash[i-1] * p) + cval[str[i]];
		hash[i] %= MOD;
	}

	

	

}

int main () {



	return 0;

}



