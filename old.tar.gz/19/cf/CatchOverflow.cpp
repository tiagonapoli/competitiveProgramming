#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define FOR(i,a,b) for(int i=(a);i<(b);i++)
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>

bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define prinpar(a) if(debug) printf("%d/%d\n", (a.fi), (a.se))
#define separa() if(debug) cout << endl

const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

int n;
string s[N];
int val[N];

void fail() {
	printf("OVERFLOW!!!\n");
	exit(0);
}

ll maxi = 1LL << 32;
void check(ll x) {
	prin(maxi);
	if(x >= maxi) fail();
}

int i=0;
ll go(ll rep) {
	ll res = 0;
	while(i < n) {
		check(res);
		if(s[i] == "end") break;
		if(s[i] == "add") res++;
		else {
			int aux = val[i];
			i++;
			res += go(aux);	
		}
		i++;
	}
	prin(res);
	prin(rep);
	prin(res * rep);
	separa();
	check(res * rep);
	return res * rep;
}

int main () {
	
	scanf("%d", &n);

	FOR(i,0,n) {
		cin >> s[i];
		if(s[i] == "for") scanf("%d", &val[i]);
	}

	cout << go(1) << endl;
	
	return 0;

}



