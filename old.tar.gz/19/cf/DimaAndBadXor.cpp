#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define FOR(i,a,b) for(int i=(a);i<(b);i++)
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>

bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define prinpar(a) if(debug) printf("%d/%d\n", (a.fi), (a.se))
#define separa() if(debug) cout << endl

const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 510

int a[N][N];
int n,m;

vector<int> solve(int bit) {
	vector<int> r, both;
	int one = 0, zero = 0;

	for(int i=0;i<n;i++) {
		int p = 0;
		for(int j=0;j<m;j++) {
			if(a[i][j] & bit) p |= 1;
			else p |= 2;
		}
		if(p == 1) one++;
		if(p == 2) zero++;
		if(p == 3) both.pb(i);
		r.pb(0);
	}

	for(int p : both) {
		for(int j=0;j<m;j++) {
			if((a[p][j] & bit) == 0) {
				r[p] = j;
				break;
			}
		}
	}

	if(one % 2 == 1) return r;
	if(one % 2 == 0 && both.size() > 0) {
		for(int j=0;j<m;j++) {
			if(a[both[0]][j] & bit) {
				r[both[0]] = j;
				break;
			}
		}
		return r;
	}

	return vector<int>();
}

int main () {

	cin >> n >> m;

	FOR(i,0,n) FOR(j,0,m) {
		scanf("%d", &a[i][j]);			
	}

	int bit = 1;
	FOR(i,0,14) {
		vector<int> r = solve(bit);
		if(r.size() > 0) {
			printf("TAK\n");
			for(int x : r) {
				printf("%d ", x + 1);
			}
			printf("\n");
			return 0;
		}
		bit *= 2;
	}

	printf("NIE\n");	

	

	return 0;

}



