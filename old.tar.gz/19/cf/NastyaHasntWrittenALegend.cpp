#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

ll FLAG = -100000000000LL;
ll lazy[4*N], seg[4*N];
ll a[N], t[N], acumT[N];
int n;

void prop(int l, int r, int id) {
	if(lazy[id] == FLAG) return;
	if(l != r) {
		lazy[id*2] = lazy[id*2+1] = lazy[id]; 	
	}
	seg[id] = lazy[id] * (r-l+1);
	lazy[id] = FLAG;
}

void upd(int i, int j, ll val, int l=1, int r=n, int id=1) {
	prop(l,r,id);
	if(l > j or r < i) return;
	if(i <= l and r <= j) {
		lazy[id] = val;
		prop(l,r,id);
		return;
	}

	int mid = (l+r)/2;
	upd(i,j,val,l,mid,id*2);
	upd(i,j,val,mid+1,r,id*2+1);
	seg[id] = seg[id*2] + seg[id*2+1];
}

ll query(int i, int j, int l=1, int r=n, int id=1) {
	if(l > j or r < i) return 0;
	prop(l,r,id);
	if(i <= l and r <= j) return seg[id];
	int mid = (l+r)/2;
	return query(i,j,l,mid,id*2) + query(i,j,mid+1,r,id*2+1);
}

void build(int l=1, int r=n, int id=1) {
	lazy[id] = FLAG;
	if(l == r) {
		seg[id] = a[l] - t[l];
		return;
	}
	int mid = (l+r)/2;
	build(l,mid,id*2);
	build(mid+1,r,id*2+1);
	seg[id] = seg[id*2] + seg[id*2+1];
}

int equalInterval(int pos, ll val) {
	int i,m,f;
	i = pos;
	f = n + 1;
	while(i < f) {
		m = (i+f)/2;
		if(query(m, m) > val) {
			f = m;
		} else i = m + 1;
	}
	return f - 1;
}

void print(int l=1, int r=n, int id=1) {
	printf("%d->%d %lld lazy %lld\n", l,r,seg[id],lazy[id]);
	if(l != r) {
		int mid = (l+r)/2;
		print(l,mid,id*2);
		print(mid+1,r,id*2+1);
	}
}


int main () {

	scanf("%d", &n);

	fr(i,1,n+1) { 
		scanf("%lld", &a[i]);
	}
	fr(i,2,n+1) {
		scanf("%lld", &t[i]);
		t[i] += t[i-1];
	}

	for(int i=1;i<=n;i++) {
		acumT[i] = acumT[i-1] + t[i];
	}

	build();
	
	int q;
	scanf("%d", &q);

	char op;
	int a,b;
	for(int i=0;i<q;i++) {
		scanf(" %c %d %d", &op, &a, &b);
		if(op == '+') {
			ll valOnPos = query(a,a);
			int lastPos = equalInterval(a,valOnPos + b);
			upd(a,lastPos,valOnPos+b);
		} else {
			printf("%lld\n", query(a,b) + acumT[b] - acumT[a-1]);
		}
		//print();
	}


	return 0;

}



