#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define FOR(i,a,b) for(int i=(a);i<(b);i++)
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>

bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define prinpar(a) if(debug) printf("%d/%d\n", (a.fi), (a.se))
#define separa() if(debug) cout << endl

const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100


int main () {

	int t;

	int n;
	string v[10];
	cin >> t;
	while(t--) {
		cin >> n;
		
		int c[10];
		for(int i=0;i<10;i++) {
			c[i] = 0;
		}

		for(int i=0;i<n;i++) {
			cin >> v[i];
			c[v[i][0]-'0']++;
		}

		int now = 0;
		while(c[now] > 0) {
			now++;
		}

		int res = 0;
		for(int i=0;i<n;i++) {
			for(int j=i+1;j<n;j++) {
				if(v[i] == v[j]) {
					v[i][0] = now+'0';
					now++;
					while(c[now] > 0) {
						now++;
					}
					res++;
					break;
				}
			}
		}

		printf("%d\n", res);
		for(int i=0;i<n;i++) {
			cout << v[i] << endl;
		}
	}


	return 0;

}



