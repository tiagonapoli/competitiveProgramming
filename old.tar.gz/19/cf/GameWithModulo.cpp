#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

int aux = 0;
char query(ll a, ll b) {
	aux++;
	assert(a <= 2000000000);
	assert(b <= 2000000000);
	char c;
	printf("? %lld %lld\n", a, b);
	fflush(stdout);
	scanf(" %c", &c);
	return c;
}

int solve() {
	ll x = 1;
	while(query(x-1, 2*x-1) != 'x') {
		x = 2*x;
	}

	ll i,f,m;
	i = x;
	f = 2*x;
	while(f - i > 1) {
		m = (i+f)/2;
		if(query(m, x) == 'x') {
			i = m+1;
		} else f = m;
		prin(i);
		prin(f);
		separa();
	}

	if(f == 2*x) return x;
	return f;
}

int main () {

	string s;

	cin >> s;
	while(s != "end") {
		int x = solve();
		printf("! %d\n", x);
		fflush(stdout);
		cin >> s;
		aux = 0;
	}


	return 0;

}



