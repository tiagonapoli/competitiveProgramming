#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

vector<int> adj[N];
int k,n;
bool vis[N];

ll sol(int x) {
	ll res = 1;
	for(int i=0;i<k;i++) {
		res *= x;
		res %= MOD;
	}
	return res;
}

int dfs(int u) {
	vis[u] = 1;
	int res = 0;
	prin(u);
	for(int v : adj[u]) {
		if(vis[v] == 0) res += dfs(v);
	}
	return 1 + res;
}

int main () {

	scanf("%d %d", &n, &k);

	for(int i=0;i<=n;i++) vis[i] = 0;

	int a,b,c;
	for(int i=0;i<n-1;i++) {
		scanf("%d %d %d", &a, &b, &c);
		if(c == 0) {
			adj[a].pb(b);
			adj[b].pb(a);
		}
	}

	ll res = 0;
	for(int i=1;i<=n;i++) {
		if(vis[i] == 0) {
			prin(i);
			res += sol(dfs(i));		
			res %= MOD;
		}
	}

	prin(res);
	ll tot = 1;
	for(int i=0;i<k;i++) {
		tot *= n;
		tot %= MOD;
	}

	cout << (tot - res + MOD) % MOD << endl;
	return 0;

}



