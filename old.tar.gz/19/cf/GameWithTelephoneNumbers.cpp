#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

string s;
int posInv(int x) {
	return s.size() - x;
}

vector<int> p8;

int main () {

	int n;
	cin >> n >> s;


	int c8 = 0;
	fr(i,0,s.size()) {
		if(s[i] == '8') {
			p8.pb(i);
		}
	}

	int moves = (n-11)/2;
	int hasToDel = 0;
	for(int x : p8) {
		if(posInv(x) < 11) continue;
		prin(x);
		prin(moves+hasToDel);
		separa();
		if(x <= moves + hasToDel) hasToDel++;
	}

	prin(hasToDel);
	if(hasToDel > moves) {
		printf("YES\n");
	} else printf("NO\n");

	return 0;
}



