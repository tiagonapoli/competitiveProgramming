#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

vector<int> v[N];
int n;

int main () {
	
	scanf("%d", &n);

	int x;
	fr(i,0,2*n) {
		scanf("%d", &x);
		v[x].pb(i);
	}

	ll res = 0;
	int p1,p2;
	p1 = p2 = 0;
	fr(i,1,n+1) {
		if(abs(p1-v[i][0]) + abs(p2-v[i][1]) <= abs(p1-v[i][1]) + abs(p2-v[i][0])) {
			res += abs(p1-v[i][0]) + abs(p2-v[i][1]);
		} else {
			res += abs(p1-v[i][1]) + abs(p2-v[i][0]);
		}
		p1 = v[i][0];
		p2 = v[i][1];
	}

	cout << res << endl;
	return 0;

}



