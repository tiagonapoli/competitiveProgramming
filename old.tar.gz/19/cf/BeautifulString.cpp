#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define FOR(i,a,b) for(int i=(a);i<(b);i++)
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>

bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define prinpar(a) if(debug) printf("%d/%d\n", (a.fi), (a.se))
#define separa() if(debug) cout << endl

const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100


int main () {

	string s;
	int t;

	cin >> t;
	while(t--) {
		cin >> s;
		for(int i=0;i<s.size();i++) {
			if(s[i] == '?') {
				set<char> aux;
				aux.insert('a');
				aux.insert('b');
				aux.insert('c');
				if(i+1 < s.size() && s[i+1] != '?') {
					aux.erase(s[i+1]);
				}

				if(i-1 >= 0 && s[i-1] != '?') {
					aux.erase(s[i-1]);
				}

				s[i] = *aux.begin();
			}
		}

		bool res = 0;
		for(int i=0;i<s.size()-1;i++) {
			if(s[i] == s[i+1]) {
				res = 1;
			}
		}

		if(res) {
			printf("-1\n");
		} else cout << s << endl;
	}


	return 0;

}



