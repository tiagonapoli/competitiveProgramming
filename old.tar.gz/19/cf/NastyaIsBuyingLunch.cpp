#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 600100

int fila[N];
int vcnt[N];

vector<int> adj[N];
vector<int> inv[N];

bool in(int x, int y) {
	return binary_search(inv[y].begin(), inv[y].end(), x);
}

int main () {

	int n,m;

	cin >> n >> m;

	for(int i=0;i<n;i++) {
		scanf("%d", &fila[i]);
	}
	
	int a,b;
	for(int i=0;i<m;i++) {
		scanf("%d %d", &a, &b);
		adj[a].pb(b);
		inv[b].pb(a);
	}

	for(int i=0;i<=n+1;i++) {
		sort(adj[i].begin(), adj[i].end());
		sort(inv[i].begin(), inv[i].end());
	}

	int between = 0, res = 0;
	for(int i=n-2;i>=0;i--) {
		if(in(fila[i], fila[n-1]) and vcnt[fila[i]] == between) {
			res++;
		} else {
			for(auto j : inv[fila[i]]) {
				vcnt[j]++;
			}
			between++;
		}
	}

	cout << res << endl;


	return 0;

}



