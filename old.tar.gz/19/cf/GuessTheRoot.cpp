#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000003;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

typedef vector<ll> poly;

ll fastPow(ll b, int e) {
	ll res = 1;
	while(e) {
		if(e & 1) res *= b;
		res %= MOD;
		e /= 2;
		b *= b;
		b %= MOD;
	}
	return res;
}

ll inv(ll x) { return fastPow(x, MOD-2); }
ll mul(ll a, ll b) { return (a * b) % MOD; }
ll divi(ll a, ll b) { return mul(a, inv(b)); }
ll sub(ll a, ll b) { return (a - b + MOD) % MOD; }
ll add(ll a, ll b) { return (a + b) % MOD; }

void print(vector<poly> a) {
	int n = a.size();
	for(int i=0;i<n;i++) {
		for(int j=0;j<=n;j++) {
			printf("%lld ", a[i][j]);
		}
		printf("\n");
	}
	printf("-----\n");
}

poly GaussJordan(vector<poly> a) {
	int n = a.size();

	for(int col=0, row=0; col < n and row < n; col++, row++) {
		int sel = row;
		for(int i=row;i<n;i++) {
			if(a[row][col] != 0)  {
				sel = row;
				break;
			}
		}
		
		for(int i=col;i<=n;i++) {
			swap(a[sel][i], a[row][i]);
		}
		
		for(int i=0;i<n;i++) {
			if(i != row) {
				ll f = divi(a[i][col], a[row][col]);
				for(int j=col;j<=n;j++) {
					a[i][j] = sub(a[i][j], mul(a[row][j], f));
				}
			}
		}

	}

	if(debug) print(a);
	poly ans(n,0);
	for(int i=0;i<n;i++) {
		ans[i] = divi(a[i][n], a[i][i]);
		if(debug) printf("%lld ", ans[i]);
	}

	return ans;
	
}

ll read(int x) {
	int fx;
	printf("? %d\n", x);
	cin >> fx;
	cout.flush();
	return fx;
}

ll evalP(poly p, ll x) {
	ll res = 0;
	for(int i=0;i<p.size();i++) {
		res += mul(p[i], fastPow(x,i));
		res %= MOD;
	}
	return res;
}

int main () {

	vector<poly> a(11);
	for(int i=0;i<=10;i++) {
		for(int j=0;j<=10;j++) {
			a[i].pb(fastPow(i,j));
		}
		a[i].pb(read(i));
	}

	poly p = GaussJordan(a);

	for(ll i=0;i<MOD;i++) {
		if(evalP(p, i) == 0) {
			printf("! %lld\n", i);
			return 0;
		}
	}

	printf("! -1\n");

	return 0;

}



