#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

ll lcm(ll a, ll b) {
	return a / __gcd(a,b) * b;
}

int main () {

	int a,b;

	cin >> a >> b;
	if(a > b) swap(a,b);

	ll best = lcm(a,b);
	ll kr = 0;

	vector<int> div;
	for(int d=1;d*d<= b-a; d++) {
		if((b-a) % d == 0) {
			div.pb(d);
			div.pb((b-a)/d);
		}
	}

	for(int x : div) {
		ll k = x - (a % x);
		ll mmc = lcm(a+k,b+k);
		if(mmc < best) {
			best = mmc;
			kr = k;
		} else if(mmc == best and k < kr) {
			kr = k;
		}
	}

	cout << kr << endl;
	return 0;

}



