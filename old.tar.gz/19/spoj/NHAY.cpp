#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 1001000

ll p = 31;
ll inv[N], sHash[N];

ll fastPow(ll b, int e) {
	ll res = 1;
	while(e) {
		if(e & 1) {
			res *= b;
			res %= MOD;
		}
		b *= b;
		b %= MOD;
		e /= 2;
	}
	return res;
}

void pre() {
	inv[N-1] = fastPow(fastPow(p, N-1), MOD-2);
	for(int i=N-2;i>=0;i--) {
		inv[i] = inv[i+1] * p;
		inv[i] %= MOD;
	}
}

void hashPre(char *s) {
	int n = strlen(s);
	sHash[0] = s[0] - 'a' + 1;
	ll pot = p;
	for(int i=1;i<n;i++) {
		sHash[i] = sHash[i-1] + (s[i] - 'a' + 1) * pot;
		sHash[i] %= MOD;
		pot *= p;
		pot %= MOD;
	}
}

ll subHash(int i, int j) {
	if(i == 0) return sHash[j];
	return ((sHash[j] - sHash[i-1] + MOD) * inv[i]) % MOD;
}

ll stringHash(char *s) {
	int n = strlen(s);
	ll res = s[0] - 'a' + 1;
	ll pot = p;
	for(int i=1;i<n;i++) {
		res += (s[i] - 'a' + 1) * pot;
		res %= MOD;
		pot *= p;
		pot %= MOD;
	}
	return res;
}

int main () {

	char s[N];
	char pat[N];
	pre();
	int n;

	vector<int> res;
	while(scanf("%d", &n) != EOF) {
		scanf("%s %s", pat, s);
		res.clear();
		ll id1 = stringHash(pat);
		hashPre(s);
		int sz = strlen(s);
		for(int i=0;i+n-1<sz;i++) {
			if(subHash(i,i+n-1) == id1) {
				printf("%d\n", i);
			}
		}	
		printf("\n");

	}


	return 0;

}



