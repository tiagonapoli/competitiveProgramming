#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define fr(i,a,b) for(int i =a;i<b;i++)

bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define par(a) if(debug) printf("%d/%d\n", (a.first), (a.second))
#define separa() if(debug) cout << endl

#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>

const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

vector<pii> edges;

void add(int a, pii b) {
	edges.pb({a,b.fi});
	if(b.se != -1) edges.pb({a, b.se});
}

int main () {

	int n;
	
	vector<pii> a;
	cin >> n;

	int maxi = n%2 ? n-1 : n;
	for(int i=1;i<=maxi/2;i++) {
		a.pb({i, maxi-i+1});
		
	}

	if(n % 2) a.pb({n, -1});

	for(auto x : a) par(x);

	for(int i=0;i<a.size();i++) {
		for(int j=i+1;j<a.size();j++) {
			add(a[i].fi, a[j]);
			add(a[i].se, a[j]);
		}
	}


	printf("%d\n", (int)edges.size());
	for(auto i : edges) {
		printf("%d %d\n", i.fi, i.se);
	}

	return 0;

}



