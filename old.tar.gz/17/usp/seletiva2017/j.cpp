#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define printa(a) cout << #a << " = " << (a) << endl
bool debug = 1;
#define debug(args...) if(debug) fprintf(stderr,args)
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define frrs(i,a,b) for(int i = (a); i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100

ll dp[300][20][2];
int vn[25];
int vk[25];
ll n;

ll solve(int soma, int dig, int menor) {
    if(soma < 0) return 0;
    if(dig == 0 && soma == 0) return 1;
    if(dig == 0 && soma != 0) return 0;
    if(dp[soma][dig][menor] != -1) return dp[soma][dig][menor];
    ll res = 0;
    if(menor) {
        for(int i=0;i<=9;i++) {
            res += solve(soma-i,dig-1,1);
        }
    } else {
        res += solve(soma-vn[dig-1],dig-1,0);
        for(int i=0;i<vn[dig-1];i++) {
            res += solve(soma-i,dig-1,1);
        }
    }
    return dp[soma][dig][menor] = res;
}

ll k;
int kesimo() {
    
}

vector<int> resp;
void posicao(ll pos, int soma, int dig, bool menor) {
    if(dig == 0) return;
    ll sum = 0;
    if(menor) {
        for(int i=0;i<=9;i++) {
            if(sum+solve(soma-i,dig-1,1) >= pos) {
                resp.pb(i);
                posicao(pos-sum,soma-i,dig-1,1);
                return;
            } else sum += solve(soma-i,dig-1,1);
        }
    } else {
        for(int i=0;i<vn[dig-1];i++) {
            if(sum+solve(soma-i,dig-1,1) >= pos) {
                resp.pb(i);
                posicao(pos-sum,soma-i,dig-1,1);
                return;
            } else sum += solve(soma-i,dig-1,1);
        }
        resp.pb(vn[dig-1]);
        posicao(pos-sum,soma-vn[dig-1],dig-1,0);
        return;
    }
}

int main () {

    cin >> n >> k;

    ll a = n;
    for(int i=0;i<19;i++) {
        vn[i] = a % 10;
        a /= 10LL;
    }
    int sumk = 0;
    a = k;
    for(int i=0;i<19;i++) {
        vk[i] = a % 10;
        a /= 10LL;
        sumk += vk[i];
    }

    for(int i=19;i>=0;i--) {
        printf("%d",vn[i]);
    }
    printf("\n");
    
    for(int i=0;i<=20;i++) {
        for(int j=0;j<=2;j++) {
            dp[i][j][0] = dp[i][j][1] = -1LL;
        }
    }

    for(int i=0;i<=20;i++) {
        printf("soma: %d\n", i);
        for(int j=1;j<=2;j++) {
            for(int k=0;k<=1;k++) {
                printf("[%d][%d] = %lld\n", j,k,solve(i,j,k));
            }
            printf("\n");
        }
        printf("\n");
    }

    ll aux = k;
    int sumi;
    
    for(sumi=1;solve(sumi,2,0) < aux; sumi++) {
        aux -= solve(sumi,2,0);
        printf("[%d] %lld\n",sumi, solve(sumi,2,0));
    }
    printf("soma conhecida %d\n\n",sumi);
    posicao(aux,sumi,2,0);
    
    for(int i : resp) {
        printf("%d", i);
    }
    printf("\n");

    
    for(int i=0;i<=20;i++) {
        for(int j=0;j<=2;j++) {
            dp[i][j][0] = dp[i][j][1] = -1LL;
        }
    }
    for(int i=0;i<19;i++) {
        vn[i] = vk[i];
    }
    
    printf("%lld\n", solve(sumk,2,0));

}



