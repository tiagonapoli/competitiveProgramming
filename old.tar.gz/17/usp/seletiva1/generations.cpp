#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 70100


ii base[2*N];
vector<ii> seg[8*N];
vector<int> maxi[8*N];
ii v[N];
int n;

void build2(int idseg, int sz) {
    maxi[idseg][0] = 0;
    for(int i=1;i<=sz;i++) {
        maxi[idseg][i] = max(maxi[idseg][i], seg[idseg][i].se);
    }
}

void build(int id=1, int l=1, int r=n) {
    if(l == r) {
        if(seg[id].size() < 2) {
            seg[id].resize(2);
        }
        seg[id][1] = base[l];
        if(maxi[id].size() < 2) {
            maxi[id].resize(2);
        }
        build2(id,r-l+1);
        return;
    }
    int mid = (l+r)/2;
    build(id*2,l,mid);
    build(id*2+1,mid+1,r);
    if(seg[id].size() < r-l+2) { 
        seg[id].resize(r-l+2);
    }
    merge(seg[id*2].begin()+1, seg[id*2].begin()+1+(mid-l+1), seg[id*2+1].begin()+1, seg[id*2+1].begin()+1+(r-mid), seg[id].begin()+1);
    if(maxi[id].size() < r-l+2) {
        maxi[id].resize(r-l+2);
    }
    build2(id,r-l+1);
}


int query2(int a,int idseg) {
    return maxi[idseg][a];
}

int query(int a, int b, int fimvida, int id=1, int l=1, int r=n) {
    if(b < l || a > r) return 0;
    if(a <= l && b >= r) {
        int sz = r-l+1;
        int fim = upper_bound(seg[id].begin()+1, seg[id].begin()+1+sz, mk(fimvida,N+10))-seg[id].begin();
     //   printf("Query1 %d->%d [fimvida %d]\n", l,r,fimvida);
       // printf("query2 1->%d = %d\n",fim-1, query2(1,fim-1,id,1,1,r-l+1)); 
        return query2(fim-1, id); 
    }
    int mid = (l+r)/2;
    return max(query(a,b,fimvida,id*2,l,mid), query(a,b,fimvida,id*2+1,mid+1,r));
}

void print2(int id, int sz) {
    for(int i=1;i<=sz;i++) {
        printf("[%d] ", maxi[id][i]);
    }
    printf("\n");
}

void print(int id=1, int l=1, int r=n) {
    printf("[%d] %d->%d\n",id,l,r);
    for(int i=1; i<r-l+2; i++) {
        printf("%d/%d ", seg[id][i].fi, seg[id][i].se);
    }
    printf("\n");
    printf("MAXI %d\n", id);
    print2(id,r-l+1);
    if(l == r) {
        return;
    }
    int mid = (l+r)/2;
    print(id*2,l,mid);
    print(id*2+1,mid+1,r);
}

vector<int> adj[N];
ii tempos[N];
int pos = 0;
int pai[N];

int dfs(int x, int level) {
    
    tempos[x].fi = ++pos;
    base[pos].fi = v[x].fi;
    base[pos].se = level;
    
    for(int i : adj[x]) {
        if(i != pai[x]) {
            pai[i] = x;
            dfs(i,level+1);
        }
    }

    tempos[x].se = ++pos;
    base[pos].fi = v[x].fi;
    base[pos].se = level;
}

int NUM,T;
int main () {

    scanf("%d", &T);

    int ini;
    int a,b,c;
    while(T--) {
    
        scanf("%d", &NUM);
        n = 2*NUM;
        pos = 0;
        for(int i=1;i<=NUM;i++) {
            adj[i].clear();
        }

        for(int i=1;i<=NUM;i++) {
            scanf("%d %d %d", &a, &b, &c);
            a++;
            if(a == 0) {
                ini = i;
            } else {
                
                adj[a].pb(i);
            }
            v[i] = mk(b,c);
        }

        dfs(ini,0);
   /*     
        for(int i=1;i<=NUM;i++) {
            printf("i %d [%d->%d]\n", i,tempos[i].fi, tempos[i].se);
        }
        printf("\n");

        for(int i=1;i<=pos;i++) {
            printf("pos %d [%d][%d]\n", i, base[i].fi, base[i].se);
        }
        printf("\n");
*/
        build();
        print();

    //    printf("\n");

        for(int i=1; i<=NUM;i++) {
          //  printf("RESPOSTA %d\n", i);
            printf("%d ", query(tempos[i].fi, tempos[i].se, v[i].se)-base[tempos[i].fi].se);
        }
        printf("\n");

    }

}


