#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 80100

//PERCORRO O TEMPO
//A PERGUNTA QUE QUERO RESPONDER É
//QUANDO UM PAI MORRER, QUANTOS FILHOS DELE NASCERAM?
//PLANIFICO A ÁRVORE E PERCORRO OS TEMPOS
//QUANTO ALGUEM MORRER, VEJO OS QUANTOS FILHOS DELE ESTAO
//NASCIDOS

//tempo / [nascimento ou morte / quem sou]
map<int, vector<int>[2] > tempo;
int seg_plano[4*N];
ii interv[N];
ii v[N];
int n;
int res[N];
int lv[N];

int t;
vector<int> adj[N];
int pai[N];

void upd(int x, int val, int id=1, int l=1, int r=n) {
    if(l == r) {
        seg_plano[id] = val;
        return;
    }
    int mid = (l+r)>>1;
    if(x <= mid) {
        upd(x,val,id<<1,l,mid);
    } else upd(x,val,(id<<1)|1,mid+1,r);

    seg_plano[id] = max(seg_plano[id<<1], seg_plano[(id<<1)|1]);
}

int query(int a,int b, int id=1, int l=1, int r=n) {
    if(b < a) return 0;
    if(a > r || b < l) return 0;
    if(a <= l && b >= r) {
        return seg_plano[id];
    }
    int mid = (l+r)>>1;
    return max(query(a,b,id<<1,l,mid), query(a,b,(id<<1)|1,mid+1,r));
}

void build(int id=1, int l=1, int r=n) {
    if(l == r) {
        seg_plano[id] = 0;
        return;
    }
    int mid = (l+r)>>1;
    build(id<<1,l,mid);
    build((id<<1)|1,mid+1,r);
    seg_plano[id] = 0;
}

void dfs(int x, int level) {
    interv[x].fi = ++t;
    lv[x] = level;
    for(int i : adj[x]) {
        if(pai[x] != i) {
            pai[i] = x;
            dfs(i,level+1);
        }
    }
    interv[x].se = t;
}

int T;
int main () {

    scanf("%d", &T);

    while(T--) {
    
        scanf("%d", &n);
        t = 0;

        tempo.clear();
        for(int i=0;i<n;i++) {
            adj[i].clear();
        }

        int ini;
        int a;
        for(int i=0;i<n;i++) {
            scanf("%d %d %d", &a, &v[i].fi, &v[i].se);
            tempo[v[i].fi][0].pb(i);
            tempo[v[i].se][1].pb(i);
            if(a == -1) {
                ini = i;
            } else {
                adj[a].pb(i);
            }
        }

        dfs(ini,1);
        build();

       /* printf("level\n");
        for(int i=0;i<n;i++) {
            printf("[%d] = %d\n", i, lv[i]);
        }
        printf("\n");

        for(int i=0;i<n;i++) {
            printf("%d: %d->%d\n", i, interv[i].fi, interv[i].se);
        }
        printf("\n");*/

        for(auto it = tempo.begin(); it != tempo.end(); it++) {
          //  printf("Tempo %d\n", it->fi);
            for(int i : it->se[0]) {
           //     printf("%d [%d]/[%d]\n", 0, interv[i].fi, interv[i].se);
                upd(interv[i].fi, lv[i]);
            }
            for(int i : it->se[1]) {
                res[i] = query(interv[i].fi, interv[i].se) - lv[i];
            }

       /*     for(int k=1;k<=n;k++) {
                printf("[%d/%d] ", k, query(k,k));
            }
            printf("\n");*/
        }

        for(int i=0;i<n;i++) {
            printf("%d ", res[i]);
        }
        printf("\n");
      
    }

}


