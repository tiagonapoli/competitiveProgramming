#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 5000
#define M 10000


// Dinicão da massa
// Generico: O(V^2 E)
// BipMatch: O(V^(1/2) E)
// UnitCap: O(min{V^(2/3),E^(1/2)} E)

struct dinic {
    int hd[N], nx[M], to[M], ht[M], es;
    ll fl[M], cp[M];
    int n, src, snk;
    int dist[N], seen[N], visi[N], turn;
    int qi, qf, qu[N];

    inline void init () // antes de montar o grafo
    { es = 2; }

    inline void reset () {
        es = 2;
        memset(hd, 0, sizeof hd);
        memset(seen, 0, sizeof seen);
        memset(visi, 0, sizeof visi);
    }

    inline void connect (int i, int j, ll cap) {
 //       printf("%d-%d [%lld]\n", i, j, cap);
        nx[es] = hd[i]; hd[i] = es; to[es] = j; cp[es] = cap; fl[es] = 0; es++; 
        nx[es] = hd[j]; hd[j] = es; to[es] = i; cp[es] = fl[es] = 0; es++;
    }

    bool bfs () {
        turn++;
        qi = qf = 0;

        qu[qf++] = snk;
        dist[snk] = 0;
        seen[snk] = turn;

        while (qi < qf) {
            int u = qu[qi++];

            if (visi[u] == turn)
                continue;
            visi[u] = turn;

            for (int ed = hd[u]; ed; ed = nx[ed]) {
                if (cp[ed^1] == fl[ed^1])
                    continue;
                int v = to[ed];

                if (seen[v] == turn && dist[v] <= dist[u]+1)
                    continue;
                seen[v] = turn;
                dist[v] = dist[u]+1;
                qu[qf++] = v;
            }
        }

        return (seen[src] == turn);
    }

    ll dfs (int u, ll flw) {
        if (u == snk || flw == 0)
            return flw;

        for (int & ed = ht[u]; ed; ed = nx[ed]) {
            int v = to[ed];
            if (fl[ed] >= cp[ed] || seen[v] != turn || dist[v]+1 != dist[u])
                continue;
            if (ll ret = dfs(v, min(flw, cp[ed] - fl[ed]))) {
                fl[ed] += ret;
                fl[ed^1] -= ret;
                return ret;
            }
        }

        return 0;
    }

    ll debug () {
        for (int i = 0; i < n; i++){ 
            printf("%d:", i);
            for (int ed = hd[i]; ed; ed = nx[ed])
                printf(" %d[%lld/%lld]", to[ed], fl[ed], cp[ed]);
            printf("\n");
        }
    }

    ll maxflow () {
        ll res = 0;
        while (bfs()) {
            for (int i = 0; i < n; i++)
                ht[i] = hd[i];
            while (ll val = dfs(src, LLONG_MAX))
                res += val;
        }
        return res;
    }
};

int main () {

    int t;
    int n;

    int v[55];
    cin >> t;

    while(t--) {

        cin >> n;
        int sum = 0;
        for(int i=1;i<=n;i++) {
            cin >> v[i];
            sum += v[i];
        }
        dinic grafo;
        grafo.init();
        grafo.reset();
        int cnt = n+1;

        for(int i=1;i<=n;i++) {
            for(int j=i+1;j<=n;j++) {
                grafo.connect(0,cnt,1);
                grafo.connect(cnt,i,1);
                grafo.connect(cnt,j,1);
                cnt++;
            }
        }
        grafo.src = 0;
        grafo.snk = cnt;
        grafo.n = cnt+1;
        for(int i=1;i<=n;i++) {
            grafo.connect(i,cnt,min(n-1,v[i]));
        }   

        ll flow = grafo.maxflow();
        int res = 0;
      //  grafo.debug();
    //    printf("flow %lld\n", flow);
        for(int i=1;i<=n;i++) {
            res += v[i] - grafo.fl[grafo.hd[i]];
        }
        res += (n*(n-1)/2 - flow);
        cout << res << endl;

    }

}
