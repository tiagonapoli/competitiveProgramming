#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100

typedef ll T;

struct pt {

    T x,y;
    pt() {}
    pt(T a, T b) {x=a,y=b;}
    pt operator- (pt b) {
        pt res(x-b.x,y-b.y);
        return res;
    }
    bool operator< (const pt b) const {
        if(x == b.x) {
            return y < b.y;
        } else return x < b.x;
    }
    bool operator==(const pt b) const {return ((x == b.x) && (y == b.y));}
    void print() {printf("%lld %lld", x,y);}
};

T cross(pt a, pt b) {
    return a.x*b.y - a.y*b.x;
}

//Retorna a area do 'paralelogramo' com 'sinal'
//AB ^ AC = (B-A)^(C-A) = A^B + B^C + C^A
T area(pt a, pt b, pt c) {
    return cross(a,b) + cross(b,c) + cross(c,a);
}

T area2(pt a, pt b, pt c) {
    pt ab = b-a;
    pt ac = c-a;
    return abs(cross(ab,ac));
}

//Tira o cara do topo de up ou down se for fazer uma curva para esquerda (area positiva)
vector<pt> convex_hull(vector<pt> p) {
    vector<pt> up,dn;
    sort(p.begin(), p.end());
    
    up.pb(p[0]);
    up.pb(p[1]);
    //Tirar os colineares area >=
    for(int i=2;i<p.size();i++) {
        while(up.size() >= 2 && area(up[(int)up.size()-2],up[(int)up.size()-1],p[i]) >= 0) {
            up.pop_back();
        }
        up.pb(p[i]);
    }
    dn.pb(p[p.size()-1]);
    dn.pb(p[p.size()-2]);
    for(int i=p.size()-3;i>=0;i--) {
        while(dn.size() >= 2 && area(dn[(int)dn.size()-2],dn[(int)dn.size()-1],p[i]) >= 0) {
            dn.pop_back();
        }
        dn.pb(p[i]);
    }
    for(int i=1;i<dn.size();i++) {
        up.pb(dn[i]);
    }
    reverse(up.begin(), up.end());
    return up;
}

vector<pt> v;

int ts(pt a, pt b, int i, int f) {
    if(f - i <= 0) {
        return i;
    }
    int res = i;
    while(i < f) {
        int m = (i+f)/2;
        int ant = m-1;
        int prox = m+1;
        ant = max(ant,i);
        prox = min(prox,f-1);
        if(area2(a,b,v[res]) < area2(a,b,v[m])) {
            res = m;
        }
        if(area2(a,b,v[res]) < area2(a,b,v[ant])) {
            res = ant;
        }
        if(area2(a,b,v[res]) < area2(a,b,v[prox])) {
            res = prox;
        }
        if(area2(a,b,v[ant]) <= area2(a,b,v[m]) && area2(a,b,v[m]) <= area2(a,b,v[prox])) {
            i = m+1;
        } else f = m;
    }
    return res;
}

ll solve() {
    int a,b,c;
    int n = v.size();
    if(n <= 3) return 0LL;
    ll maxi = -1;
    for(int i=0;i<n;i++) {
        for(int j=i+1;j<n;j++) {
            a = ts(v[i],v[j],i,j);
            b = ts(v[i],v[j],j,n-1);
            c = ts(v[i],v[i],0,i); 
            if(area2(v[i],v[j],v[c]) > area2(v[i],v[j],v[b])) {
                b = c;
            }
            maxi = max(maxi, area2(v[i],v[j],v[a]) + area2(v[i],v[j],v[b]));
        }
    }
    return maxi;
}




int main () {

    int t;

    cin >> t;
    while(t--) {

        int n;
        cin >> n;
        pt x;
        v.clear();
        vector<pt> p;
        for(int i=0;i<n;i++) {
            cin >> x.x >> x.y;
            p.pb(x);
        }

        v = convex_hull(p);
        ll res = solve();
        if(res % 2LL == 1LL) {
            printf("%.1lf\n", res/2.0);
        } else printf("%lld\n", res/2);

    }

}
