#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100

bool vis[N][4];
int vizinho[N][4];
vector<ii> adj[N];
int obj;

int dfs(int ant, int now) {
    int ret = 1;
    if(now == obj) ret = 0;
   // printf("%d[%d] - ", ant,now);
    for(ii x : adj[now]) {
        if(x.fi == ant) {
            int id;
            //quero ver se vis[x.se][now] ja esta visitado
            for(int j=0;j<4;j++) {
                if(vizinho[x.se][j] == now) {
                    id = j;
                    break;
                }
            }
            if(vis[x.se][id] == 0) {
                vis[x.se][id] = 1;
                ret = min(ret, dfs(now,x.se));
            } 
        }
    }
    return ret;
}



int main () {

    int T;

    scanf("%d", &T);
    
    int n;
    while(T--) {
    
        scanf("%d %d", &n, &obj);    
        
        for(int i=1;i<=n;i++) {
            adj[i].clear();
            vis[i][0] = vis[i][1] = vis[i][2] = vis[i][3] = 0;
        }

        int a,b,c,d;
        for(int i=1;i<=n;i++) {
            scanf("%d %d %d %d", &a, &b, &c, &d);
            vizinho[i][0] = a;
            vizinho[i][1] = b;
            vizinho[i][2] = c;
            vizinho[i][3] = d;
            adj[i].pb(mk(a,c));
            adj[i].pb(mk(c,a));
            adj[i].pb(mk(b,d));
            adj[i].pb(mk(d,b));
        }

    /*    for(int i=1;i<=n;i++) {
            printf("[%d]: ", i);
            for(ii x : adj[i]) {
                printf("(%d,%d) ", x.fi,x.se);
            }
            printf("\n");
        }
        printf("\n");

        for(int i=1;i<=n;i++) {
            printf("[%d]: ", i);
            for(int j=0;j<4;j++) {
                printf("%d ", vizinho[i][j]);
            }
            printf("\n");
        }
        printf("\n");
     */   int res = 0;
        for(int i=1;i<=n;i++) {
            for(int j=0;j<4;j++) {
                if(vis[i][j] == 0) {
                    vis[i][j] = 1;
                    res += dfs(vizinho[i][j],i);
                    //printf("\n");
                }
            }
        }

       printf("%d\n", res/2); 


    }

}



