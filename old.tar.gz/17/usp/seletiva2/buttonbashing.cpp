#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100

//TEMOS UM GRAFO COM 3600 ESTADOS
//DE UM ESTADO PARA OUTRO TEMOS NO MAXIMO 16 ARESTAS
//BFS -> V+E = 3600 + 3600*16

int n,t;
int v[20];
int d[3650];
const int inf = 99999999;


void bfs() {
    queue<int> fila;
    for(int i=0;i<=3600;i++) {
        d[i] = inf;
    }
    d[0] = 0;
    fila.push(0);
    while(!fila.empty()) {
        int x = fila.front();
        fila.pop();
        for(int i=0;i<n;i++) {
            int p = x + v[i];
            if(p > 3600) p = 3600;
            if(p < 0) p = 0;
            if(d[p] == inf) { //nao visitei esse estado antes! COmo é bfs ja tenho certeza que tenho a resposta otima
                d[p] = d[x] + 1;
                fila.push(p);
            }
        }
    }
}


int main () {

    int T;
    cin >> T;
    while(T--) {

        cin >> n >> t;
        for(int i=0;i<n;i++) {
            cin >> v[i];
        }

        bfs();
        
        for(int i=t;i<=3600;i++) {
            if(d[i] < inf) {
                printf("%d %d\n", d[i], i-t);
                break;
            }
        }

    }

}



