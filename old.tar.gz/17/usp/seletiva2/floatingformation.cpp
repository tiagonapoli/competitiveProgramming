#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100

int grau[N];
int preso[N];
vector<int> adj[N];
int n,k;
priority_queue<int> res;
int d[N];
bool vis[N];

void dfs(int now, int ant) {
    vis[now] = 1;
    d[now] = 0;
    int id;
    for(int x : adj[now]) {
        if(x == ant) continue;
        if(vis[x] == 0 && preso[x] == 0) {
            dfs(x,now);
            if(d[now] < d[x]) {
                id = x;
                d[now] = d[x];
            }
        }
    }

    for(int x : adj[now]) {
        if(preso[x] || x == id || x == ant) continue;
        res.push(d[x]);
    }

    if(preso[now] && d[now] != 0) {
        res.push(d[now]);
        return;
    }
    d[now] += 1;
}



int main () {

    int m;
    int T;

    cin >> T;

    while(T--) {
        
        cin >> n >> m >> k;

        while(!res.empty()) res.pop();

        for(int i=0;i<=n;i++) {
            grau[i] = 0;
            adj[i].clear();
            preso[i] = 0;
            vis[i] = 0;
        }

        int a,b;
        for(int i=0;i<m;i++) {
            scanf("%d %d", &a, &b);
            adj[a].pb(b);
            adj[b].pb(a);   
            grau[a]++;
            grau[b]++;
        }

        queue<int> fila;
        for(int i=1;i<=n;i++) {
            if(grau[i] == 1) {
                fila.push(i);
            }
        }

        while(!fila.empty()) {
            int x = fila.front();
            fila.pop();
            for(int i : adj[x]) {
                grau[i]--;
                if(grau[i] == 1) fila.push(i);
            }
        }

        int aux = 0;
        for(int i=1;i<=n;i++) {
            if(grau[i] >= 2) {
                preso[i] = 1;
                aux++;
            }
        }

        for(int i=1;i<=n;i++) {
            if(preso[i] == 1 && vis[i] == 0) dfs(i,-1);
        }
       /* printf("grau\n");
        for(int i=1;i<=n;i++) {
            printf("%d[%d] ", i,grau[i]);
        }
        printf("\n");



        for(int i=1;i<=n;i++) {
            printf("%d[%d] ", i, preso[i]);
        }
        printf("\n");
        
        printf("d\n");
        for(int i=1;i<=n;i++) {
            printf("%d[%d] ", i, d[i]);
        }
        printf("\n");

        while(!res.empty()) {
            printf("%d\n", res.top());
            res.pop();
        }
*/

        while(k > 0 && !res.empty()) {
            aux += res.top();
            res.pop();
            k--;
        }

        printf("%d\n", n-aux);

    }

}



