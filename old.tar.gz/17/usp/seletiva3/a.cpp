#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#ifndef ONLINE_JUDGE
#define debug(args...) fprintf(stderr,args)
#else
#define debug(args...)
#endif //ONLINE_JUDGE
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 5500

vector<ll> a,bb;

ll l;
int s,m,d,b;
ll vs[N], vm[N], vd[N], vb[N];

ll bs(ll val) {
    ll aux = upper_bound(bb.begin(), bb.end(),val) - bb.begin();
    return aux;
}

int main () {

    
    scanf("%lld", &l);

    scanf("%d %d %d %d", &s, &m, &d, &b);
    
    while(l != 0 && s != 0 && m != 0 && d != 0 && b != 0) {

        for(int i=0;i<s;i++) {
            scanf("%lld", &vs[i]);
        }

        for(int i=0;i<m;i++) {
            scanf("%lld", &vm[i]);
        }

        for(int i=0;i<d;i++) {
            scanf("%lld", &vd[i]);
        }

        for(int i=0;i<b;i++) {
            scanf("%lld", &vb[i]);
        }

        ll aux;
        for(int i=0;i<s;i++) {
            for(int j=0;j<m;j++) {
                aux = vs[i] + vm[j];
                if(aux <= l) {
                    a.pb(aux);
                }
            }
        }

        for(int i=0;i<d;i++) {
            for(int j=0;j<b;j++) {
                aux = vd[i] + vb[j];
                if(aux <= l) {
                    bb.pb(aux);
                }
            }
        }

        sort(a.begin(), a.end());
        sort(bb.begin(), bb.end());
        ll res = 0;
        for(int i=0;i<a.size();i++) {
            res += bs(l-a[i]);
        }

        cout << res << endl;
        
        scanf("%lld", &l);

        scanf("%d %d %d %d", &s, &m, &d, &b);
        a.clear();
        bb.clear();
    }
}



