#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#ifndef ONLINE_JUDGE
#define debug(args...) fprintf(stderr,args)
#else
#define debug(args...)
#endif //ONLINE_JUDGE
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100

int sum;
bool f(int x) {
    int soma = 0;
    while(x > 0) {
        soma += x%10;
        x /= 10;
    }
    return (soma == (sum-1));
}

int main () {

    string s;

    cin >> s;

    while(s != "END") {
    
        sum = 0;
        int x = 0;
        int aux = 1;
        for(int i=((int)s.size()-1);i>=0;i--) {
            sum += (s[i]-'0');
            x += (s[i]-'0')*aux;
            aux *= 10;
        }
       
        int res = 0;
        for(int i=x-1;i>=0;i--) {
            if(f(i)) {
                res = i;
                break;
            }
        }

        cout << res << endl;

        cin >> s;
    }

}



