#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#ifndef ONLINE_JUDGE
#define debug(args...) fprintf(stderr,args)
#else
#define debug(args...)
#endif //ONLINE_JUDGE
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll int
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100

int n,m;
vector<pair<ii,ll> >e;
ll d[N];
ll inf = 100000000LL;

bool bellman() {

    for(int i=0;i<=n+5;i++) {
        d[i] = inf;
    }
    d[n+2] = 0;

    for(int i=0;i<=n;i++) {
        for(int j=0;j<e.size();j++) {
            d[e[j].fi.se] = min(d[e[j].fi.se], e[j].se + d[e[j].fi.fi]); 
        }
    }

    bool muda = 0;
    for(int j=0;j<e.size();j++) {
        if(d[e[j].fi.se] != min(d[e[j].fi.se], e[j].se + d[e[j].fi.fi])) {
            muda = 1;
            break;
        }
    }
    return muda == 0; //nao ha ciclo

}

int main () {

    cin >> n;

    while(n) {
        
        cin >> m;
        e.clear();

        int a,b,c;
        string op;

        for(int i=0;i<m;i++) {
            cin >> a >> b >> op >> c;
            b = a+b;
            a--;
            if(op == "gt") {
                c = -c;
                swap(a,b);
            }
            c--;
            e.pb(mk(mk(a,b),c)); 
            e.pb(mk(mk(n+2,a),0));
            e.pb(mk(mk(n+2,b),0));
        }
    
        if(bellman() == 1) {
            printf("lamentable kingdom\n");
        } else printf("successful conspiracy\n");

        cin >> n;
    }

}
