#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#ifndef ONLINE_JUDGE
#define debug(args...) fprintf(stderr,args)
#else
#define debug(args...)
#endif //ONLINE_JUDGE
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 1000100

int n;
vector<pair<int,ii> > event[4*N];
ii v[N];
ii seg[10*N];

bool intersect(int x1,int x2, int y1, int y2, int xx1, int xx2, int yy1, int yy2) {
    if(x1 > xx2 || x2 < xx1 || y1 > yy2 || y2 < yy1) {
        return 0;
    }
    return 1;
}

int query() {
    return seg[1].fi;
}

void upd(int a, int b, int x, int id, int l, int r) {
    if(a > r || b < l) return;
    if(a <= l && b >= r) {
        seg[id].se += x;
        if(seg[id].se == 0) {
            if(l == r) {
                seg[id].fi = 0;
            } else seg[id].fi = seg[id*2].fi + seg[id*2+1].fi;
        } else seg[id].fi = r-l+1;
        return;
    } 
    int mid = (l+r)/2;
    upd(a,b,x,id*2,l,mid);
    upd(a,b,x,id*2+1,mid+1,r);
    if(seg[id].se == 0) {
        seg[id].fi = seg[id*2].fi + seg[id*2+1].fi;
    } else seg[id].fi = r-l+1;
}



bool go(int t) {

    //debug("go [%d]\n",t);
    int s = t+1;
    for(int i=-t;i<=t;i++) {
        event[i+s].clear();
    }

    int x1,x2,y1,y2;
    int xx1,xx2,yy1,yy2;
    x1 = 1;
    y1 = 1;
    x2 = t + s;
    y2 = t + s;

    //debug("hm %d->%d  %d->%d\n",x1,x2,y1,y2);
    
    for(int i=0;i<n;i++) {
        xx1 = v[i].fi - t + s;
        xx2 = v[i].fi + t + s;
        yy1 = v[i].se - t + s;
        yy2 = v[i].se + t + s;
        //debug("%d->%d  %d->%d\n", xx1,xx2,yy1,yy2);
        if(intersect(xx1,xx2,yy1,yy2,x1,x2,y1,y2)) {
            //debug("add\n");
            event[max(x1,xx1)].pb(mk(-1,mk(max(y1,yy1), min(y2,yy2))));
            event[min(x2,xx2)].pb(mk(+1,mk(max(y1,yy1), min(y2,yy2))));
        }
    }

   // res=0 é pego
   // res=1 nao é pego
    bool res = 0;
    for(int i=x1;i<=x2;i++) {
        //debug("\n[%d]: ", i);
        int aberto = query();
        for(pair<int,ii> now : event[i]) {
            //add
            //debug("%d/%d->%d ", now.fi,now.se.fi,now.se.se);
            if(now.fi == -1) {
                upd(now.se.fi, now.se.se, 1,1,y1,y2);
            } else {
                upd(now.se.fi, now.se.se, -1,1,y1,y2);
            }
            aberto = max(aberto, query()); 
            //debug("qry[%d] ", query());
        }
        if(aberto < y2-y1+1) {
            res = 1;
        }
    }
    //debug("\nres %d\n",res);
    return res;
}


int bs() {
    int i,f;
    int mid;   
    i = 0;
    f = 2000001;
    while(f > i) {
        mid = (i+f)/2;
        //debug("%d->%d  [%d]\n", i,f,mid);
        if(go(mid)) {
            i = mid+1;            
        } else {
            f = mid;
        }
    }
    if(f == 2000001) return -1;
    return f;
}




int main () {

    cin >> n;
    int test = 1;
    while(n != -1) {

        for(int i=0;i<n;i++) {
           cin >> v[i].fi >> v[i].se; 
        }

        printf("Case %d: ", test++);
        int res = bs();
        if(res == -1) {
            printf("never\n");
        } else printf("%d\n", res);
        
        cin >> n;
    }

}



