#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#ifndef ONLINE_JUDGE
#define debug(args...) fprintf(stderr,args)
#else
#define debug(args...)
#endif //ONLINE_JUDGE
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 10000

ll n;
ll r[30];
ll qtd[30];

int M;
int x[N],y[N];
ll d[N], z[N];
ll inf = 10000000LL;

bool bellman() {

    for(int i=0;i<=30;i++) {
        d[i] = inf;
    }
    d[0] = 0;

    for(int i=0;i<=30;i++) {
        for(int j=0;j<M;j++) {
            d[y[j]] = min(d[y[j]], d[x[j]] + z[j]);
        }
    }

    bool resp = 1;
    for(int j=0;j<M;j++) {
        if(d[y[j]] != min(d[y[j]], d[x[j]] + z[j])) {
            resp = 0;
            break;
        }
    }
    return resp;
}

void addEdge(int a, int b, ll c) {
    x[M] = a;
    y[M] = b;
    z[M++] = c;
}

ll busca() {
    ll res = -1LL;
   // printf("n %d\n",n);
    for(ll k=n;k>=0;k--) {

        M = 0;

        //S(i) - S(i-1) <= qtd(i)
        for(int i=1;i<=24;i++) {
            addEdge(i-1,i,qtd[i]);           
        }

        //S(i) - S(i-1) >= 0
        //S(i-1) - S(i) <= 0
        for(int i=1;i<=24;i++) {
            addEdge(i,i-1,0LL);
        }

        //S(i) - S(i-8) >= R(i) ->
        //S(i-8) - S(i) <= -R(i)
        for(int i=8;i<=24; i++) {
            addEdge(i,i-8,-1LL*r[i]);
        }

        //S(24) = K
        //S(24)-S(0) <= K
        //S(24)-S(0) >= K -> S(0) - S(24) <= -K
        addEdge(0,24,k);
        addEdge(24,0,-1LL*k);

        //De 1 a 7 -> Quantos trabalham?
        //S(i) + K - S(16+i) >= R(i)
        //S(i) - S(16+i) >= R(i) - K
        //S(16+i) - S(i) <= K - R(i)
        for(int i=1;i<=7;i++) {
            addEdge(i,16+i,k-1LL*r[i]);
        }

        //printf("[%d] %d\n",k,bellman());
        if(bellman()) {
            res = k;
        } 
    }
    return res;
}


int main () {

    int t;
    cin >> t;
    while(t--){
        
        for(int i=1;i<=24;i++) {
            cin >> r[i];
            qtd[i] = 0;
        }

        cin >> n;
        int x;
        for(int i=0;i<n;i++) {
            cin >> x;
            qtd[x+1]++;
        }

        ll res = busca();
        if(res == -1LL) {
            printf("No Solution\n");
        } else cout << res << endl;

    }
}

