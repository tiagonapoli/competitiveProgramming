#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#ifndef ONLINE_JUDGE
#define debug(args...) fprintf(stderr,args)
#else
#define debug(args...)
#endif //ONLINE_JUDGE
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100

double t[N], v[N];
int n;
double go(double tempo) {
    double mini,maxi;
    double s;
    mini = maxi = v[0]*(tempo-t[0]);
    for(int i=0;i<n;i++) {
        s = v[i]*(tempo-t[i]);
        mini = min(s,mini);
        maxi = max(s,maxi);
    }
    return fabs(maxi-mini);
}


double ts(double i, double f) {
    int iter = 80;
    double m1,m2;
    while(iter--) {
        m1 = i + (f-i)/3.0;
        m2 = f - (f-i)/3.0;
        if(go(m1) < go(m2)) {
            f = m2;
        } else i = m1;
    }
  //  printf("[%lf]\n", i);
    return go(i);
}

int main () {

    scanf("%d", &n);

    while(n != 0) {

        double maxi = 0;
        for(int i=0;i<n;i++) {
            scanf("%lf %lf", &t[i], &v[i]);
            maxi = max(t[i],maxi);
        }
        printf("%lf\n", ts(maxi,1000100000));
        scanf("%d", &n);

    }
    

}



