#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#ifndef ONLINE_JUDGE
#define debug(args...) fprintf(stderr,args)
#else
#define debug(args...)
#endif //ONLINE_JUDGE
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 1000100

map<int,vector<int> > mais;
map<int,vector<int> > menos;
int n;
int v[N];

vector<int> adj[N];
bool vis[N];


int dfs(int now) {
    vis[now] = 1;
    int aux = now;
    for(int x :  adj[now]) {
        if(vis[x] == 0) {
            aux = max(aux,dfs(x));
        }
    }
    return aux;
}


int main () {

    scanf("%d", &n);

    while(n != 0) {
            
        mais.clear();
        menos.clear();

        for(int i=1;i<=n;i++) {
            adj[i].clear();
            vis[i] = 0;
            scanf("%d", &v[i]);
            mais[v[i]+i].pb(i);
            menos[v[i]-i].pb(i);
        }

        for(int i=1;i<=n;i++) {
            if(mais.find(i-v[i]) != mais.end()) {
                for(int x : mais[i-v[i]]) {
                    if(i > x) {
                        adj[i].pb(x);
                    }
                }
            }

            if(menos.find(-i-v[i]) != menos.end()) {
                for(int x : menos[-i-v[i]]) {
                    if(i < x){
                        adj[i].pb(x);
                    }
                }
            }   
        }

     /*   for(int i=1;i<=n;i++) {
            printf("%d: ", i);
            for(int x : adj[i]) {
                printf("%d ", x);
            }
            printf("\n");
        }
        printf("\n");
       */
        printf("%d\n", dfs(1)-1);
        scanf("%d", &n);

    }

}



