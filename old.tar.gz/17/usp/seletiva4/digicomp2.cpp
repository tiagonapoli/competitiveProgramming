#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#ifndef ONLINE_JUDGE
#define debug(args...) fprintf(stderr,args)
#else
#define debug(args...)
#endif //ONLINE_JUDGE
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 501100

ll dp[N];
ii adj[N];
int in[N];
ll n;
int m;
bool st[N];

int main () {
    

    cin >> n >> m;
    
    char c;
    int a,b;

    for(int i=1;i<=m;i++) {
        cin >> c >> a >> b;
        if(c == 'L') {
            st[i] = 0;
        } else st[i] = 1;
        adj[i] = mk(a,b);
        in[a]++;
        in[b]++;
    }

    dp[1] = n;
    queue<int> fila;

    for(int i=1;i<=m;i++) {
        if(in[i] == 0) {
            fila.push(i);
        }
    }

    int esq,dir;
    while(!fila.empty()) {
        int now = fila.front();
        fila.pop();
        if(now == 0) continue;
        esq = adj[now].fi;
        dir = adj[now].se;
        
        dp[esq] += dp[now]/2LL;
        dp[dir] += dp[now]/2LL;
        
        in[esq]--;
        in[dir]--;

        if(esq != dir) {
            if(in[esq] == 0) {
                fila.push(esq);
            }
            if(in[dir] == 0) {
                fila.push(dir);
            }
        } else {
            if(in[esq] == 0) {
                fila.push(esq);
            }
        }

        if(dp[now] % 2LL == 1) {
            if(st[now] == 0) {
                dp[esq]++;
            } else dp[dir]++;
        }
    }
    for(int i=1;i<=m;i++) {
     //   printf("%d %lld\n", i, dp[i]); 
        if((dp[i] % 2LL) == 1LL) {
            st[i] = !st[i];
        }
        if(st[i] == 0) {
            printf("L");
        } else printf("R");
    }
    printf("\n");
}



