#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#ifndef ONLINE_JUDGE
#define debug(args...) fprintf(stderr,args)
#else
#define debug(args...)
#endif //ONLINE_JUDGE
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100

int n;
ll s,t;
map<int,int> ori;
ll res[10001000];

ll gcd(ll a, ll b) {
    if(b == 0) return a;
    return gcd(b,a%b);
}

ll simula(int p) {
    map<int,int>::iterator now;
    ll res = 0;
    map<int,int> pos = ori;
    for(int i=0;i<n;i++) {
        now = pos.lower_bound(p);
        if(now == pos.end()) {
            res += s - p;
            now = pos.begin();
            res += now->fi;
         //   debug("atualiza %lld\n", res);
        } else {
            res += now->fi-p;
       //     debug("atualiza %lld\n", res);
        }
        p = now->fi;
        now->se--;
        if(now->se == 0) {
            pos.erase(now->fi);
        }
       // debug("pos=%d [%d]=%d  res = %lld\n", p, now->fi, now->se, res);
       // for(auto it = pos.begin(); it != pos.end(); it++) {
      //      debug("%d=%d\n", it->fi, it->se);
      //  }
      //  debug("\n");
        p += t;
        p %= s;
        res += t;
    }
    return res;
}

int main () {

    cin >> n >> s >> t;

    int a;
    for(int i=0;i<n;i++) {
        cin >> a;
        ori[a]++;
    }

    ll mini,maxi,media;
    media = 0;
    mini = 100000000000000000LL;
    maxi = -1LL;
    ll x;

    for(ii p : ori) {
        res[p.fi] = simula(p.fi);
    }

    int ant = (ori.rbegin())->fi;
    ant = (ant+1)%s;
    for(ii p : ori) {
        int i;
        for(i=ant; i != p.fi; i=(i+1)%s) {
            res[i] = res[p.fi];
            if(i > p.fi) {
                res[i] += s - i + p.fi;
            } else res[i] += p.fi-i;
        }
        ant = (i+1)%s;
    }

    for(int i=0;i<s;i++) {
       // printf("%d %lld\n", i, res[i]);
        mini = min(mini,res[i]);
        maxi = max(maxi,res[i]);
        media += res[i];
    }

    

    ll mdc = gcd(max(media,s), min(media,s));
    media /= mdc;
    s /= mdc;


    cout << mini << endl << maxi << endl;
    printf("%lld/%lld\n",media,s);
}



