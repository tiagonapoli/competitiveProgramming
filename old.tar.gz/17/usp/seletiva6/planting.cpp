#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#ifndef ONLINE_JUDGE
#define debug(args...) fprintf(stderr,args)
#else
#define debug(args...)
#endif //ONLINE_JUDGE
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100

int v[N];
int n;


int main () {

    cin >> n;

    for(int i=0;i<n;i++) {
        cin >> v[i];
    }

    sort(v,v+n, greater<int>());

    int dia = 0;
    for(int i=0;i<n;i++) {
        dia = max(dia, v[i]+i+1);
    }

    printf("%d\n", dia+1);

}



