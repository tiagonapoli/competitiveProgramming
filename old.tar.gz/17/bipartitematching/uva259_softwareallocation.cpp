#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define printa(a) cout << #a << " = " << (a) << endl
bool debug = 1;
#define debug(args...) if(debug) fprintf(stderr,args)
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define frrs(i,a,b) for(int i = (a); i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100

vector<int> adj[N];
int match[N], dist[N];
int inf = 999999;
int m;

bool bfs() {
    queue<int> fila;
    for(int i=1;i<=10;i++) {
        dist[i] = inf;
        if(match[i] == 0) {
            dist[i] = 0;
            fila.push(i);
        }
    }
    dist[0] = inf;
    while(!fila.empty()) {
        int u = fila.front();
        fila.pop();
        for(int v : adj[u]) {
            if(dist[match[v]] == inf) {
                dist[match[v]] = dist[u] + 1;
                fila.push(match[v]);
            }
        }
    }
    return (dist[0] != inf);
}

bool dfs(int u) {
    if(u == 0) return true;
    for(int v : adj[u]) {
        if(dist[match[v]] == dist[u] + 1) {
            if(dfs(match[v])) {
                match[u] = v;
                match[v] = u;
                dist[u] = inf;
                return true;
            }
        }
    }
    dist[u] = inf;
    return false;
}

int bpm() {
    for(int i=0;i<=10+m+5;i++) {
        match[i] = 0;
    }

    int res = 0;
    while(bfs()) {
        for(int i=1;i<=10;i++) {
            if(match[i] == 0 && dfs(i)) {
                res++;
            }
        }
    }
    return res;
}  

map<int, char> dicio;

bool fim = 0;
void readAndSetup() {
    
    for(int i=1;i<=20;i++) {
        adj[i].clear();
    }
    dicio.clear();

    m = 10;
    string s;
    int n;
    char app;
    while(true) {
        if(scanf("%c", &app) == EOF) {
            fim = 1;
            break;
        }
       
        if(app == '\n') break;

        scanf("%d", &n);
        cin >> s;
        for(int j=0;j<n;j++) {
            m++;
            dicio[m] = app;
            for(int i=0;i<s.size()-1;i++) {
                adj[s[i]-'0'+1].pb(m);
            }
        }
        scanf("%*c");
    }
}

int main () {

    while(fim == 0) {
        readAndSetup();
        if(bpm() == (m-10)) {
            for(int i=1;i<=10;i++) {
                if(match[i] == 0) {
                    printf("_");
                } else printf("%c", dicio[match[i]]);
            }
        } else printf("!");
        printf("\n");
    }


}



