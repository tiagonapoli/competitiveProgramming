#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define debug(args...) if(debug) fprintf(stderr,args)
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define frrs(i,a,b) for(int i = (a); i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

int n;
int x[N], y[N];
set<int> asd;

int main () {
	
	cin >> n;

	for(int i=0;i<n;i++) {
		cin >> x[i];
		asd.insert(x[i]);
	}

	fr(i,n) {
		cin >> y[i];
		asd.insert(y[i]);
	}

	int cnt =0 ;
	for(int i=0;i<n;i++) {
		for(int j=i+1;j<n;j++) {
			if(asd.find(x[i] xor y[j]) != asd.end()) {
				cnt++;
			}
		}
	}

	prin(cnt);

	if(cnt % 2 == 0) {
		cout << "Karen" << endl;
	} else cout << "Koyomi" << endl;


	return 0;

}



