#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define debug(args...) if(debug) fprintf(stderr,args)
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define frrs(i,a,b) for(int i = (a); i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 998244353LL
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100


int main () {

	ll a,b;

	cin >> a >> b;

	a++;
	ll res = 1;
	while(a <= b and res != 0) {
		res *= (a % 10);
		res %= 10;
		a++;
	}

	cout << res << endl;

	return 0;

}



