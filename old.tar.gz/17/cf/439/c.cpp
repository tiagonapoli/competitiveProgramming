#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define debug(args...) if(debug) fprintf(stderr,args)
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define frrs(i,a,b) for(int i = (a); i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
const ll MOD =  998244353LL;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

ll escolhe[5010][5010];
ll f[5010][5010];

void pre() {
	
	escolhe[0][0] = 1;
	escolhe[1][0] = 1;
	escolhe[1][1] = 1;
	for(int n=1;n<=5002;n++) {
		escolhe[n][0] = 1;
		for(int k=1;k<n;k++) {
			escolhe[n][k] = escolhe[n-1][k] + escolhe[n-1][k-1];
			escolhe[n][k] %= MOD;
		}
		escolhe[n][n] = 1;
	}

	for(ll b=1;b<=5002;b++) {
		f[0][b] = 1;
		for(ll k=1;k<=b;k++) {
			f[k][b] = f[k-1][b] * (b-k+1LL);
			f[k][b] %= MOD;
		}
	}

}

ll fat(ll k, ll b) {
	return f[k][b];
}

int main () {
	
	ll a,b,c;

	pre();

	cin >> a >> b >> c;
	

	ll ab = 0;
	for(int k=0;k<=min(a,b);k++) {
		ll res = 1;
		res *= escolhe[min(a,b)][k];
		res %= MOD;
		res *= fat(k,max(a,b));
		res %= MOD;
		ab += res;
		ab %= MOD;
	}

	ll bc = 0;
	for(int k=0;k<=min(b,c);k++) {
		ll res = 1;
		res *= escolhe[min(b,c)][k];
		res %= MOD;
		res *= fat(k,max(b,c));
		res %= MOD;
		prin(res);
		bc += res;
		bc %= MOD;
	}

	ll ca = 0;
	for(int k=0;k<=min(c,a);k++) {
		ll res = 1;
		res *= escolhe[min(c,a)][k];
		res %= MOD;
		res *= fat(k,max(c,a));
		res %= MOD;
		ca += res;
		ca %= MOD;
	}

	prin(ab);
	prin(bc);
	prin(ca);
	ll res = (ab*bc)%MOD;
	res *= ca;
	res %= MOD;

	cout << res << endl;

	return 0;

}



