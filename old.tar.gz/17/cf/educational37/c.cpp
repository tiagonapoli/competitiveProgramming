#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 200100

int v[N];
int volta[N], vai[N];
int main () {

	int n;
	cin >> n;
	for(int i=0;i<n;i++) {
		cin >> v[i];
	}

	string s;

	cin >> s;

	int pos = 0;
	for(int i=0;i<n;i++) {
		volta[i] = pos;
		if(s[i] == '0') {
			pos = i + 1;
		}
	}

	pos = n-1;
	for(int i=n-1;i>=0;i--) {
		if(s[i] == '0') {
			pos = i;
		}
		vai[i] = pos;
	}

	int qtd = 0;
	for(int i=0;i<n;i++) {
		if(volta[i] <= v[i]-1 and v[i]-1 <= vai[i]) {
			qtd++;
		}	
	}
/*
	for(int i=0;i<n;i++) {
		printf("[%d/%d] ", volta[i], vai[i]);
	}
	cout << endl;
*/
	if(qtd == n) {
		printf("YES\n");
	} else printf("NO\n");

	return 0;

}



