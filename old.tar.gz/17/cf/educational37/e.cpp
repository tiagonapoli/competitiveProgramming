#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 200100

set<int> adj[N];
set<int> falta;
int cnt = 0;
vector<int> res;

void bfs(int x){
	queue<int> fila;
	fila.push(x);
	falta.erase(x);
	int ret = 0;
	while(!fila.empty()) {
		int now = fila.front();
		ret++;
		prin(now);
		prin(cnt);
		separa();
		fila.pop();
		set<int> aux = falta;
		for(int x : falta) {
			if(adj[now].find(x) == adj[now].end()) {
				fila.push(x);
				aux.erase(x);
			}
		}
		falta = aux;
	}
	res.pb(ret);
}

int main () {
	
	int n,m;

	scanf("%d %d", &n, &m);

	vector<int> itera;
	for(int i=1;i<=n;i++) {
		falta.insert(i);
		itera.pb(i);
	}

	int a,b;
	for(int i=0;i<m;i++) {
		scanf("%d %d", &a, &b);
		adj[a].insert(b);
		adj[b].insert(a);
	}

	random_shuffle(itera.begin(), itera.end());
	for(int i : itera) {	
		if(falta.find(i) != falta.end()) {
			bfs(i);
			cnt++;
		}
	}
	
	sort(res.begin(), res.end());
	cout << cnt << endl;
	for(int x : res) {
		printf("%d ", x);
	}
	cout << endl;


	return 0;

}



