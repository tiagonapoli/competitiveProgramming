#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

priority_queue <ii, vector<ii>, greater<ii> > heap;
int v[N];

int main () {

	int n,k;
	cin >> n >> k;

	for(int i=0;i<n;i++) {
		cin >> v[i];
		if(v[i] == 100) continue;
		heap.push({10 - (v[i] % 10), i});
	}

	while(!heap.empty() and k > 0) {
		ii now = heap.top();
		heap.pop();
//		prin(now.fi);
		v[now.se] += min(now.fi,k); 
		k -= min(now.fi,k);
		if(v[now.se] < 100) {
			heap.push({10,now.se});
		}
	}
/*
	prin(k);
	for(int i=0;i<n;i++) {
		printf("%d ", v[i]);
	}
	separa();
*/
	int res =0 ;
	for(int i=0;i<n;i++) {
		res += v[i]/10;
	}

	cout << res << endl;

	
	

	return 0;

}



