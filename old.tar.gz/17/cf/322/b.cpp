#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

int n;
int v[N];
int main () {
	
	cin >> n;

	int maxi[N];
	for(int i=0;i<n;i++) {
		cin >> v[i];
	}

	maxi[n] = 0;
	for(int i=n-1;i>=0;i--) {
		maxi[i] = max(v[i],maxi[i+1]);
	}

	int aux = 0;
	for(int i=0;i<n;i++) {
		if(maxi[i] == v[i]) {
			if(maxi[i+1] == v[i]) {
				printf("%d ", 1);
			} else printf("0 ");
		} else printf("%d ", maxi[i] - v[i] + 1);
	}

	cout << endl;


	return 0;

}



