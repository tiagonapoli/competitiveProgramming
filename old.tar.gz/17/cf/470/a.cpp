#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 600

char grid[N][N];

void wolf(int x, int y) {
	if(grid[x][y] == 'W') {
		printf("No\n");
		exit(0);
	} 
	if(grid[x][y] != 'S') grid[x][y] = 'D';
}

int main () {

	int a,b;

	cin >> a >> b;
	
	for(int i=0;i<=a+1;i++) {
		for(int j=0;j<=b+1;j++) {
			grid[i][j] = '.';
		}
	}

	for(int i=1;i<=a;i++) {
		for(int j=1;j<=b;j++) {
			scanf(" %c", &grid[i][j]);
		}
	}

	for(int i=1;i<=a;i++) {
		for(int j=1;j<=b;j++) {
			if(grid[i][j] == 'S') {
				wolf(i+1,j);
				wolf(i-1,j);
				wolf(i,j+1);
				wolf(i,j-1);
			}
		}
	}

	printf("Yes\n");
	for(int i=1;i<=a;i++) {
		for(int j=1;j<=b;j++) {
			printf("%c", grid[i][j]);
		}
		printf("\n");
	}

	return 0;

}



