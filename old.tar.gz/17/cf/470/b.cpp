#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

vector<int> fact(int x) {
	vector<int> p;
	for(int i=2;i*i<=x and x > 1;i++) {
		if(x % i == 0) {
			p.pb(i);
			while(x % i == 0) x /= i; 
		}
	}

	if(x > 1) p.pb(x);
	return p;
}

int main () {

	int x2,x1,x0;

	cin >> x2;
	int mini = 99999999;

	vector<int> f2 = fact(x2);
	for(int p2 : f2) {
		prin(p2);
		for(int x1=x2-p2+1;x1 <= x2; x1++) {
			prin(x1);
			if(x1 <= 3) continue;
			vector<int> f1 = fact(x1);
			if(f1.size() == 1 and x1/f1[0] == 1) continue;
			prin(f1.back());
			prin(x1 - f1.back() + 1);
			mini = min(mini, x1-f1.back() + 1);
			separa();
		}
	}
	

	cout << mini << endl;
	return 0;

}



