#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

int h1,h2,a1,a2;

int main () {

	int c;
	cin >> h1 >> a1 >> c;
	cin >> h2 >> a2;

	vector<string> res;
	while(h2 > 0) {
		if(h2 - a1 <= 0 or h1 - a2 > 0) {
			res.pb("STRIKE");
			h2 -= a1;
		} else {
			res.pb("HEAL");
			h1 += c;
		}
		h1 -= a2;
	}

	cout << res.size() << endl;
	for(string s : res) {
		cout << s << endl;
	}


	

	return 0;

}



