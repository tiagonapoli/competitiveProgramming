#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 200100

ll v[N];
ll sum[N];
map<ll, vector<int> > pos;
ll n;

ll check() {
	ll res = 0;
	for(int i=1;i<=n;i++) {
		for(int j=i;j<=n;j++) {
			if(abs(v[j]-v[i]) > 1) {
				res += v[j] - v[i];
			}
		}
	}
	return res;
}

int main () {
	cin >> n;
	for(int i=1;i<=n;i++) {
		cin >> v[i];
		pos[v[i]].pb(i);
	}

	sum[0] = 0;
	for(int i=1;i<=n;i++) {
		sum[i] = sum[i-1] + v[i];
	}

	long double res = 0;
	for(ll i=1;i<=n;i++) {
		res += sum[n] - sum[i];
		res -= v[i] * (n-i);
	}


	
	for(int i=1;i<=n;i++) {
		ll ant = v[i]-1;
		ll prox = v[i]+1;
		if(pos.find(ant) != pos.end()) {
			//+1
			res += (long double)(pos[ant].end() - lower_bound(pos[ant].begin(), pos[ant].end(), i));
		}
		if(pos.find(prox) != pos.end()) {
			//-1
			res -= (long double)(pos[prox].end() - lower_bound(pos[prox].begin(), pos[prox].end(), i));
		}
	}

	printf("%.0Lf\n", res);
/*
	if(check() != res) {
		printf("DEU RUIM\n");
	} else cout << "deu bom" << endl;
*/
	return 0;

}



