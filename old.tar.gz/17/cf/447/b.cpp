#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100


ll expo(ll b, ll e) {
	ll res = 1;
	while(e != 0) {
		if(e % 2 == 1) {
			res *= b;
			res %= MOD;
		}
		b *= b;
		b %= MOD;
		e /= 2LL;
	}
	return res;
}

int main () {
	
	ll n,m,k;

	cin >> n >> m >> k;

	ll res = expo(2LL,n-1LL);
	res = expo(res,m-1LL);


	cout << res << endl;


	return 0;

}



