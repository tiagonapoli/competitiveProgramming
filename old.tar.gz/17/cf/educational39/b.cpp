#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

pair<ll,ll> f(ll a, ll  b) {
	if(a == 0 or b == 0) return {a,b};
	if(a >= 2*b) {
		a %= 2*b;
	} else if(b >= 2*a) {
		b %= 2*a;
	} else return {a,b};
	return f(a,b);
}

int main () {
	
	ll a,b;
	cin >> a >> b;
	
	pair<ll,ll> res = f(a,b);

	printf("%lld %lld\n", res.fi, res.se);

	return 0;

}



