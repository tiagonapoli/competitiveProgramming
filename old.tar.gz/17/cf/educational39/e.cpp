#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100


string s;

vector<int> pilha;

bool solve(int pos, bool menor, set<int> impar) {
/*
	prin(pos);
	printf("impar: ");
	for(int x : impar) {
		printf("%d ", x);
	}
	separa();
	printf("Stack: ");
	for(int x : pilha) {
		printf("%d", x);
	}
	separa();
	prin(menor);
	separa();
*/
	if(pos >= 1 and pilha[0] == 0) return 0;
	
	if (pos == s.size() and (menor == 0 or impar.size() != 0)) {
		return 0;
	}

	if((int)impar.size() + pos - 1 > (int)s.size()) {
		return 0;
	}

	if(menor) {
		vector<int> res;
		for(int x : impar) {
			res.pb(x);
			pos++;
		}
		while(pos < s.size()) {
			res.pb(9);
			pos++;
		}
		sort(res.begin(), res.end(), greater<int>());
		for(int x : res) {
			pilha.pb(x);				
		}
		
		for(int x : pilha) {
			printf("%d", x);
		}
		printf("\n");
		return 1;
	}


	for(int i=s[pos]-'0';i >= 0; i--) {
		bool res = 0;
		pilha.pb(i);
		if(impar.find(i) == impar.end()) {
			impar.insert(i);
			res = solve(pos+1, i != (s[pos]-'0'), impar);
			impar.erase(i);
			if(res == 1) return 1;
		} else {
			impar.erase(i);	
			res = solve(pos+1, i != (s[pos]-'0'), impar);
			impar.insert(i);
			if(res == 1) return 1;
		}
		pilha.pop_back();
	}
	return 0;
}

int main () {
	
	int t;

	scanf("%d", &t);

	while(t--) {
	
		s.clear();
		pilha.clear();
		char c;
		scanf(" %c", &c);
		while(c != '\n') {
			s.pb(c);
			scanf("%c", &c);
		}

		set<int> v;
		int n = s.size();
		if(n % 2 == 1) {
			n--;
			while(n--) {
				printf("9");
			}
			printf("\n");
		} else if(solve(0,0,v) == 0) {
			n -= 2;
			while(n--) {
				printf("9");
			}
			printf("\n");
		}


	}

	return 0;

}



