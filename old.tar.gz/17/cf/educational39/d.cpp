#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 510

ll best[N][N];
ll dp[N][N];
vector<ll> tempo[N];
int n;
ll inf = 100000000000LL;

int solve(int pos, int k) {
	if (pos == n) return 0;
	if (dp[pos][k] != -1) return dp[pos][k];
	ll ret = inf;
	int hasta = min(k, (int)tempo[pos].size());
	for(int i=0;i <= hasta;i++) {
		ret = min(ret, solve(pos+1, k-i) + best[pos][i]); 	 
	}
	return dp[pos][k] = ret;

}

int main () {
	
	int m,k;

	scanf("%d %d %d", &n, &m, &k);

	for(int i=0;i<n+5;i++) {
		for(int j=0;j<k+5;j++) {
			dp[i][j] = -1;
			best[i][j] = inf;
		}
	}

	for(int i=0;i<n;i++) {
		char c;
		for(int j=0;j<m;j++) {
			scanf(" %c", &c);
			if(c == '1') {
				tempo[i].pb(j);
			}
		}
	}

	for(int i=0;i<n;i++) {
		int hasta = min(k, (int)tempo[i].size());
		for(int j=0;j<=hasta;j++) {
			int pega = (int)tempo[i].size() - j;
			if (pega == 0) {
				best[i][j] = 0;
			} else {
				for(int l=0;l + pega - 1 < tempo[i].size();l++) {
					best[i][j] = min(best[i][j], tempo[i][l + pega - 1] - tempo[i][l] + 1);
				}
			}
		//	printf("best[%d][%d] = %lld\n", i, j, best[i][j]);
		}
	}

	cout << solve(0, k) << endl;	

	return 0;

}



