#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100

int dig[10];
int cnt = 0;
int f(int x) {
    if(x == 2) {
        dig[x]++;
    } else if(x == 3) {
        dig[x]++;
    } else if(x == 4) {
        dig[2]+= 2;
        dig[3]++;
    } else if(x == 5) {
        dig[x]++;
    } else if(x == 6) {
        dig[3]++;
        dig[5]++;
    } else if(x == 7) {
        dig[x]++;
    } else if(x == 8) {
        dig[2] += 3;
        dig[7]++;
    } else if(x == 9) {
        dig[3]+=2;
        dig[2]++;
        dig[7]++;
    }

}



int main () {

    int n;

    cin >> n;
    string s;

    cin >> s;

    for(int i=0;i<n;i++) {
        f(s[i] - '0');
    }

    for(int i=0;i<10;i++) {
        cnt += dig[i];
    }

    while(cnt--) {
        for(int i=9;i>=0;i--) {
            if(dig[i] != 0) {
                dig[i]--;
                printf("%d",i);
                break;
            }
        }
    }
    printf("\n");
    

}



