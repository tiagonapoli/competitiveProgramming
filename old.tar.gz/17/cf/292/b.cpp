#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100

bool stn[N];
bool stm[N];
int n,m;

int main () {

    cin >> n >> m;

    int a,b;

    cin >> a;

    for(int i=0;i<a;i++) {
        cin >> b;
        stn[b] = 1;
    }

    cin >> a;
    for(int i=0;i<a;i++) {
        cin >> b;
        stm[b] = 1;
    }
    

    for(int i=0;i<1000000;i++) {
        if(stn[i%n] == 1 || stm[i%m] == 1) {
            stn[i%n] = stm[i%m] = 1;
        }
    }

    for(int i=0;i<n;i++) {
        if(stn[i] == 0) {
            printf("No\n");
            return 0;
        }
    }

    for(int i=0;i<m;i++) {
        if(stm[i] == 0) {
            printf("No\n");
            return 0;
        }
    }

    printf("Yes\n");
}



