#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 2010

int n,m;
int g[N][N];
int v[N][N][5];
char res[N][N];
bool acaba = 0;
bool vis[N][N];

bool esquerda(int x, int y) {
    if(x-1 >= 0 && g[x-1][y] == 1) return 1;
    return 0;
}

bool direita(int x, int y) {
    if(x+1 < m && g[x+1][y] == 1) return 1;
    return 0;
}

bool cima(int x, int y) {
    if(y-1 >= 0 && g[x][y-1] == 1) return 1;
    return 0;
}

bool baixo(int x, int y) {
    if(y+1 < n && g[x][y+1] == 1) {
        return 1;
    }
    return 0;
}
bool check(int x, int y) {
    if(x < 0 || y < 0) return 0;
    if(x >= n || y >= m) return 0;
    return 1;
}

void calc(int x, int y) {
    if(check(x,y) == 0) return;
    if(g[x][y] == 0) return;
    v[x][y][0] = esquerda(x,y);
    v[x][y][1] = direita(x,y);
    v[x][y][2] = cima(x,y);
    v[x][y][3] = baixo(x,y);
    v[x][y][4] = 0;
    for(int i=0;i<4;i++) {
        v[x][y][4] += v[x][y][i];
    }
    if(v[x][y][4] == 0) {
        printf("Not unique\n");
        acaba = 1;
    }
}

    
queue<ii> fila;

void marca(int x, int y, int dir) {
    g[x][y] = 0;
    if(dir == 0) {
        if(esquerda(x,y)) {
            g[x-1][y] = 0;
            res[x-1][y] = '<';
            res[x][y] = '>';
        }
    } else if(dir == 1) {
        if(direita(x,y)) {
            g[x+1][y] = 0;
            res[x][y] = '<';
            res[x+1][y] = '>';
        }
    } else if(dir == 2) {
        if(cima(x,y)) {
            g[x][y-1] = 0;
            res[x][y-1] = 'v';
            res[x][y] = '^';
        }
    } else if(dir == 3) {
        if(baixo(x,y)) {
            g[x][y+1] = 0;
            res[x][y+1] = '^';
            res[x][y] = 'v';
        }
    }

    for(int i=x-2;i<=x+2;i++) {
        for(int j=x-2;j<=x+2;j++) {
            calc(x,y);
            if(vis[i][j] == 0) {
                if(g[i][j] == 0) {
                    printf("Not unique\n");
                    acaba = 1;
                    return;
                } else if(g[i][j] == 1) {
                    fila.push(mk(i,j));
                    vis[i][j] = 1;
                }
            }
        }
    }
}

void print() {
    for(int i=0;i<n;i++) {
        for(int j=0;j<m;j++) {
            printf("%d ", g[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}


int main () {

    scanf("%d %d", &n, &m);

    int cnt = 0;
    char c;
    for(int i=0;i<n;i++) {
        for(int j=0;j<m;j++) {
            scanf(" %c", &c);
            res[i][j] = c;
            if(c == '.') {
                g[i][j] = 1;
                cnt++;
            } else g[i][j] = 0;
        }
    }


    if(cnt % 2 == 1) {
        printf("Not unique\n");
        return 0;
    }

    
    for(int i=0;i<n;i++) {
        for(int j=0;j<m;j++) {
            if(g[i][j] == 0) continue;
            calc(i,j);
            if(v[i][j][4] == 0) {
                printf("Not unique\n");
                return 0;
            }
            if(v[i][j][4] == 1 && vis[i][j] == 0) {
                fila.push(mk(i,j));
                vis[i][j] = 1;
            }
        }
    }

    

    while(!fila.empty()) {
        ii now = fila.front();
        printf("%d %d\n", now.fi,now.se);
        fila.pop();
        if(v[now.fi][now.se][4] == 0) continue;
        for(int i=0;i<4;i++) {
            if(v[now.fi][now.se][i] == 1) {
                marca(now.fi,now.se,i);
                print();
                if(acaba) return 0;
            }
        }
    }

    for(int i=0;i<n;i++) {
        for(int j=0;j<m;j++) {
            if(g[i][j] == 1) {
                printf("Not unique\n");
                return 0;
            }
        }
    }

    for(int i=0;i<n;i++) {
        for(int j=0;j<m;j++) {
            printf("%c", res[i][j]);
        }
        printf("\n");
    }
    printf("\n");
    

    



}



