#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 200100

int pai[N];
int sz[N];
int v[N];
ii rg[N];

int find(int x) {
	if(pai[x] == x) return x;
	return pai[x] = find(pai[x]);
}

priority_queue<ii, vector<ii> > heap;

void join(int a, int b){
	a = find(a);
	b = find(b);
	if(a != b) {
		pai[b] = a;
		sz[a] += sz[b];
		sz[b] = 0;
		rg[a].fi = min(rg[a].fi, rg[b].fi);
		rg[a].se = max(rg[a].se, rg[b].se);
		heap.push({sz[a], a});
	}
}

void joinM(int a, int morto) {
	a = find(a);
	int b  = find(morto);
	pai[b] = a;
	rg[a].fi = min(rg[a].fi, rg[b].fi);
	rg[a].se = max(rg[a].se, rg[b].se);
}

bool morre[N];
int n;


void printa() {
	
	bool asd[N];
	for(int i=0;i<n;i++) {
		asd[i] = 0;
	}
	for(int i=0;i<n;i++) {
		int a = find(i);
		if(asd[a] == 0) {
			asd[a] = 1;
			printf("%d*%d [%d] ",v[a],sz[a],morre[a]);
		}
	}
	printf("\n\n");

}

int main () {


	cin >> n;

	for(int i=0;i<=n;i++) {
		pai[i] = i;
		sz[i] = 1;
		morre[i] = 0;
		rg[i].fi = rg[i].se = i;
	}

	for(int i=0;i<n;i++) {
		scanf("%d", &v[i]);
	}

	heap.push({sz[0],find(0)});
	for(int i=1;i<n;i++) {
		if(v[i] == v[i-1]) {
			join(i,i-1);
		} else heap.push({sz[i],find(i)});
	}

	int a,b;
	int res = 0;

//	printa();
	
	while(!heap.empty()) {
		ii now = heap.top();
		prin(now.fi);
		prin(now.se);

		heap.pop();
		int f = find(now.se);
		int t = sz[f];
		if(f == now.se and t == now.fi) {
			morre[f] = 1;

//			printf("DELETA %d->%d\n", f, v[f]);	

			res++;
			a = rg[f].fi - 1;
			b = rg[f].se + 1;
			if(a >= 0) {
				joinM(a,f);
			} else if(b < n) {
				joinM(b,f);
			}
			if(a >= 0 and b < n) {
				a = find(a);
				b = find(b);
				if(v[a] == v[b] and morre[a] == 0 and morre[b] == 0) {
					join(a,b);
				} else if(morre[a] == 1) {
					joinM(b,a);
				} else if(morre[b] == 1) {
					joinM(a,b);
				}
			} 
		}
	
//		printa();
	}

	cout << res << endl;

	return 0;

}



