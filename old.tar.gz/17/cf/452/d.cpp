#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100
#define MAXI 1000000

int main () {
	
	ll n;

	cin >> n;

	ll maxi = n + n-1LL;
	prin(maxi);

	int max9 = 0;
	ll num = 9;
	ll mul = 1;	
	for(int i=0;i<10;i++) {
		if(num <= maxi) {
			max9 = max9 + 1;
			mul *= 10;
		} else break;
		num *= 10LL;
		num += 9LL;
	}

	if(max9 == 0) {
		printf("%lld\n", n * (n-1)/2);
		return 0;
	}

	num /= 10LL;

	ll res = 0;
	for(ll i=0;i<=MAXI;i++) {
		ll x = mul * i + num;
		prin(x);
		ll b = min(n,x-1LL);
		ll a = max(1LL,x - n);
		if(a >= b) continue;
		res += (b - a + 1)/2;
		prin(a);
		prin(b);
		prin(res);
		separa();
	}
	

	cout << res << endl;



	return 0;

}



