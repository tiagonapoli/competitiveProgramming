#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

vector<int> res;
ll n;

void go() {
	ll sum = 0;
	printf("%d ", (int)res.size());
	for(int x : res) {
		sum += x;
		printf("%d ", x);
	}
	cout << endl;

	prin(sum);
	prin((n * (n+1)/2)/2);
	

}

int main () {

	cin >> n;

	if(n % 2 == 0) {
		if(n % 4 == 0) {
			cout << 0 << endl;
			for(ll i=1;i<=n/4;i++) {
				res.pb(i);
				res.pb(n-i+1);
			}
			go();
			return 0;
		}	
	} else {
		if((n+1) % 4 == 0) {
			cout << 0 << endl;
			res.pb(n);
			for(ll i=1;i<(n+1)/4;i++) {
				res.pb(i);
				res.pb(n-i);
			}
			go();
			return 0;
		}
	}
	

	cout << 1 << endl;
	ll sum = (ll)n * (ll)(n+1)/2LL;
	sum /= 2LL;
	for(int i=n;i>=1;i--) {
		if(i <= sum) {
			sum -= i;
			res.pb(i);
		}
		if(sum == 0) break;
	}

	go();



	return 0;

}



