#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

int size(int m, int ano) {
	if(m == 1 or m == 3 or m == 5 or m == 7 or m == 8 or m == 10 or m == 12) {
		return 31;
	} else if(m == 2) {
		if(ano % 400 == 0) return 29;
		if(ano % 4 == 0 and ano % 100 != 0) return 29;
		return 28;
	} else return 30;
}

ii prox(int m, int ano) {
	if(m == 12) {
		return {1,ano+1};
	}
	return {m+1,ano};
}

int v[N];
int n;
bool check(int m, int a) {
	for(int i=0;i<n;i++) {
		if(v[i] != size(m,a)) return 0;
		ii p = prox(m,a);
		m = p.fi;
		a = p.se;
	}
	return 1;
}

int main () {


	cin >> n;

	for(int i=0;i<n;i++) {
		cin >> v[i];
	}


	for(int i=0;i<5000;i++) {
		for(int j=1;j<=12;j++) {
			if(check(j,i)) {
				cout << "YES" << endl;
				return 0;
			}
		}
	}

	cout << "NO" << endl;
	


	return 0;

}



