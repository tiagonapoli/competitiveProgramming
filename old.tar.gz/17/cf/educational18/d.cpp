#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100

ll  maxi;

ll andar(char op, ll n) {
    int p;
    for(p=0;(1LL<<p) <= n; p++) {
        if(((1LL<<p)&n) != 0) {
            break;
        }
    }
    if(op == 'U') {
        if((1LL<<p) == (maxi/2LL+1LL)) return n;
        n -= (1LL<<p);
        if((n & (1LL<<(p+1))) == 0) {
            n += (1LL << (p+1));
        }
        return n;
    } else if(op == 'L') {
        if(p == 0) return n;
        return (n - (1LL<<p) + (1LL<<(p-1))); 
    } else {
        //rigth - seta a posicao logo apos o bit 1 menos significativo
        if(p == 0) return n;
        return n + (1LL<<(p-1));
    }
}

int main () {

    int q;

    cin >> maxi >> q;

    string s;
    ll ini;
    for(int i=0;i<q;i++) {
        cin >> ini >> s;
        for(int j=0;j<s.size();j++) {
            ini = andar(s[j],ini);

           // printf("[%c][%lld] -> ", s[j],ini);
            
        }
        printf("%lld\n", ini);
    }



}



