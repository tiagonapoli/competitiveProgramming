#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100

int v[200];


int main () {

    int n,k;

    cin >> n >> k;

    for(int i=0;i<n;i++) {
        v[i] = i+1;
    }

    int a;
    int ini = 0;
    for(int i=0;i<k;i++) {
        cin >> a;
        a = (ini+a)%n;
        printf("%d ",v[a]);
        v[a] = 0;

        bool ok = 0;
        for(int j=0;j<n;j++) {
            if(v[j] == 0) {
                if(ok == 0) ini = ((j==n-1) ? 0 : j);
                ok = 1;
                swap(v[j], v[j+1]);
            }
        }
        n--;
    }

}



