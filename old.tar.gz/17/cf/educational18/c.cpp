#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100

string s;
int n;
int v[N];
int dp[N][3];
bool uso[N][3];

void preenche() {
    for(int now=1;now<=n;now++) {

        for(int i=0;i<3;i++) {
            uso[now][i] = 0;
            dp[now][i] = dp[now-1][i];
        }

        if(dp[now][v[now]%3] == 0 && v[now] != 0) {
            dp[now][v[now]%3] = 1;
            uso[now][v[now]%3] = 1;
        }

        for(int i=0;i<3;i++) {
            int r = (v[now] + i) % 3;
            if(dp[now-1][i] != 0) {
                if(dp[now][r] < dp[now-1][i]+1) {
                    dp[now][r] = dp[now-1][i] + 1;
                    uso[now][r] = 1;
                }
            }
        }

       // printf("now %d[%d]: ",now,v[now]);
       // for(int i=0;i<3;i++) {
        //    printf("[%d][%d] ", dp[now][i], uso[now][i]);
        //}
        //printf("\n");
    }
}

void print(int now, int r) {
    if(now == 0) return;
    if(uso[now][r]) {
        print(now-1, (((r-v[now])%3)+3)%3);
        printf("%d", v[now]);
    } else print(now-1,r);

}

int main () {

    bool has0 = 0;

    cin >> s;

    int i=0;
    while(i < s.size() && s[i] == '0') {
        i++;
        has0 = 1;
    }

    for(;i<s.size();i++) {
        v[++n] = s[i] - '0';
        if(s[i] == '0') has0 = 1;
    }

    preenche();

    if(dp[n][0] == 0) {
        if(has0) {
            printf("0\n");
        } else printf("-1\n");
        return 0;
    } else print(n,0);
    printf("\n");
}
