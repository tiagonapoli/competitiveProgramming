#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-8;
#define N 100100

double a[N],b[N];
double p;
int n;
bool check(double t) {
    double sum = 0;
    for(int i=0;i<n;i++) {
        sum += max(0.0,a[i] * t - b[i]);//quanto gasta - quanto tinha = quanto precisa
    }
    //sum -> quanto precisa;
    //printf("tempo %lf\n", t);
    //printf("soma quanto precisa %lf quanto fornece %lf\n\n", sum,t*p);
    if(t*p >= sum-eps) return 1;
    //maior sum possivel -> a[i]*t 
    return 0;
}

double bs() {

    double i,f,m;
    i = 0.0;
    f = 1e11;
    clock_t now = clock();
    while((double)now/CLOCKS_PER_SEC < 1.8) {
        m = (f+i)/2.0;
       // printf("[%lf][%lf] - %lf\n", i,f,m);
        if(check(m) == 0) {
            f = m;
        } else i = m;
        now = clock();
    }
    return i;
}

int main () {

    
    clock_t t = clock();
    cin >> n >> p;

    for(int i=0;i<n;i++) {
        cin >> a[i] >> b[i];
    }

    double sum = 0;
    for(int i=0;i<n;i++) {
        sum += a[i];
    }   

    if(sum <= p) {
        printf("-1\n");
        return 0;
    }

    cout << bs() << endl;
}



