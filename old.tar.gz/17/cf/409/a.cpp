#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100


bool usado[N];
string s;

int main () {

    cin >> s;

    int cnt = 0;
    for(int i=0;i<s.size()-1;i++) {
        if(s[i] == 'V' && s[i+1] == 'K') {
            usado[i] = 1;
            usado[i+1] = 1;
            i++;
            cnt++;
        }
    }
    for(int i=0;i<s.size();i++) {
        if(s[i] == 'V' && usado[i] == 0 && i<s.size()-1 && usado[i+1] == 0) {
            cnt++;
            break;
        }
        if(s[i] == 'K' && usado[i] == 0 && i > 0 && usado[i-1] == 0) {
            cnt++;
            break;
        }
    }

    cout << cnt << endl;

    



}



