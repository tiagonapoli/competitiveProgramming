#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100



struct pt {
    
    double x,y;

    pt(){}
    pt(double a, double b) {x=a;y=b;}
    
    pt operator- (pt b) {
        pt res(x-b.x,y-b.y);
        return res;
    }

};


int n;
pt v[N];

double norma(pt a) {
    return hypot(a.x,a.y);
}

double cross(pt o, pt a, pt b) {
    pt oa = a - o;
    pt ob = b - o;
    return fabs(oa.x*ob.y - oa.y*ob.x); 
}

double dist(int x, int a, int b) {
    if(x == a || x == b) return 1e11;
    double res = cross(v[a],v[b],v[x])/norma(v[b]-v[a]);
    res /= 2.0;
    return res;
}

int main () {


    scanf("%d", &n);

    for(int i=0;i<n;i++) {
        scanf("%lf %lf", &v[i].x, &v[i].y);
    }

    double res;

    res = norma(v[1]-v[0])/2.0;
   // printf("res %lf\n", res);
    for(int i=0;i<n;i++) {
        res = min(res, norma(v[(i+1)%n]-v[i]));
   //     printf("res %lf\n", res);
    }

    for(int i=0;i<n;i++) {
        for(int j=0;j<n;j++) {
            if(i == j) continue;
            res = min(res, dist((i+1)%n,i,j));
            res = min(res, dist((i-1+n)%n,i,j));
            res = min(res, dist((j+1)%n,i,j));
            res = min(res, dist((j-1+n)%n,i,j));
        //    printf("[%d][%d] res %lf\n",i,j, res);
            
        }
    }
    printf("%.9lf\n", res);    
}



