#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 200100

ll sqr[N];
ll v[N];
vector<ii> dist;

bool cmp(ii a, ii b) {
	if(a.fi == b.fi) {
		return v[a.se] < v[b.se];
	} else return a.fi < b.fi;
}

int main () {

	for(ll i=0;i<33000;i++) {
		sqr[i] = i*i;
	}
	
	int n;

	cin >> n;

	for(int i=0;i<n;i++) {
		scanf("%lld", &v[i]);
		int pos = lower_bound(sqr,sqr+32000,v[i]) - sqr;
		prin(sqr[pos]);
		prin(pos);
		ll d = abs(sqr[pos]-v[i]);
		if(pos > 0) {
			d = min(d, abs(sqr[pos-1]-v[i]));
		}
//		printf("%lld -> %lld %d\n", v[i], d, i);
		dist.pb({d,i});
	}

	sort(dist.begin(), dist.end(), cmp);

	ll res = 0;
	for(int i=0;i<n/2;i++) {
		res += dist[i].fi;
	}
	for(int i=n/2;i<n;i++) {
		if(dist[i].fi == 0) {
			if(v[dist[i].se] == 0) {
				res += 2;
			} else res++;
		}
	}
	
	cout << res << endl;

	return 0;

}



