#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 200100


bool usado[N];
int v[N];
int main () {

	int k,n,m;

	cin >> n >> m >> k;

	for(int i=0;i<n;i++) {
		scanf("%d", &v[i]);
		usado[i] = 1;
	}

	sort(v,v+n);


	int res =0;

	separa();

	int ini = 0;
	int qtd = 0;
	for(int i=0;i<n;i++) {
		if(usado[i] == 0) continue;
		int j = ini;
		while(j < n and v[j] < v[i] + m) {
			if(usado[j]) qtd++;
			j++;
		}
		ini = j;

		while(qtd >= k) {
			if(usado[j-1]) {
				res++;
				qtd--;
			}
			usado[j-1] = 0;
			j--;
		}

		if(usado[i]) qtd--;
			
	}

	cout << res << endl;

	

	


	return 0;

}



