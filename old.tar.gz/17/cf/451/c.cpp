#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

map<string, vector<string> > v;
map<string, vector<bool> > print;

bool isSuffix(string &a, string &b) {
	if(a.size() > b.size()) return 0;
	int ini = b.size()-a.size();
	for(int i=0;i<a.size();i++) {
		if(b[ini+i] != a[i]) return 0;
	}
	return 1;
}

int main () {

	int n;

	cin >> n;

	int x;
	string s,name;
	for(int i=0;i<n;i++) {
		cin >> name;
		cin >> x;
		for(int j=0;j<x;j++) {
		print[name].resize(1000);
			cin >> s;
			v[name].pb(s);
		}
	}
	

	for(auto i = v.begin(); i != v.end(); i++) {
		sort(i->se.begin(), i->se.end());
		auto it = unique(i->se.begin(), i->se.end());
		i->se.resize(distance(i->se.begin(),it));
		for(int j=0;j< i->se.size();j++) {
			print[i->fi][j] = 1;
			for(int k=0;k< i->se.size();k++) {
				if(k == j) continue;
				if(isSuffix(i->se[j],i->se[k])) {
					print[i->fi][j] = 0;
				}
			}
		}
	}

	cout << v.size() << endl;
	
	for(auto i = v.begin(); i != v.end(); i++) {
		cout << i->fi << " ";
		int qtd = 0;
		for(int j=0;j< i->se.size();j++) {
			if(print[i->fi][j] == 1) qtd++;
		}
		printf("%d ", qtd);
		for(int j=0;j< i->se.size();j++) {
			if(print[i->fi][j] == 1) {
				cout << i->se[j] << " ";
			}
		}
		cout << endl;
	}

	return 0;

}



