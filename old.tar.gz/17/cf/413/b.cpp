#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#ifndef ONLINE_JUDGE
#define debug(args...) fprintf(stderr,args)
#else
#define debug(args...)
#endif //ONLINE_JUDGE
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 200100

set<int> cor[4];
int p[N],a[N],b[N];
int quer[N];

int main () {

    int n;

    cin >> n;

    for(int i=0;i<n;i++) {
        cin >> p[i];
    }

    for(int i=0;i<n;i++) {
        cin >> a[i];
    }

    for(int i=0;i<n;i++) {
        cin >> b[i];
    }

    for(int i=0;i<n;i++) {
        cor[a[i]].insert(p[i]);
        cor[b[i]].insert(p[i]);
    }

    int m;

    cin >> m;
    
    for(int i=0;i<m;i++) {
        cin >> quer[i];
    }


    int val;
    for(int i=0;i<m;i++) {
        if(cor[quer[i]].empty()) {
            printf("-1 ");
        } else {
            val = *cor[quer[i]].begin();
            cor[1].erase(val);
            cor[2].erase(val);
            cor[3].erase(val);
            printf("%d ", val);
        }
    }
    printf("\n");

}



