#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#ifndef ONLINE_JUDGE
#define debug(args...) fprintf(stderr,args)
#else
#define debug(args...)
#endif //ONLINE_JUDGE
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100

ii dp[2][N][2];

int c,d;
int n;
int inf = 1000000000;

vector<pair<int,ii> > coin;
vector<pair<int,ii> > dia;

int main () {

    cin >> n >> c >> d;

    for(int i=0;i<=100000;i++) {
        for(int j=0;j<2;j++) {
            for(int l=0;l<2;l++) {
                dp[j][i][l] = mk(-inf,-inf);
            }
        }
    }

    int beleza, cost;
    char caraca;
    int id;
    ii v[4];
    for(int i=0;i<n;i++) {
        cin >> beleza >> cost >> caraca;
        if(caraca == 'D') {
            id = 1;
            dia.pb(mk(i,mk(beleza,cost)));
        } else {
            id = 0;
            coin.pb(mk(i,mk(beleza,cost)));
        }
        v[0] = dp[id][cost][0];
        v[1] = dp[id][cost][1];
        v[2] = mk(beleza,i);
        sort(v,v+3,greater<ii>());
        dp[id][cost][0] = v[0];
        dp[id][cost][1] = v[1]; 
    }  

    for(int i=1;i<=100000;i++) {
        for(int j=0;j<2;j++) {
            v[0] = dp[j][i-1][0];
            v[1] = dp[j][i-1][1];
            v[2] = dp[j][i][0];
            v[3] = dp[j][i][1];
            sort(v,v+4, greater<ii>());
            dp[j][i][0] = v[0];
            dp[j][i][1] = v[1];
        }
    }

    /*debug("coin\n");
    for(int i=0;i<=10;i++) {
        debug("[%d]: [%d][%d]  [%d][%d]\n", i, dp[0][i][0].fi, dp[0][i][0].se, dp[0][i][1].fi, dp[0][i][1].se);
    }
    debug("\n");
    debug("diamond\n");
    for(int i=0;i<=10;i++) {
        debug("[%d]: [%d][%d]  [%d][%d]\n", i, dp[1][i][0].fi, dp[1][i][0].se, dp[1][i][1].fi, dp[1][i][1].se);
    }
    debug("\n");
*/
    
    
    int res = dp[1][d][0].fi + dp[0][c][0].fi;

    int aux = 0;
    
    ii a1,a2;
    for(int i=0;i<dia.size(); i++) {
        if(dia[i].se.se > d) continue;
        a1 = dp[1][d-dia[i].se.se][0];
        a2 = dp[1][d-dia[i].se.se][1];
        aux = dia[i].se.fi;
        id = dia[i].fi;
        if(a1.se == id) {
            aux += a2.fi;
        } else {
            aux += a1.fi;
        }
        res = max(res,aux); 
    }

    for(int i=0;i<coin.size(); i++) {
        if(coin[i].se.se > c) continue;
        a1 = dp[0][c-coin[i].se.se][0];
        a2 = dp[0][c-coin[i].se.se][1];
        id = coin[i].fi;
        aux = coin[i].se.fi;
        if(a1.se == id) {
            aux += a2.fi;
        } else {
            aux += a1.fi;
        }  
        res = max(res,aux);
   }
    cout << max(0,res) << endl;

}



