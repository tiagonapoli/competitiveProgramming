#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#ifndef ONLINE_JUDGE
#define debug(args...) fprintf(stderr,args)
#else
#define debug(args...)
#endif //ONLINE_JUDGE
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100

int n;
int v1[1000100];

int main () {

    int t,k,d;

    scanf("%d %d %d %d", &n, &t, &k, &d);

    int n1,n2;
    int t1,t2;

    if(n % k == 0) {
        t1 = (n/k)*t;
    } else {
        t1 = (n/k+1)*t;
    }

    //1 -> tira k soma t
    //2 -> tira 2k soma t

    n2 = n;
    v1[t] += -k;
    v1[d+t] += -k;
    for(t2=0;n2 > 0; t2++) {
      //  debug("[n2 %d][t %d][%d] ", n2,t2,v1[t2]);
        n2 += v1[t2];
        if(v1[t2] < 0) {
            v1[t2+t] += v1[t2];
        }
        if(n2 <= 0) break;
    }

    if(t1 <= t2) {
        printf("NO\n");
    } else printf("YES\n");
    debug("%d %d\n",t1, t2);
}
    
    
    

    


