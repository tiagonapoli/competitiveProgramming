#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define debug(args...) if(debug) fprintf(stderr,args)
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define frrs(i,a,b) for(int i = (a); i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

ll dp[20][180][2];
ll maxi;
int dig[20];
ll solve(int pos, int sum, bool menor) {
	if(sum < 0) return 0;
	if(pos == -1) {
		if(sum == 0) return 1;
		return 0;
	}
	if(dp[pos][sum][menor] != -1LL) return dp[pos][sum][menor];
	
	ll res = 0;
	if(menor == 0) {
		for(int i=0;i<dig[pos];i++) {
			res += solve(pos-1,sum-i,1);
		}
		res += solve(pos-1,sum-dig[pos],0);
	} else {
		for(int i=0;i<10;i++) {
			res += solve(pos-1, sum-i, 1);
		}
	}
	return dp[pos][sum][menor] = res;
}

void pre() {
	for(int i=0;i<=19;i++) {
		dig[i] = maxi % 10LL;
		maxi /= 10LL;
	}
}

int main () {
	
	ll n,s;

	cin >> n >> s;
	
	ll res = 0;
	for(ll i = 0;i < 180;i++) {
		maxi = min(n, s+i-1LL);
	//	prin(maxi);
	//	prin(i);
		pre();
		for(int j=0;j<20;j++) {
			for(int k=0;k<180;k++) {
				for(int l=0;l<2;l++) {
					dp[j][k][l] = -1LL;
				}
			}
		}
	//	prin(solve(18,i,0));
		res += solve(19,i,0);
	}

	res = (n - res + 1LL);

	cout << res << endl;

	return 0;

}



