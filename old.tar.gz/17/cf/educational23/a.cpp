#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define debug(args...) if(debug) fprintf(stderr,args)
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define frrs(i,a,b) for(int i = (a); i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100


int main () {

	int x2,y2,x1,y1;

	int x,y;
	int k1,k2;
	cin >> x1 >> y1 >> x2 >> y2;
	cin >> k1 >> k2;


	x = x2 - x1;
	y = y2 - y1;

	if(y % k2 != 0 or x % k1 != 0) {
		printf("NO\n");
		return 0;
	}

	int qtd = x/k1;

	y += qtd * k2;
	if(y % (2*k2) != 0) {
		printf("NO\n");
		return 0;
	}

	printf("YES\n");
	


	return 0;

}



