#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define debug(args...) if(debug) fprintf(stderr,args)
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define frrs(i,a,b) for(int i = (a); i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

map<ll,int> dicio;


int main () {

	int n;

	cin >> n;

	ll x;
	fr(i,n) {
		cin >> x;
		dicio[x]++;
	}

	ll mini = (dicio.begin())->fi;
	dicio[mini]--;
	if(dicio[mini] == 0) {
		dicio.erase(mini);
	}
	ll a,b;
	a = (dicio.begin())->fi;
	dicio[a]--;
	if(dicio[a] == 0) {
		dicio.erase(a);
	}
	b = (dicio.begin())->fi;
	dicio[b]--;

	ll prod = (ll) a * (ll) b;
	dicio[a]++;
	dicio[b]++;
	dicio[mini]++;
	ll res = 0;
	ll k1,k2,k3;
	k1 = dicio[mini];
	dicio[mini]--;
	int calc = 0;
	for(auto j = dicio.begin(); j != dicio.end(); j++){
		k2 = j->se;
		ll q = prod/j->fi;	
		if(q*j->fi != prod or q < j->fi) continue;
		j->se--;
		
		if(dicio.find(q) != dicio.end()) {
			k3 = dicio[q];
			if(mini == j->fi) {
				if(j->fi == q) {
					res += (k1*k2*k3)/6LL;
				} else res += (k1*k2*k3)/2LL;
			} else if(j->fi == q) {
				res += (k1*k2*k3)/2LL;
			} else res += (k1*k2*k3);
			calc = q + 1;
		}
		j->se++;
	}


	cout << res << endl;

	return 0;

}



