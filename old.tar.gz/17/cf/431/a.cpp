#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define printa(a) cout << #a << " = " << (a) << endl
bool debug = 1;
#define debug(args...) if(debug) fprintf(stderr,args)
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define frrs(i,a,b) for(int i = (a); i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100


int main () {

    int n;

    int v[N];
    
    cin >> n;
    int odd = 0;
    for(int i=0;i<n;i++) {
        cin >> v[i];
        if(v[i] == 1) odd++;
    }

    if(v[0] % 2 == 0) {
        printf("No\n");
        return 0;
    }
    if(v[n-1] % 2 == 0) {
        printf("No\n");
        return 0;
    }



    printf("Yes\n");

}



