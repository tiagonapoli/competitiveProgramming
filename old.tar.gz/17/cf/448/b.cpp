#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

int v[N];
int qtd[N];
map<int,int> dicio;

int main () {

	int n,x,k;

	scanf("%d %d %d", &n, &x, &k);

	for(int i=0;i<n;i++) {
		scanf("%d", &v[i]);
	}

	sort(v,v+n);
	for(int i=0;i<n;i++) {
		dicio[v[i]] = max(dicio[v[i]], i);
	}

	for(int i=0;i<n;i++) {
		qtd[i] = (v[i]-1)/x;
	}

	ll res = 0;
	for(int i=0;i<n;i++) {
		int qtos = qtd[i];
		if(v[i] % x == 0) qtos++;
		int obj = qtos - k;
		int pos = upper_bound(qtd,qtd+dicio[v[i]]+1,obj) - lower_bound(qtd,qtd+dicio[v[i]]+1,obj);
		prin(v[i]);
		prin(qtd[i]);
		prin(obj);
		prin(pos);
		separa();
		res += (ll) pos;
	}

	cout << res << endl;

	return 0;

}



