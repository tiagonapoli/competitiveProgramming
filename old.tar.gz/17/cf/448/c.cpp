#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

vector<int> prime;
bool composto[100];

void sieve(){
	for(int i=2;i<=70;i++) {
		if(composto[i] == 0) {
			prime.pb(i);
			for(int j=i;j<=70;j+=i) {
				composto[j] = 1;
			}
		}
	}
}

ll dp[1100000][2];
ll qtd[80];
ll rep[80];
ll pot[100100];

int setado(int mask, int i) {
	return ((1<<i) & mask) != 0;
}

int main () {

	sieve();

	prin(prime.size());
	for(int x : prime) {
		prin(x);
	}

	pot[0] = 1;
	for(int i=1;i<=100010;i++){
		pot[i] = pot[i-1] * 2LL;
		pot[i] %= MOD;
	}

	int n;

	scanf("%d" ,&n);

	int x;
	for(int i=0;i<n;i++) {
		scanf("%d", &x);
		qtd[x]++;
	}

	rep[1] = 0;
	for(int i=2;i<=70;i++) {
		int aux = i;
		for(int j=0;j<prime.size();j++) {
			while(aux % prime[j] == 0) {
				aux /= prime[j];
				rep[i] ^= (1 << j);
			}
		}
	}

	for(int i=1;i<=20;i++) {
		prin(i);
		for(int j=0;j<=6;j++) {
			printf("%d", setado(rep[i],j));
		}
		separa();
	}
	
	
	for(int i=1;i<=70;i++) {
		prin(i);
		for(int j=0;j<(1<<20);j++) {
			if(qtd[i] == 0) {
				dp[j][i%2] = dp[j][(i+1)%2];
			} else dp[j][i%2] = 0;
		}
		if(qtd[i] == 0) continue;

		//Eu sozinho -> IMPAR
		dp[rep[i]][i%2] += pot[qtd[i]-1];
		dp[rep[i]][i%2] %= MOD;

		//EU sozinho -> PAR
		dp[0][i%2] += (pot[qtd[i]-1] - 1LL + MOD) % MOD;
		dp[0][i%2] %= MOD;

		for(int j=0;j<(1<<20);j++) {
			//prin(j);
			//QTD IMPAR DE CARAS
			dp[j xor rep[i]][i%2] += (dp[j][(i+1)%2] * pot[qtd[i]-1]) % MOD;
			dp[j xor rep[i]][i%2] %= MOD;
			
			//QTD PAR DE CARAS
			dp[j][i%2] += (dp[j][(i+1)%2] * pot[qtd[i]-1]) % MOD;
			dp[j][i%2] %= MOD;
		}
	}

	cout << dp[0][70%2] << endl;

	
	


	return 0;

}



