#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define debug(args...) if(debug) fprintf(stderr,args)
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define frrs(i,a,b) for(int i = (a); i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100


int main () {

    int n,x;

    cin >> n >>x;

    int now = (1 << 19);

    vector<int> res;
    while(1) {
        if(n <= 4) break;
        res.pb(now);
        res.pb(now+1);
        res.pb(now+2);
        res.pb(now+3);
        now += 4;
        n-=4;
    }

    if(x == 0) {
        if(n == 1) {
            res.pb(0);
        } else if(n == 2) {
            if(res.size() > 0) {
                res.pop_back();
                res.pop_back();
                res.pop_back();
                res.pop_back();
                res.pb(1);
                res.pb(5);
                res.pb(4);
                res.pb(24);
                res.pb(16);
                res.pb(8);
               //\\ res.pb(8);
                
            } else { 
                printf("NO\n");
                return 0;
            }
        } else if(n == 3) {
            res.pb(1);
            res.pb(2);
            res.pb(3);
        } else if(n == 4) {
            res.pb(0);
            res.pb(1);
            res.pb(2);
            res.pb(3);
        }
    } else {
        int aux = (1 << 18);
        if(n == 4) {
            res.pb(x);
            if(x == 1) {
                res.pb(3);
                res.pb(4);
                res.pb(7);
            } else {
                res.pb(1);
                res.pb(aux);
                res.pb(aux + 1);
            }
        } else if(n == 1) {
            res.pb(x);
        } else if(n == 2) {
            res.pb(0);
            res.pb(x);
        } else if(n == 3) {
            res.pb(0);
            if(x == 1) {
                res.pb(2);
                res.pb((x xor 2));
            } else {
                res.pb(1);
                res.pb((x xor 1));
            }
        }
    }

    cout << "YES" << endl;
    int aux = 0;
    for(int asd : res) {
        printf("%d ", asd);
        aux = (aux xor asd);
    }
    cout << endl;

    prin(aux);

	return 0;

}



