#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define debug(args...) if(debug) fprintf(stderr,args)
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define frrs(i,a,b) for(int i = (a); i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

vector<int> v[2];
bool vis[N];
vector<int> adj[N];

void dfs(int x, int h) {
    v[h%2].pb(x);
    vis[x] = 1;
    for(int p : adj[x]) {
        if(vis[p] == 0) dfs(p,h+1);
    }
}

int main () {

    int n;
    
    cin >> n;
    int a,b;
    for(int i=0;i<n-1;i++) {
        cin >> a >> b;
        adj[a].pb(b);
        adj[b].pb(a);
    }

    dfs(1,0);

    ll res = ((ll)v[0].size()) * ((ll)v[1].size()) - ((ll)n) + 1LL;
    
    cout << res << endl;

	return 0;

}



