#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 500100

int n;
ll v[N];
char s[N];
ll acum[N];
ll acum2[N];

int main () {

	scanf("%d" ,&n);

	for(int i=0;i<n;i++) {
		scanf("%lld", &v[i]);
	}

	scanf("%s", s);

	
	ll res = 0;
	if(s[0] == 'A') {
		acum[0] += v[0];
	} else {
		res += v[0];
		acum[0] -= v[0];
	}
	
	for(int i=1;i<n;i++) {
		acum[i] = acum[i-1];
		if(s[i] == 'A') {
			acum[i] += v[i];
		} else {
			res += v[i];
			acum[i] -= v[i];
		}
	}
	
	for(int i=n-1;i>=0;i--) {
		acum2[i] = acum2[i+1];
		if(s[i] == 'A') {
			acum2[i] += v[i];
		} else {
			acum2[i] -= v[i];
		}
	}
	
	ll maxi = res;
	for(int i=0;i<n;i++) {
		maxi = max(maxi, res + acum[i]);
	}

	for(int i=n-1;i>=0;i--) {
		maxi = max(maxi, res + acum2[i]);
	}

	cout << maxi << endl;

	return 0;

}



