#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100
#define int ll

ll vida[N];
ll regen[N];
ll start[N];

ll bounty, inc, dano;
map<ll, vector<pair<int, ii> > > ev;
bool vivo[N];
int cntev[N];

ll sweep() {

	ll res = 0;
	ll cnt = 0;
	for(auto j = ev.begin(); j != ev.end(); j++) {
		ll t = j->fi;
		prin(t);
		if(t >= 0) res = max(res, (bounty + t * inc) * cnt);
		int i,who,add;

		for(pair<int, ii> now : j->se) {
			i = now.fi;
			who = now.se.fi;
			add = now.se.se;
			if(cntev[who] > i) continue;
			if(add == -1) continue;
			cntev[who] = i;	
			if(vivo[who] == 0) {
		//		printf("vivo: ");
				prin(who);
				cnt++;
				vivo[who] = 1;
			}
		}
		
		if(t >= 0) res = max(res, (bounty + t * inc) * cnt);

		for(pair<int,ii> now : j->se) {
			i = now.fi;
			who = now.se.fi;
			add = now.se.se;
			if(cntev[who] > i) continue;
			if(add == 1) continue;
			cntev[who] = i;	
			if(vivo[who] == 1) {
		//		printf("morto: ");
				prin(who);
				cnt--;
				vivo[who] = 0;
			}
		}
		if(t >= 0) res = max(res, (bounty + t * inc) * cnt);
		separa();
	}

	return res;

}


int ultvida[N];
main () {

	int n,m;

	scanf("%lld %lld", &n, &m);

	scanf("%lld %lld %lld", &bounty, &inc, &dano);

	int aux = 0;
	for(int i=0;i<n;i++) {
		cntev[i] = -1;
		scanf("%lld %lld %lld", &vida[i], &start[i], &regen[i]);
		if(vida[i] <= dano) {
			aux++;
		}
		ultvida[i] = start[i];
	}

	if(aux > 0 and inc > 0) {
		for(int i=0;i<m;i++) {
			scanf("%*d %*d %*d");
		}
		cout << -1 << endl;

		return 0;
	}

	ll tt;
	for(int i=0;i<n;i++) {
		if(vida[i] <= dano) {
			ev[0].pb({-1,{i,1}});
			continue;
		}
		if(start[i] <= dano) {
			ev[0].pb({-1,{i,1}});
			if(regen[i] > 0) {
				tt = (dano - start[i]) / regen[i];
				ev[tt].pb({-1,{i,-1}});
			}
		}

	}

	ll t,who,h;

	for(int i=0;i<m;i++) {
		scanf("%lld %lld %lld", &t, &who, &h);
		who--;
		ultvida[who] = h;
		if(h > dano) {
			ev[t-1].pb({t,{who,-1}});
			continue;
		}

		prin(h);
		ev[t].pb({t,{who,1}});
	//	printf("evento add [%lld] %d %lld %d\n", t, i ,who, 1);
		if(h <= dano && vida[i] > dano && regen[who] > 0) {
			tt = t + (dano - h) / regen[who];
			prin(tt);
			ev[tt].pb({t,{who,-1}});
	//		printf("evento add morte [%lld] %d %lld %d\n", tt, i ,who, -1);
		}
	}

	for(int i=0;i<n;i++) {
		if(ultvida[i] <= dano and regen[i] == 0 and inc > 0) {
			cout << -1 << endl;
			return 0;
		}
	}

	cout << sweep() << endl;

	return 0;

}



