#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100


int n;
int v[N];

int gcd(int a, int b) {
    if(a < b) swap(a,b);
    if(b == 0) return a;
    return gcd(a%b,b);
}



int main () {

    cin >> n;
    
    for(int i=0;i<n;i++) {
        scanf("%d", &v[i]);
    }   

    int geral = 0;

    for(int i=0;i<n;i++) {
        geral = gcd(v[i],geral);
    }

    if(geral > 1) {
        printf("YES\n0\n");
        return 0;
    }

    //Há alguns gcd's primos entre si!!!! Tornar todos multiplos de 2! Esse é o objetivo
    int a,b;
    int cnt = 0;
    for(int i=0;i<n-1;i++) {
        while(abs(v[i]) % 2 == 1) {
            a = v[i] - v[i+1];
            b = v[i+1] + v[i]; 
            v[i] = a;
            v[i+1] = b;
            cnt++;
        }
    }

    while(abs(v[n-1]) % 2 == 1) {
        a = v[n-2] - v[n-1];
        b = v[n-2] + v[n-1];
        v[n-2] = a;
        v[n-1] = b;
        cnt++;
    }

    /*for(int i=0;i<n;i++) {
        printf("%d ", v[i]);
    }
    printf("\n");
*/
    printf("YES\n");
    printf("%d\n", cnt);

    


    
    

}



