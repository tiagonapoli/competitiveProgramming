#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100



int dist(string a, string b) {
    string aux;
    if(a == b) return 0;
    for(int i=1;i<b.size();i++) {
        aux = b.substr(i,b.size()-i) + b.substr(0,i);
        if(aux == a) {
            return i;
        }
    }
    return -1;
}


int main () {

    int n;
    string s[55];

    cin >> n;

    for(int i=0;i<n;i++) {
        cin >> s[i];
    }

    int res = 99999999;
    for(int i=0;i<n;i++) {
        int cnt = 0;
        for(int j=0;j<n;j++) {
            int aux = dist(s[i],s[j]);
            if(aux == -1) {
                cnt = 99999999;
                break;
            }
            cnt += dist(s[i],s[j]);
        }
        res = min(res,cnt);
    }
    if(res == 99999999) {
        cout << -1 << endl;
    } else cout << res << endl;
}



