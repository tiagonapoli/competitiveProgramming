#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#ifndef ONLINE_JUDGE
#define debug(args...) fprintf(stderr,args)
#else
#define debug(args...)
#endif //ONLINE_JUDGE
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100

string s;
char dp[N];
stack<char> t;
string u;


int main () {

    cin >> s;

    int n = s.size();

    dp[n-1] = s[n-1];
    for(int i=n-2;i>=0;i--) {
        dp[i] = min(s[i], dp[i+1]);
    }

    for(int i=0;i<s.size();i++){
        debug("%c ", dp[i]);
        while(!t.empty() && t.top() <= dp[i]) {
            u.pb(t.top());
            t.pop();
        }
        t.push(s[i]);
    }
    debug("\n");
    while(!t.empty()) {
        u.pb(t.top());
        t.pop();
    }

    cout << u << endl;

}



