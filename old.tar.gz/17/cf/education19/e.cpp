#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#ifndef ONLINE_JUDGE
#define debug(args...) fprintf(stderr,args)
#else
#define debug(args...)
#endif //ONLINE_JUDGE
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100

int n,q;


int pre[350][N];
int v[N];

void calc() {
    for(int i=0;i<=340;i++) {
        for(int j=n;j>=1;j--) {
            if(j + v[j] + i > n) {
                pre[i][j] = 1;
            } else pre[i][j] = 1 + pre[i][j+i+v[j]];
        }
    }
}

int simula(int p, int k) {
    if(p > n) return 0;
    return 1 + simula(p+v[p]+k,k);
}

int main () {

    cin >> n;

    for(int i=1;i<=n;i++) {
        cin >> v[i];
    }

    cin >> q;
    calc();
    int p,k;
    for(int i=0;i<q;i++) {
        cin >> p >> k;
        if(k > 340) {
            printf("%d\n", simula(p,k));
        } else printf("%d\n", pre[k][p]);
    }


}



