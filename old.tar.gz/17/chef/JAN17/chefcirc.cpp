#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100

struct pt {
    double x,y;

    pt(){}
    pt(double a,double b) {x=a;y=b;}
    pt operator-(pt b) {pt res(x-b.x,y-b.y);return res;}
    pt operator+(pt b) {pt res(x+b.x,y+b.y);return res;}

};

int n,m;
pt v[550];
std::clock_t start;

double sqr(double a) {
    return a*a;
}

double dist(int a, int b) {
    return sqr(v[a].x-v[b].x) + sqr(v[a].y-v[b].y);
}

bool check(int now, double r) {


 /*   printf("\nCHECK\n");
    printf("raio %Lf\n", r); 
 */   //negativo insercao / positivo remocao
    vector<pair<double,int> > angle; 
    double anglea,angleb;
    for(int i=1;i<=n;i++) {
        if(i == now) continue;
        if(dist(now,i) > sqr(2.0*r)) continue;
        double h2 = (sqr(r) - dist(now,i)/4.0);
        double norma2;
        pt ni = v[i] - v[now];
        ni.x /= 2.0;
        ni.y /= 2.0;
        pt a,b;
        a = b = ni;

        swap(ni.x,ni.y);
        ni.x = -ni.x;
        norma2 = sqr(ni.x) + sqr(ni.y);
        ni.x = ni.x * sqrt(h2)/sqrt(norma2);
        ni.y = ni.y * sqrt(h2)/sqrt(norma2);
        a = a + ni;
        b = b - ni;
    
        anglea = atan2(a.y,a.x);
        angleb = atan2(b.y,b.x);

        if(anglea > angleb) swap(anglea,angleb);
        if(angleb - anglea > PI) {
            angle.pb(mk(angleb,-i));
            angle.pb(mk(PI,+i));
            angle.pb(mk(-PI,-i));
            angle.pb(mk(anglea,+i));
        } else {
            angle.pb(mk(anglea,-i));
            angle.pb(mk(angleb,+i));
        }
/*
        printf("[%.0Lf][%.0Lf] [%.0Lf][%.0Lf] %.4Lf = ", v[now].x,v[now].y,v[i].x,v[i].y,r);
        printf("[%Lf][%Lf]  [%Lf][%Lf]\n", a.x,a.y,b.x,b.y);
        printf("%Lf -> %Lf / %Lf -> %Lf\n", anglea, angleb, anglea*180.0/PI, angleb*180.0/PI);
*/
    }

    sort(angle.begin(), angle.end());

    /*for(int i=0;i<angle.size();i++) {
        printf("[%.2Lf][%d] ", angle[i].fi, angle[i].se);
    }
    printf("\n");
*/

    set<int> cnt;
    int res = 0;
    for(int i=0;i<angle.size(); i++) {
        if(angle[i].se < 0) {
           cnt.insert(abs(angle[i].se));
        } else cnt.erase(abs(angle[i].se));
        res = max(res, (int)cnt.size());
    }

    res++;
    //printf("res %d\n", res);
    return res >= m;
}

double bsearch(int now) {
    double r;
    double i,f;

    start = std::clock();
    double duration;

    duration = (std::clock()-start)/(double)CLOCKS_PER_SEC;
    f = 3000;
    i = 0.00001;
    while(duration < 1.8/n) {
        r = (f+i)/2.0;
        if(check(now,r)) {
            f = r;
        } else {
            i = r;
        }
        duration = (std::clock()-start)/(double)CLOCKS_PER_SEC;
    }
    return f;
}



int main () {


    scanf("%d %d", &n, &m);
    for(int i=1;i<=n;i++) {
        scanf("%lf %lf", &v[i].x, &v[i].y);
    }

    //Tenta colocar um ponto na extremidade de uma circunferencia

    double res = 4099;
    for(int i=1;i<=n;i++) {
        res = min(res, bsearch(i));
    }

    printf("%lf\n", res);
}



