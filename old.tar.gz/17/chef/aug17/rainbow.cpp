#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#ifndef ONLINE_JUDGE
#define debug(args...) fprintf(stderr,args)
#else
#define debug(args...)
#endif //ONLINE_JUDGE
#define printa(a) cout << #a << " = " << (a) << endl
//for
#define fr(i,n) for(int i=0;i<(n);i++) 
#define frr(i,a,b) for(int i=(a);i<=(b);i++)
#define frrs(i,a,b) for(int i=(a);i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
//for
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100


int main () {

    int t;
    int n;
    int v[N];

    cin >> t;

    while(t--) {

        cin >> n;
        
        stack<int> p;
        int x;
        for(int i=0;i<n;i++) {
            cin >> x;
            p.push(x);
        }
        
        int a[10];
        bool res = 1;
        for(int i=1;i<=7;i++) {
            int cnt = 0;
            while(!p.empty() && p.top() == i) {
                cnt++;
                p.pop();
            }
            if(cnt == 0) {
                res = 0;
                break;
            } else a[i] = cnt;
        }

        if(res == 0) {
            printf("no\n");
            continue;
        }

        for(int i=6;i>=1;i--) {
            int cnt = 0;
            while(!p.empty() && p.top() == i) {
                cnt++;
                p.pop();
            }
            if(cnt != a[i]) {
                res = 0;
                break;
            }
        }

        if(res == 0) {
            printf("no\n");
            continue;
        }

        printf("yes\n"); 

    }

}



