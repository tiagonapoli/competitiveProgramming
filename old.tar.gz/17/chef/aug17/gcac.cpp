#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#ifndef ONLINE_JUDGE
#define debug(args...) fprintf(stderr,args)
#else
#define debug(args...)
#endif //ONLINE_JUDGE
#define printa(a) cout << #a << " = " << (a) << endl
//for
#define fr(i,n) for(int i=0;i<(n);i++) 
#define frr(i,a,b) for(int i=(a);i<=(b);i++)
#define frrs(i,a,b) for(int i=(a);i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
//for
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 1010

int mini[N], of[N], maxi[N];
int qual[N][N];
int n,m;
set<ii> v[N];

int main () {

    int t;
    cin >> t;
    bool mark[N];
    string s;
    while(t--) {
        
        cin >> n >> m;
        
        for(int i=0;i<=max(n,m)+1;i++) {
            v[i].clear();
            mark[i] = 0;
        }

        for(int i=1;i<=n;i++) {
            cin >> mini[i];
        }

        for(int i=1;i<=m;i++) {
            cin >> of[i] >> maxi[i];
        }

        for(int i=1;i<=n;i++) {
            cin >> s;
            for(int j=1;j<=m;j++) {
                if(s[j-1] == '1') {
                    qual[i][j] = 1;
                } else qual[i][j] = 0;
                if(qual[i][j] == 1 && mini[i] <= of[j]) {
                    v[i].insert(mk(of[j],j));
                }
            }
        }

        int empregado = 0;
        ll sal = 0;
        int comp = 0;

        for(int i=1;i<=n;i++) {
        //    printf("%d: ", i);
            for(auto it = v[i].rbegin(); it != v[i].rend(); it++) {
          //      printf("%d[%d] ", it->fi, it->se);
                if(maxi[it->se] != 0) {
                    maxi[it->se]--;
                    empregado++;
                    sal += of[it->se];
                    mark[it->se] = 1;
                    break;
                }
            }
          //  printf("\n");
        }

        for(int i=1;i<=m;i++) {
            if(mark[i] == 0) {
                comp++;
            }
        }

        printf("%d %lld %d\n", empregado, sal, comp);
        
    }
}



