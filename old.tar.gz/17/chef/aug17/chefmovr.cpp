#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#ifndef ONLINE_JUDGE
#define debug(args...) fprintf(stderr,args)
#else
#define debug(args...)
#endif //ONLINE_JUDGE
#define printa(a) cout << #a << " = " << (a) << endl
//for
#define fr(i,n) for(int i=0;i<(n);i++) 
#define frr(i,a,b) for(int i=(a);i<=(b);i++)
#define frrs(i,a,b) for(int i=(a);i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
//for
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100

int n,d;
ll v[N];
ll solve(int id) {
    ll tot = 0;
    ll aux = 0;
    for(int i=id;i<n;i+=d) {
        tot += v[i];
        aux++;
    }
    tot /= aux;
    ll res = 0;
    for(int i=id;i+d<n;i+=d) {
        res += abs(tot-v[i]);
        v[i+d] -= (tot-v[i]);
        v[i] = tot;
    }
    return res; 

}

int main () {

    int t;

    cin >> t;

    while(t--) {

        cin >> n >> d;

        for(int i=0;i<n;i++) {
            cin >> v[i];
        }
    
        ll res=0;
        for(int i=0;i<d;i++) {
            res+=solve(i);
        }
        
        for(int i=0;i<n;i++) {
            if(v[i] != v[0]) {
                res = -1LL;
                break;
            }
        }

        printf("%lld\n", res);
    }
}



