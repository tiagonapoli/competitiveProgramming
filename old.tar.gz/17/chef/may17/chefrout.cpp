#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#ifndef ONLINE_JUDGE
#define debug(args...) fprintf(stderr,args)
#else
#define debug(args...)
#endif //ONLINE_JUDGE
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100


int main () {

    int t;
    cin >> t;

    while(t--) {
        
        string s;
        cin >> s;
        bool v[3];
        v[0] = v[1] = v[2] = 0;
    
        bool res = 1;
        for(int i=0;i<s.size(); i++) {
            if(s[i] == 'C') {
                if(v[1] == 1 || v[2] == 1) {
                    res = 0;
                    break;
                }
                v[0] = 1;
            } else if(s[i] == 'E') {
                if(v[2] == 1) {
                    res = 0;
                }
                v[1] = 1;
            } else {
                v[2] = 1;
            }
        }
        
        if(res) {
            printf("yes\n");
        } else printf("no\n");
    }

}



