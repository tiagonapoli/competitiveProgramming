#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define P 1001010
#define N 100010

vector<ll> prime;
bool mark[P];
void sv() {
    for(ll i=2;i<=P;i++) {
        if(mark[i] == 0) {
            prime.pb(i);
            for(ll j=i;j<=P;j+=i) {
                mark[j] = 1;
            }
        }
    }
}

int main () {

    sv();

    ll a,b;

    cin >> a >> b;
    
    map<ll,ll> fact[N];

    ll v[N];
    ll sz = b-a+1;
    for(ll i=0;i<sz;i++) {
        v[i] = a+i;
    }

    for(ll primo : prime) {
        for(ll now = (a % primo == 0) ? a : primo*(a/primo+1LL);now <= b; now += primo) {
            while(v[now-a] % primo == 0) {
                v[now-a] /= primo;
                fact[now-a][primo]++;
            }
        }
    }

    for(ll i=0;i<sz;i++){
        if(v[i] != 1) {
            fact[i][v[i]] = 1;
        }
    }

   /* for(int i=0;i<sz;i++) {
        printf("%lld: ", i+a);
        for(auto j = fact[i].begin(); j != fact[i].end();j++) {
            printf("%lld[%lld] ", j->fi, j->se);
        }
        printf("\n");
    }
*/
    ll res = 0;
    for(ll i=0;i<sz;i++) {
        
 //       printf("[%lld]\n", i+a);
        priority_queue<ll> heap;
        ll divisores = 1;
        for(auto j = fact[i].begin();j != fact[i].end(); j++) {
            divisores *= (j->se+1LL);
            heap.push((j->se+1LL));
        }
   //     printf("%lld\n", divisores);
        ll now;
        while(!heap.empty()) {
            res += divisores;
            now = heap.top();
            heap.pop();
            divisores /= now;
            divisores *= now-1LL;
     //       printf("%lld\n", divisores);
            now--;
            if(now > 1) {
                heap.push(now);
            }
        }
    }

    cout << res << endl;

}



