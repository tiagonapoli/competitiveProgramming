#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100


vector<int> v[N];

int main () {

    int n,k,t;

    cin >> t;

    while(t--){
        cin >> n >> k;
        
        map<int,int> cont;

        int ingrediente = 0;
        int aux,x;
        for(int i=1;i<=n;i++){
            v[i].clear();
            cin >> aux;
            for(int j=0;j<aux;j++) {
                cin >> x;
                if(cont.find(x) == cont.end()) {
                    ingrediente++;
                }
                cont[x]++;
                v[i].pb(x);
            }
        }

        if(ingrediente < k) {
            printf("sad\n");
        } else {
            bool res = 0;
            for(int i=1;i<=n;i++) {
                res = 0;
                for(int j=0;j<v[i].size(); j++) {
                    if(cont[v[i][j]] == 1) {
                        res = 1;
                    }
                }
                if(res == 0) {
                    break;
                }
            }
            if(res == 0) {
                printf("some\n");
            } else {
                printf("all\n");
            }
        }
    }
}



