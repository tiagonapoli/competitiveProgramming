#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100

ll d[N];
int n,k;
ll X;
vector<pair<int,ll> > adj[N];


bool visk;
void dijkstra(int s) {
    priority_queue< pair<ll,int>, vector<pair<ll,int> >, greater<pair<ll,int> > > fila;
    for(int i=1;i<=n;i++) {
        d[i] = -1LL;
    }
    visk = 0;
    fila.push(mk(0,s));
    pair<ll,int> now;
    int x;
    ll dist;
    while(!fila.empty()) {
        now = fila.top();
        //printf("[%d] %lld\n",now.se, now.fi);
        fila.pop();
        x = now.se;
        dist = now.fi;

        if(d[x] != -1LL) continue;
        
        d[x] = dist;

        if(x <= k) {
            if(visk == 0) {
                visk = 1;
                for(int i=1;i<=k;i++) {
                    if(i == x) continue;
                    fila.push(mk(dist+X,i));
                }
            }

            
        }
        for(pair<int, ll> p : adj[x]) {
            if(d[p.fi] == -1) {
                fila.push(mk(dist+p.se,p.fi));
            }
        }
        
    }
    


}


int main () {

    int t;

    cin >> t;

    int m,s;
    while(t--) {
        
        scanf("%d %d %lld %d %d", &n, &k, &X, &m, &s);
        
        for(int i=0;i<=n;i++) {
            adj[i].clear();
        }

        int a,b;
        ll c;
        for(int i=0;i<m;i++) {
            scanf("%d %d %lld", &a, &b, &c);
            adj[a].pb(mk(b,c));
            adj[b].pb(mk(a,c));
        }

        dijkstra(s);

        for(int i=1;i<=n;i++) {
            printf("%lld ", d[i]);
        }
        printf("\n");
    }

}



