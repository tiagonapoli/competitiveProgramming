#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#ifndef ONLINE_JUDGE
#define debug(args...) fprintf(stderr,args)
#else
#define debug(args...)
#endif //ONLINE_JUDGE
#define printa(a) cout << #a << " = " << (a) << endl
//for
#define fr(i,n) for(int i=0;i<(n);i++) 
#define frr(i,a,b) for(int i=(a);i<=(b);i++)
#define frrs(i,a,b) for(int i=(a);i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
//for
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100

ii v[N][2];

bool interx(int a, int b) {
    if(v[a][1].fi - v[a][0].fi < v[b][1].fi - v[b][0].fi) swap(a,b);
    if(v[a][0].fi <= v[b][0].fi && v[a][1].fi >= v[b][0].fi) return 1;
    if(v[a][0].fi <= v[b][1].fi && v[a][1].fi >= v[b][1].fi) return 1;
    return 0;
}

double alt(int x, int id) {
    double m = ((double)(v[id][1].se-v[id][0].se))/((double)(v[id][1].fi-v[id][0].fi));
    double y = (double)v[id][0].se + m*((double)(x-v[id][0].fi));
    return y;
}

struct seg {
    int id;
    seg(){}
    seg(int x){id=x;}
    bool operator< (const seg b) const {
        if(interx(id,b.id)) {
            int aux[] = {v[id][0].fi,v[id][1].fi,v[b.id][0].fi,v[b.id][1].fi};
            sort(aux,aux+4);
            if(alt(aux[1],id) < alt(aux[1],b.id)) {
                return 1;
            } else return 0;
        } else return 1;
    }
};

seg segmento(int id) {
    seg aux(id);
    return aux;
}

map<int, vector<ii> > ev;
map<int,int> proxB;
int proxS[N];

void print(int id) {
    debug("%d/%d %d/%d", v[id][0].fi, v[id][0].se, v[id][1].fi, v[id][1].se);
}

void sweep() {

    multiset<seg> aberto;

    for(auto x=ev.begin(); x != ev.end(); x++) {
        
      /*  debug("\nx: %d\n", x->fi);
        
        debug("eventos:\n");
        for(ii j : x->se) {
            debug("%d: %d\n", j.fi, j.se);
        }
        
        debug("aberto:\n");
        for(seg i : aberto) {
            debug("[%d] ",i.id);
            print(i.id);
            debug("\n");
        }
        */

        for(ii j : x->se) {
            if(j.fi == +1) {
                aberto.insert(segmento(j.se));
            }
        }

        if(aberto.empty()) {
            proxB[x->fi] = -1;
        } else {
            proxB[x->fi] = aberto.begin()->id;
        }

        for(ii j : x->se) {
            
            if((j.fi == -1 && v[j.se][1].se > v[j.se][0].se) || (j.fi == +1 && v[j.se][0].se > v[j.se][1].se)) {
                auto pos = aberto.find(segmento(j.se));
                if(pos != (--aberto.end())) {
                    pos++;
                    proxS[j.se] = pos->id;
                } else proxS[j.se] = -1;
            }

        }

        for(ii j : x->se) {
            if(j.fi == -1) {
                aberto.erase(segmento(j.se));
            }
        }

        
    }
    
}

ii saida(int id) {
    if(id == -1) return mk(-1,-1);
    if(v[id][0].se > v[id][1].se) return mk(v[id][0].fi,v[id][0].se);
    if(v[id][0].se == v[id][1].se) return mk(-1,v[id][0].se);
    return mk(v[id][1].fi,v[id][1].se);
}

bool vis[N];
ii res[N];
int query[N];

ii dfs(int now) {
    if(vis[now]) return res[now];
    vis[now] = 1;
    if(proxS[now] == -1) {
        res[now] = saida(now);
        if(v[now][0].se != v[now][1].se) res[now].se = -1;
        return res[now];
    }
    res[now] = dfs(proxS[now]);
    if(res[now].fi == -1) {
        res[now].fi = saida(now).fi; 
    }
    return res[now];
}

int main () {
    
    int n,c;
    int grau[N];

    scanf("%d %d", &n, &c);

    for(int i=0;i<n;i++) {
        vis[i] = 0;
        res[i] = mk(-1,-1);
        proxS[i] = -1;
    }

    for(int i=0;i<n;i++) {
        scanf("%d %d %d %d", &v[i][0].fi, &v[i][0].se, &v[i][1].fi, &v[i][1].se);
        if(v[i][0].fi > v[i][1].fi) {
            swap(v[i][0],v[i][1]);
        }
        ev[v[i][0].fi].pb(mk(+1,i));
        ev[v[i][1].fi].pb(mk(-1,i));
    }

    int x;
    for(int i=0;i<c;i++) {
        scanf("%d", &x);
        query[i] = x;
        ev[x].pb(mk(+2,x));
    }
    
    sweep(); 

  /*  for(int i=0;i<n;i++) {
        debug("%d - > %d\n", i, proxS[i]);
    }
*/
    for(int i=0;i<n;i++) {
        if(vis[i] == 0) {
            dfs(i);
        }
    }
/*
    debug("res:\n");
    for(int i=0;i<n;i++) {
        debug("%d: %d %d\n", i, res[i].fi, res[i].se);
    }
*/
    ii aux;
    for(int i=0;i<c;i++) {
        int id = proxB[query[i]];
        if(id == -1) {
            printf("%d\n", query[i]);
        } else {
            aux = res[id];
            if(aux.se == -1) {
                printf("%d\n", aux.fi);
            } else if(aux.fi == -1) {
                printf("%d %d\n", query[i], aux.se);
            } else {
                printf("%d %d\n", aux.fi,aux.se);
            }
        }
    }

}



