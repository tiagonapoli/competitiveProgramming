#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#ifndef ONLINE_JUDGE
#define debug(args...) fprintf(stderr,args)
#else
#define debug(args...)
#endif //ONLINE_JUDGE
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 30500


ii seg[4*N];

void upd(int a, int b, int x, int id=1, int l=1, int r=30100) {
    if(a > r || b < l) return;
    if(a <= l && b >= r) {
        seg[id].fi += x;
        if(seg[id].fi == 0) {
            seg[id].se = seg[id<<1].se + seg[(id<<1)|1].se;
        } else {
            seg[id].se = r-l+1;
        }
        return;
    }
    int mid = (l+r)>>1;
    upd(a,b,x,id<<1,l,mid);
    upd(a,b,x,(id<<1)|1,mid+1,r);
    if(seg[id].fi == 0) {
        seg[id].se = seg[id<<1].se + seg[(id<<1)|1].se;
    } else {
        seg[id].se = r-l+1;
    }
}

int query() {
    return seg[1].se;
}

vector< pair<int,ii>> event[N];

int solve() {

    int ant = -1;
    int res = 0;

   for(int i=0;i<=30010;i++) {
        if(event[i].size() == 0) continue;
        if(ant != -1) {
            res += query()*(i-ant);
        }
       // printf("[%lld]\n",i);
       // printf("abertos %d\n", query());
       // printf("ant %lld\n", ant);
        ant = i;
       // printf("res %lld\n", res);
        for(pair<int,ii> j : event[i]) {
         //   printf("evento %d %d [%d]\n", j.se.fi,j.se.se-1, j.fi);
            upd(j.se.fi,j.se.se-1,j.fi);
        }
    }
    return res;
}

int main () {

    int n;

    scanf("%d", &n);

    int x1,x2,y1,y2;
    for(int i=0;i<n;i++) {
        scanf("%d %d %d %d", &x1, &y1, &x2, &y2);
        y1++,y2++;
        event[x1].pb(mk(1,mk(y1,y2)));
        event[x2].pb(mk(-1,mk(y1,y2)));
    }

    cout << solve() << endl;


}




