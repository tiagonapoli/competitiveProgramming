#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#ifndef ONLINE_JUDGE
#define debug(args...) fprintf(stderr,args)
#else
#define debug(args...)
#endif //ONLINE_JUDGE
#define printa(a) cout << #a << " = " << (a) << endl
//for
#define fr(i,n) for(int i=0;i<(n);i++) 
#define frr(i,a,b) for(int i=(a);i<=(b);i++)
#define frrs(i,a,b) for(int i=(a);i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
//for
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 1010

ii star[N];
int n,m;

map<int, set<ii> > evstar;
map<int, set<ii> > ev;

void sweep1(int id) {
    int x,y;
    x = star[id].fi;
    y = star[id].se;
    set<int> aberto;
    bool flag = 0;
    int a,b;

    for(auto it = ev.begin(); it != ev.end(); it++) {
        for(ii j : it->se) {
            if(j.fi == -1) {
                //abre
                aberto.insert(j.se);
                if(flag == 0 && aberto.size() >= 2) {
                    a = *(aberto.begin());
                    b = *(aberto.rbegin());
                    if(y >= a && y <= b) {
                        evstar[it->fi - x].insert(mk(-1,id));
                        flag = 1;
                    }
                }
            } else {
                //fechar
                aberto.erase(j.se);
                if(flag == 1) {
                    if(aberto.size() >= 2) {
                        a = *(aberto.begin());
                        b = *(aberto.rbegin());
                        if(y < a || y > b) {
                            evstar[it->fi - x].insert(mk(1,id));
                            flag = 0;
                        }
                    } else {
                        evstar[it->fi - x].insert(mk(1,id));
                        flag = 0;
                    }
                }
            }
        }

    }
}

int sweep2() {
    int res = 0; 
    int aberto = 0;
    for(auto it = evstar.begin(); it != evstar.end();it++) {
      //  printf("tempo %d\n", it->fi);
        for(ii j : it->se) {
    //        printf("%d [%d]\n", j.fi, j.se);
            if(j.fi == -1) {
                aberto++;
            } else {
                aberto--;
            }
  //          printf("abertos %d\n\n", aberto);
            res = max(res,aberto);
        }
    }
    return res;
}

int main () {

    cin >> n >> m;

    int maxx = -1;
    for(int i=0;i<n;i++) {
        cin >> star[i].se >> star[i].fi;
        maxx = max(maxx, star[i].fi);
    }

    for(int i=0;i<n;i++) {
        star[i].fi -= maxx;
    }

   /* printf("\n\n");
    for(int i=0;i<n;i++) {
        printf("%d %d\n", star[i].fi, star[i].se);
    }
    printf("\n");
*/
    int a,b,y;
    for(int i=0;i<m;i++) {
        cin >> y >> a >> b;
        ev[a].insert(mk(-1,y));
        ev[b].insert(mk(1,y));
    }

    for(int i=0;i<n;i++) {
        sweep1(i);
    }
    printf("%d\n", sweep2());


}



