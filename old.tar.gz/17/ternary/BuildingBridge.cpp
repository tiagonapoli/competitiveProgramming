#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#ifndef ONLINE_JUDGE
#define debug(args...) fprintf(stderr,args)
#else
#define debug(args...)
#endif //ONLINE_JUDGE
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100

int n,m;
double a,b;
double va[N], vb[N];
double l[N];
double mini, maxi;

double sqr(double x) {
    return x*x;
}

double go(double ya, int ib) {
    return sqrt(sqr(b-a) + sqr(vb[ib]-ya)) + sqrt(sqr(ya) + sqr(a));
}

double d(int i, int j) {
    return go(va[i],j);
}

int ts(int ib) {

    double i = mini-1;
    double f = maxi+1;
    int iter = 100;

    double m1,m2;
    while(iter--) {
        m1 = i + (f-i)/3.0;
        m2 = f - (f-i)/3.0;
        if(go(m1,ib) < go(m2,ib)) {
            f = m2;
        } else i = m1;
    }

  //  debug("ya %lf  yb %lf  dist %lf\n", i,vb[ib], go(i,ib));

    int res[5];
    res[2] = lower_bound(va+1,va+n+1,i) - va;
    
    res[0] = max(1,res[2]-2);
    res[1] = max(1,res[2]-1);
    res[3] = min(n,res[2]+1);
    res[4] = min(n,res[2]+2);

    double aux = d(res[0],ib);
    int resposta = 0;
    for(int k=1;k<5;k++) {
        if(aux > d(res[k],ib)) {
            aux = d(res[k],ib);
            resposta = k;
        }
    }
    return res[resposta];
  //  printf("x1 %d  x %d  x2 %d\n", x1,x,x2); 
}

int main () {

    scanf("%d %d", &n, &m);
    scanf("%lf %lf", &a, &b);

    mini = 99999999;
    maxi = -999999999;
    for(int i=1;i<=n;i++) {
        scanf("%lf", &va[i]);
        mini = min(mini,va[i]);
        maxi = max(maxi,va[i]);
    }

    for(int i=1;i<=m;i++) {
        scanf("%lf", &vb[i]);
    }

    for(int i=1;i<=m;i++) {
        scanf("%lf", &l[i]);
    }

    double dist = 999999999999;
    ii res;
    int k;

    //printf("resultado: %d\n",  ts(1));

    for(int i=1;i<=m;i++) {
        k = ts(i);
        if(dist > l[i] + d(k,i)) {
            dist = l[i] + d(k,i);
            res = mk(k,i);
        }
    }

    printf("%d %d\n", res.fi, res.se);

}



