#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#ifndef ONLINE_JUDGE
#define debug(args...) fprintf(stderr,args)
#else
#define debug(args...)
#endif //ONLINE_JUDGE
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 200

int n;
double v[N][3];
double r[3];
double x1,x2,ya,yb,z1,z2;

double square(double x) {
    return x*x;
}

//fixo uma coordenada, procuro o minimo para as proximas coordenadas
//devolvo o valor minimo com aquela coordenada p fixa na posicao po


double goZ(double x,double y, double pos) {
    double res = 0;
    for(int i=0;i<n;i++) {
        res = max(res, square(x-v[i][0]) + square(y-v[i][1]) + square(pos-v[i][2]));
    }
    return res;
}

double tsZ(double x, double y) {
    double m1,m2,i,f;
    i = z1;
    f = z2;
    int iter = 60;
    while(iter--) {
        m1 = i+(f-i)/3.0;
        m2 = f-(f-i)/3.0;
        if(goZ(x,y,m1) < goZ(x,y,m2)) {
            f = m2;
        } else {
            i = m1;
        }
    }
    r[2] = i;
  //  printf("%f %f %f\n", x,y,i);
    return goZ(x,y,i);
}

double tsY(double x) {
    double m1,m2,i,f;
    i = ya;
    f = yb;
    int iter = 60;
    while(iter--) {
        m1 = i+(f-i)/3.0;
        m2 = f-(f-i)/3.0;
        if(tsZ(x,m1) < tsZ(x,m2)) {
            f = m2;
        } else {
            i = m1;
        }
    }
    r[1] = i;
    return tsZ(x,i);
}

double tsX() {
    double m1,m2,i,f;
    i = x1;
    f = x2;
    int iter = 60;
    while(iter--) {
        m1 = i+(f-i)/3.0;
        m2 = f-(f-i)/3.0;
        if(tsY(m1) < tsY(m2)) {
            f = m2;
        } else {
            i = m1;
        }
    }
    r[0] = i;
    return tsY(i);
}

int main () {

    scanf("%d", &n);
    scanf("%lf %lf %lf", &v[0][0], &v[0][1], &v[0][2]);
    x1=x2=v[0][0];
    ya=yb=v[0][1];
    z1=z2=v[0][2];
    for(int i=1;i<n;i++) {
        scanf("%lf %lf %lf", &v[i][0], &v[i][1], &v[i][2]);
        x1 = min(x1,v[i][0]);
        x2 = max(x2,v[i][0]);
        ya = min(ya,v[i][1]);
        z1 = min(z1,v[i][2]);
        yb = max(yb,v[i][1]);
        z2 = max(z2,v[i][2]);
    }

    tsX();

    printf("%f %f %f", r[0], r[1], r[2]);
    


}



