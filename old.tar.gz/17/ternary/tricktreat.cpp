#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 50100

int n;
double x[N],y[N];


double f(double pos) {
    double maxi = 0;
    for(int i=0;i<n;i++) {
      //  printf("%d %lf\n", i,hypot(x[i]-pos,y[i]));
        maxi = max(maxi, hypot(x[i]-pos,y[i]));
    }
    return maxi;
}

double bs() {
    
    double i,fim,m1,m2;

    i = -201100.0;
    fim = 201100.0;
    int iter = 120;

    while(iter--) {
        m1 = i + (fim-i)/3.0;
        m2 = fim - (fim-i)/3.0;
        //printf("[%.2lf][%.2lf] %lf=%lf  %lf = %lf\n", i,fim, m1, f(m1), m2,f(m2));
        if(f(m1) <= f(m2) ) {
            fim = m2;
        } else i = m1;
    }
   return fim; 

}

int main () {

    scanf("%d", &n);
    while(n != 0) {
       
        for(int i=0;i<n;i++) {
            scanf("%lf %lf", &x[i], &y[i]);
        }
        double res = bs();
        printf("%.9lf %.9lf\n", res, f(res));
        scanf("%d", &n);
    }

}



