#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#ifndef ONLINE_JUDGE
#define debug(args...) fprintf(stderr,args)
#else
#define debug(args...)
#endif //ONLINE_JUDGE
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 350

struct pt {
    double x,y;
    pt(){}
    pt(double a, double b) {x = a;y = b;}   
    pt operator- (pt b) {pt res(x - b.x, y - b.y);return res;}
    pt operator+ (pt b) {pt res(x+b.x, y+b.y);return res;}
};

int n;
pt v[N];

double square(double x) {
    return x*x;
}

double norma(pt x) {
    return square(x.x) + square(x.y);
}

double dist2(int a, int b) {
    return norma(v[a]-v[b]);
}

int check(int p, double r) {

    vector<pair<double,int> > angle;
    pt a,b;
    double a1,a2;
    for(int i=0;i<n;i++) {
        if(i == p) continue;
        if(dist2(i,p) > 4.0*r*r) continue;
        pt pi = v[i] - v[p];

        pi.x /= 2.0;
        pi.y /= 2.0;
    
        pt x = pi;
        double mult2 = square(r) - norma(pi);
        
        swap(pi.x,pi.y); 
        pi.x = -pi.x;
 
        double h = sqrt(mult2/norma(pi));
        pi.x = pi.x * h;
        pi.y = pi.y * h;
       
        a = x + pi;
        b = x - pi;

        a1 = atan2(a.y,a.x);
        a2 = atan2(b.y,b.x);
       
        if(a1 > a2) swap(a1,a2);
        if(a2 - a1 < PI) {
            angle.pb(mk(a2,1));
            angle.pb(mk(a1,-1));
        } else {
            angle.pb(mk(-PI,-1));
            angle.pb(mk(a1,1));
            angle.pb(mk(a2,-1));
            angle.pb(mk(PI,1));
        }
    }

    sort(angle.begin(), angle.end());
    int res = 0;
    int now = 0;
    for(int i=0;i<angle.size();i++) {
        if(angle[i].se == 1) {
            now--;
        } else now++;
        res = max(res,now);
    }
    res++;
    return res;
}

double bs(int now) {
    double i,f,r;
    i = 0.001;
    f = 1500;
    while(f-i >= 0.001) {
        r = (i+f)/2.0;
        int res = check(now,r);
        if(res == n) {
            f = r;
        } else i = r;
    }

    //debug("[%d] [%lf]\n", now,f);
    return f;
}


int main () {

    scanf("%d", &n);

    for(int i=0;i<n;i++) {
        scanf("%lf %lf", &v[i].x, &v[i].y);
    }

    double res = 9999999;
    for(int i=0;i<n;i++) {
        res = min(res, bs(i));
    }

    printf("%lf\n", 2.0*res);

}



