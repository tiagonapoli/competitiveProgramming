#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 5010

//SOLVES UVA681 - CONVEX HULL FINDING

ll inf = 9999999999;
typedef ll T;

struct pt {
    T x,y;
    pt() {}
    pt(T a, T b) {x=a,y=b;}
    pt operator+ (pt b) {return {x+b.x, y+b.y};}
    pt operator- (pt b) {return {x-b.x, y-b.y};}
	T operator* (const pt b) const {return x * b.x + y * b.y;}
	T operator^ (const pt b) const {return x * b.y - y * b.x;}
    bool operator< (const pt b) const {
        if(x == b.x) {
            return y < b.y;
        } else return x < b.x;
    }
    bool operator==(const pt b) const {return ((x == b.x) && (y == b.y));}
    void print() {printf("%lld %lld\n", x,y);}
    void read() {cin >> x >> y;}
};

//Retorna a area do 'paralelogramo' com 'sinal'
//AB ^ AC = (B-A)^(C-A) = A^B + B^C + C^A
T area(pt a, pt b, pt c) {
    return (a ^ b) + (b ^ c) + (c ^ a);
}

//Tira o cara do topo de up ou down se for fazer uma curva para esquerda (area positiva)
vector<pt> convex_hull(vector<pt> p) {
    vector<pt> up,dn;
    sort(p.begin(), p.end());

	if(p.size() <= 2) return p;

    up.pb(p[0]);
    up.pb(p[1]);
    //Tirar os colineares area >=
    for(int i=2;i<p.size();i++) {
        while(up.size() >= 2 && area(up[(int)up.size()-2],up[(int)up.size()-1],p[i]) >= 0) {
            up.pop_back();
        }
        up.pb(p[i]);
    }
    dn.pb(p[p.size()-1]);
    dn.pb(p[p.size()-2]);
    for(int i=p.size()-3;i>=0;i--) {
        while(dn.size() >= 2 && area(dn[(int)dn.size()-2],dn[(int)dn.size()-1],p[i]) >= 0) {
            dn.pop_back();
        }
        dn.pb(p[i]);
    }
    for(int i=1;i<dn.size();i++) {
        up.pb(dn[i]);
    }
    reverse(up.begin(), up.end());
    up.pop_back();
	return up;
}

ll area2(vector<pt> v) {
	vector<pt> aux = convex_hull(v);
	ll tot = 0;
	for(int i=1;i<aux.size()-1;i++) {
		tot += area(aux[0],aux[i],aux[i+1]);
	}
	prin(tot);
	if(v.size() == aux.size()) return tot;
	ll mini = abs(area(v[0],v[1],v[2]));
	for(int i=0;i<v.size();i++) {
		for(int j=i+1;j<v.size();j++) {
			for(int k=j+1;k<v.size();k++) {
				mini = min(mini, abs(area(v[i],v[j],v[k])));
			}
		}
	}
	prin(tot-mini);
	separa();
	return tot - mini;	
}


set<ii> antipodal;
int rotating_callipers(vector<pt> &p) {
	int sz = p.size();
	int to;
	pt a,b,c,d;
	pt ab,ac,ad;
	to = 0;
	a = p[sz-1];
	b = p[0];
	ab = b-a;
	while((to + 1) % sz != sz-1) {
		c = p[to];
		d = p[(to+1) % sz];
		ac = c-a;
		ad = d-a;
		if((ab ^ ac) < (ab ^ ad)) {
			to = to + 1;
		} else break;
	}

	for(int i=0;i<sz;i++) {
		a = p[i];
		b = p[(i+1) % sz];
		ab = b-a;
		antipodal.insert({min(i,to), max(i,to)});
		while((to + 1) % sz != 0) {
			c = p[to];
			d = p[(to+1) % sz];
			ac = c-a;
			ad = d-a;
			if((ab ^ ac) < (ab ^ ad)) {
				//distancia de d a reta ab [e maior
				to = (to + 1) % sz;
			} else break;
			antipodal.insert({min(i,to), max(i,to)});
		}

		if((ab ^ ac) == (ab ^ ad)) {
			antipodal.insert({min(i,(to+1) % sz), max(i,(to+1) % sz)});
			antipodal.insert({min((i+1) % sz,to), max((i+1) % sz,to)});
			if((to + 1) % sz != 0) to = (to + 1) % sz;
		}

	}

}

ll areap(pt a, pt b, pt c) {
	return abs(area(a,b,c));
}

ll ts(pt a, pt b,int ini, int fim, vector<pt> &p) {
	int sz = p.size();
	if(ini > fim) {
		return max(ts(a,b,ini,sz,p), ts(a,b,0,fim,p));
	}
	int i,f,ma,mb;
	f = fim;
	i = ini;
	while(f - i > 5) {
		ma = (f + i) / 2;
		mb = ma + 1;
		if(areap(a,b,p[ma]) < areap(a,b,p[mb])) {
			i = mb;
		} else f = ma;
	}
	ll ret = 0;
	if(f == sz) f--;
	for(int j=i; j <= f; j++) {
		ret = max(ret, areap(a,b,p[j]));
	}
	return ret;
}

ll go(vector<pt>& p) {
	rotating_callipers(p);
	int a,b;
	ll res = 0;
	int sz = p.size();
	for(ii j : antipodal) {
		a = j.fi;
		b = j.se;
		res = max(res, ts(p[a],p[b], (a+1) % sz, b, p)+ ts(p[a],p[b], (b+1) % sz, a, p));
	}
	return res;
}

int main () {
	
	int n;


	cin >> n;
	vector<pt> v;
	pt x;

	for(int i=0;i<n;i++) {
		x.read();
		v.pb(x);
	}

	sort(v.begin(), v.end());
	auto it = unique(v.begin(), v.end());
	v.resize(distance(v.begin(), it));
	

	vector<pt> convex = convex_hull(v);
	
	ll res = 0;
	if(convex.size() <= 2) {
		cout << "0.0" << endl;
		return 0;
	} else if(convex.size() == 3) {
		for(int i=0;i<v.size();i++) {
			if(convex[0] == v[i]) continue;
			if(convex[1] == v[i]) continue;
			if(convex[2] == v[i]) continue;
			res = max(res, area2({convex[0], convex[1], convex[2], v[i]}));
		}
	} else {
		res = go(convex);
	}

	printf("%lld", res/2LL);
	if(res % 2 == 0) {
		cout << ".0" << endl;
	} else cout << ".5" << endl;

}


