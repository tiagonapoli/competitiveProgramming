#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 1100

int sa[N];
int P[32][N];
int lcp[N];
int logg[N];
int pot2[N];
int onde[N];
pair<ii, int> rk[N];
string s;

void print() {
	for(int i=0;i<s.size();i++) {
		cout << s.substr(rk[i].se, s.size() - rk[i].se) << " ";
		printf("lcp %d\n", lcp[i]);
	}
	cout << endl;
}

void build_lcp() {
	lcp[0] = -1;
	int a,b;
	for(int i=1;i<s.size();i++) {
		lcp[i] = 0;
		a = sa[i];
		b = sa[i-1];
		for(int j=logg[s.size()];j >= 0 and a < s.size() and b < s.size();j--) {
			if(P[j][a] == P[j][b]) {
				lcp[i] += pot2[j];
				a += pot2[j];
				b += pot2[j];
			} 
		}
	}
}

void build() {
	
	int sz = s.size();

	for(int i=0;i<s.size();i++) {
		rk[i].fi.fi = s[i];
		if(i != s.size()-1) {
			rk[i].fi.se = s[i+1];
		} else rk[i].fi.se = -9999;
		rk[i].se = i;
		sa[i] = i;
		P[0][rk[i].se] = rk[i].fi.fi;
	}

	sort(rk, rk + sz);
	for(int i=0;i<sz; i++) {
		onde[rk[i].se] = i;	
	}

	int cnt = 0;
	for(int k = 2; k <= sz; k *= 2) {	
		cnt++;
		ii prev_rank = rk[0].fi;
		rk[0].fi.fi = 0;
		P[cnt][rk[0].se] = 0;
		for(int i=1;i<sz;i++) {
			if(rk[i].fi == prev_rank) {
				rk[i].fi.fi = rk[i-1].fi.fi;	
			} else {
				prev_rank = rk[i].fi;
				rk[i].fi.fi = i; 
			}
			P[cnt][rk[i].se] = rk[i].fi.fi;
		}
		int quem;
		for(int i=0;i<sz;i++) {
			if(rk[i].se+k >= sz) {
				rk[i].fi.se = -1;
				continue;
			}
			quem = onde[rk[i].se + k];
			rk[i].fi.se = rk[quem].fi.fi;
		}
		sort(rk, rk + sz);
		for(int i=0;i<sz; i++) {
			onde[rk[i].se] = i;	
		}
	}

	for(int i=0;i<sz;i++) {
		sa[i] = rk[i].se;
	}
	
	build_lcp();
}

int check() {
	set<string> asd;
	for(int i=0;i<s.size();i++) {
		for(int j=1;j<=s.size()-i;j++) {
			asd.insert(s.substr(i,j));
		}
	}

	return asd.size();
}

int main () {


	logg[1] = 0;
	for(int i=2;i<N;i++) {
		logg[i] = logg[i/2] + 1;
	}

	pot2[0] = 1;
	for(int i=1;i<20;i++) {
		pot2[i] = pot2[i-1] * 2;
	}

	int t;
	cin >> t;
	char c;
	while(t--) {
	
		s.clear();
		scanf(" %c", &c);
		while(c != '\n') {
			s.pb(c);
			scanf("%c", &c);
		}

		build();
	/*
		for(int i=0;i<s.size();i++) {
			cout << s.substr(sa[i], s.size()-sa[i]) << " " << lcp[i] << endl;
		}
	*/
		int res = s.size() - sa[0];
		for(int i=1;i<s.size();i++) {
			res += s.size() - sa[i] - lcp[i];
		}

/*
		for(int i=0;i<=logg[s.size()];i++) {
			printf("I : %d\n", i);
			for(int j=0;j<s.size();j++) {
				cout << s.substr(j,s.size()-j) << " " << P[i][j] << endl;
			}
			cout << endl;
		}
*/
		cout << res << endl;
/*
		if(check() == res) {
			cout << "DEU BOM" << endl;
		} else {
			cout << s << endl;
			cout << "DEU RUIM" << endl;
		}
*/	}

	return 0;

}



