#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define debug(args...) if(debug) fprintf(stderr,args)
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define frrs(i,a,b) for(int i = (a); i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

int in[N], out[N];
int inmaior, outmaior;
int n,m;
list<int> adj[N];
stack<int> pfinal;

bool eulerian() {
    inmaior = outmaior = -1;
    int cnt = 0;
    for(int i=0;i<n;i++) {
        if(in[i] == out[i] + 1) {
            if(inmaior != -1) return 0;
            inmaior = i;
        } else if(out[i] == in[i] + 1) {
            if(outmaior != -1) return 0;
            outmaior = i;
        } else if(in[i] != out[i]) return 0;
    } 
    return 1;
}

int euler_dfs(int p) {
    //prin(p);
    while(!adj[p].empty()) {
        int aux = adj[p].back();
        adj[p].pop_back();
        euler_dfs(aux);
    }
    pfinal.push(p);
}

int main () {


    cin >> n >> m;

    int a,b;
    for(int i=0;i<m;i++) {
        cin >> a >> b;
        adj[a].pb(b);
        in[b]++;
        out[a]++;
    }

    if(!eulerian()) {
        cout << "-1" << endl;
        return 0;
    }

    if(inmaior == -1) {
        euler_dfs(0);
    } else euler_dfs(outmaior);

    while(!pfinal.empty()) {
        printf("%d ", pfinal.top());
        pfinal.pop();
    }
    cout << endl;

	return 0;

}



