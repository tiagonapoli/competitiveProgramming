#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

struct node {
	int val, prior, sz;
	struct node *l, *r;
};

typedef node* pnode;

int sz(pnode t) {
	if(t) return t->sz;
	return 0;
}

void upd_sz(pnode t){
	if(t) t->sz = 1 + sz(t->l) + sz(t->r);
}

void split(pnode t, pnode &l, pnode &r, int key) {
	if(t == NULL) {
		l = r = NULL;
	} else if(t->val <= key) {
		split(t->r, t->r, r, key);
		l = t;
	} else {
		split(t->l, l, t->l, key);
		r = t;
	}
	upd_sz(t);
}

void merge(pnode &t, pnode l, pnode r) {
	if(!l || !r) t = l ? l : r;
	else if(l->prior > r->prior) {
		merge(l->r, l->r, r);
		t = l;
	} else {
		merge(r->l, l, r->l);
		t = r;
	}
	upd_sz(t)
}

void insert(pnode &t, pnode it) {
	if(!t) t = it;

}

int main () {


	return 0;

}



