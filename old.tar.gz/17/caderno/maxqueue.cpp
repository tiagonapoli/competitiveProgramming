#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 2000005

struct sliding_window {
	deque<pair<ll,int> > v;
	ll addval = 0;
	int sz = 0;

	int size() {return sz;}
	
	void push(ll x) {
		x -= addval;
		int aux = 1;
		//change <= or >= to maxqueue, minqueue respectavely
		while(!v.empty() and v.front().fi+addval <= x+addval) {
			aux += v.front().se;
			v.pop_front();
		}
		v.push_front({x,aux});
		sz++;
	}

	void pop() {
		v.back().se--;
		if(v.back().se == 0) {
			v.pop_back();
		}
		sz--;
	}

	void print() {
		printf("sz %d\naddval %lld\n", sz, addval);
		for(auto x : v) {
			printf("%lld[%d] ", x.fi+addval, x.se);
		}
		cout << endl;
	}

	ll getmax() {
		return v.back().fi + addval;
	}

	void add(int x) {
		addval += x;
	}

	void clear() {
		sz = addval = 0;
		v.clear();
	}
	
};

ll w[N];
ll a[N], plank[N];
int n,d;
ll p;

ll go() {
	int b;
	b = d;
	sliding_window maxq;
	maxq.push(plank[b-d+1]);
	ll ret = min(n,d);
	for(int i=1;i+d-1<=n;i++) {
		while(b <= n and a[b] - a[i-1] - maxq.getmax() <= p) {
			ret = max(ret,(ll)b-i+1);
			b++;
			if(b <= n) maxq.push(plank[b-d+1]);
		}
		maxq.pop();
	}
	return ret;
}

int main () {
	
	scanf("%d %lld %d", &n, &p, &d);

	for(int i=1;i<=n;i++) {
		scanf("%lld", &w[i]);
		a[i] = w[i] + a[i-1];
	}

	for(int i=1;i+d-1<=n;i++) {
		plank[i] = a[i+d-1] - a[i-1];
	}

	cout << go() << endl;
	
}



