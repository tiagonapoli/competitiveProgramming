#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 20100

int inf = 9999999;

struct sliding_window {
	deque<pair<ii,int> > v;
	int addval = 0;
	int sz = 0;

	int size() {return sz;}
	
	void push(int x, int pos) {
		
	/*	printf("PUSH %d\n", x);
		printf("Antes: ");
		for(auto x : v) {
			printf("%d[%d] ", x.fi.fi+addval, x.se);
		}
		cout << endl;
	*/	x -= addval;
		int aux = 1;
		while(!v.empty() and v.front().fi.fi+addval >= x+addval) {
			aux += v.front().se;
			v.pop_front();
		}
		v.push_front({{x,pos},aux});
		sz++;
	/*	printf("Depois: ");
		for(auto x : v) {
			printf("%d[%d] ", x.fi.fi+addval, x.se);
		}
		cout << endl << endl;
	*/}

	void pop() {
		v.back().se--;
		if(v.back().se == 0) {
			v.pop_back();
		}
		sz--;
	}

	void print() {
		printf("sz %d\naddval %d\n", sz, addval);
		for(auto x : v) {
			printf("%d[%d] ", x.fi.fi+addval, x.se);
		}
		cout << endl;
	}

	ii getmin() {
		return {v.back().fi.fi + addval, v.back().fi.se};
	}

	void add(int x) {
		addval += x;
	}

	void clear() {
		sz = addval = 0;
		v.clear();
	}
	
};

int dp[2][N];
int memo[210][N];
sliding_window Q[N];
int b[N];
int qtd[210];
int w[N], n, k;

void print(int i, int j) {
	if(i == 0 or j == 0) return;
	qtd[i] = (j - memo[i][j])/w[i];
	print(i-1, memo[i][j]);
}

void sol() {

	dp[0][0] = 0;
	for(int j=1;j<N;j++) {
		dp[0][j] = inf;
	}

	for(int i=1;i<=n;i++) {
		dp[i%2][0] = 0;
		for(int j=0;j<=w[i];j++) {
			Q[j].clear();
		}
	//	printf("------ %d -----\n", i);
		for(int j=0; j <= k; j++) {
			sliding_window &q = Q[j % w[i]];
			if(q.size() >= b[i] + 1) {
				q.pop();			
			}
		
			q.add(1);
			q.push(dp[(i+1)%2][j], j);
			ii res = q.getmin();
	//		q.print();
			dp[i%2][j] = res.fi;
			memo[i][j] = res.se;	
	//		printf("[%d]  %d %d\n",j,  res.fi, res.se);
	//		cout << endl;	
		}
	}

}

int main () {

	scanf("%d", &n);

	for(int i=1;i<=n;i++) {
		scanf("%d", &w[i]);
	}

	for(int i=1;i<=n;i++) {
		scanf("%d", &b[i]);
	}

	scanf("%d", &k);


	sol();
	printf("%d\n", dp[n%2][k]);
	print(n,k);

	for(int i=1;i<=n;i++) {
		printf("%d", qtd[i]);
		if(i != n) printf(" ");
	}

	return 0;

}



