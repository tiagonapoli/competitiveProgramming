#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100

//SOLVES UVA681 - CONVEX HULL FINDING

typedef ll T;

struct pt {
    T x,y;
    pt() {}
    pt(T a, T b) {x=a,y=b;}
    pt operator+ (pt b) {return {x+b.x, y+b.y};}
    pt operator- (pt b) {return {x-b.x, y-b.y};}
	T operator* (const pt b) const {return x * b.x + y * b.y;}
	T operator^ (const pt b) const {return x * b.y - y * b.x;}
    bool operator< (const pt b) const {
        if(x == b.x) {
            return y < b.y;
        } else return x < b.x;
    }
    bool operator==(const pt b) const {return ((x == b.x) && (y == b.y));}
    void print() {printf("%lld %lld", x,y);}
};

//Retorna a area do 'paralelogramo' com 'sinal'
//AB ^ AC = (B-A)^(C-A) = A^B + B^C + C^A
T area(pt a, pt b, pt c) {
    return (a ^ b) + (b ^ c) + (c ^ a);
}

//Tira o cara do topo de up ou down se for fazer uma curva para esquerda (area positiva)
vector<pt> convex_hull(vector<pt> p) {
    vector<pt> up,dn;
    sort(p.begin(), p.end());

	if(p.size() <= 2) return p;

    up.pb(p[0]);
    up.pb(p[1]);
    //Tirar os colineares area >=
    for(int i=2;i<p.size();i++) {
        while(up.size() >= 2 && area(up[(int)up.size()-2],up[(int)up.size()-1],p[i]) >= 0) {
            up.pop_back();
        }
        up.pb(p[i]);
    }
    dn.pb(p[p.size()-1]);
    dn.pb(p[p.size()-2]);
    for(int i=p.size()-3;i>=0;i--) {
        while(dn.size() >= 2 && area(dn[(int)dn.size()-2],dn[(int)dn.size()-1],p[i]) >= 0) {
            dn.pop_back();
        }
        dn.pb(p[i]);
    }
    for(int i=1;i<dn.size();i++) {
        up.pb(dn[i]);
    }
    reverse(up.begin(), up.end());
    return up;
}


int main () {

    int t;
    int n;
    cin >> t;
    printf("%d\n", t);
    while(t--) {
        cin >> n;

        vector<pt> v;
        pt x;
        for(int i=0;i<n;i++) {
            cin >> x.x >> x.y;
            v.pb(x);
        }   

        v = convex_hull(v);
        v.pop_back();
        int idfi = 0;
        for(int i=0;i<v.size();i++) {
            if(v[i].y < v[idfi].y) {
                idfi = i;
            } else if(v[i].y == v[idfi].y && v[i].x < v[idfi].x) {
                idfi = i;
            }
        }
        
        printf("%d\n", (int)v.size()+1);
        for(int i=0;i<v.size();i++) {
            v[(idfi+i)%v.size()].print();
            printf("\n");
        }
        v[idfi].print();
        printf("\n");
        
        

        if(t != 0) {
            scanf("%*d"); 
            printf("-1\n");
        }
    }

}



