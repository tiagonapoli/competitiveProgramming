#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const long double eps = 1e-10;
#define N 100100

struct pt {
  long double x, y;
  pt operator-(const pt r) const { return {x - r.x, y - r.y}; }
  pt operator+(const pt r) const { return {x + r.x, y + r.y}; }
  pt mul(long double r) const { return {x * r, y * r}; }
  long double operator* (const pt r) const {return x * r.x + y * r.y;}
  long double operator^ (const pt r) const {return x * r.y - y * r.x;}
  long double len() const { return hypot(x,y); }
  void read() { scanf("%Lf %Lf", &x, &y); }
};

pt inter(pt a, pt b, pt c, pt d, bool &paralelo) {
	// (a,b) ^ (x,y) = 0
	// -b*x + a*y = 0
	pt ab, cd;
	pt x1,x2;
	ab = b-a;
	cd = d-c;
	pt n1 = {-ab.y, ab.x};
	pt n2 = {-cd.y, cd.x};
	long double c1 = -(n1 * a);
	long double c2 = -(n2 * c);
	long double D = n1 ^ n2;
	x1 = {n1.x, -c1};
	x2 = {n2.x, -c2};
	long double Dy = x1 ^ x2;
	x1 = {-c1, n1.y};
	x2 = {-c2, n2.y};
	long double Dx = x1 ^ x2;
	if(fabs(D) < eps) {
		paralelo = 1;
		return {0,0};
	}
	return {Dx/D, Dy/D};	
}


////////////////////////////////////////////////////////////////////////////////
// Find the smallest circle containing all the points in expected time O(N)
//

typedef pair<pt, long double> circle; // center, radius

bool in_circle(circle C, pt p) { // is point p in circle C?
	return (p - C.fi)*(p - C.fi) - eps <= (C.se*C.se);
}

// Given three points, finds center of circle containing them
circle circumcenter(pt p, pt q, pt r) {
	pt rp = p-r;
	pt rq = q-r;
	if(fabs(rp ^ rq) < eps) {
		if((rp * rq) < -eps) {
			return circle((p + q).mul(0.5L), (p-q).len()/2.0L);
		} else {
			if(rp.len() < rq.len()) {
				return circle((r + q).mul(0.5L), (r-q).len()/2.0L);
			} else {
				return circle((r + p).mul(0.5L), (r-p).len()/2.0L);
			}
		}
	}
	pt A = (p+r).mul(0.5L);
	pt B = (q+r).mul(0.5L);
	pt dirA = {-rp.y, rp.x};
	pt dirB = {-rq.y, rq.x};
	bool paralelo = 0;
	pt center = inter(A,A+dirA, B, B+dirB, paralelo);
	return {center, (center-p).len()};
}


circle min_spanning_circle (vector<pt> &v) {
	srand(time(NULL)); 
	int sz = v.size();
	random_shuffle(v.begin(), v.end()); 
	circle c({0,0}, 0);
	for (int i = 0; i < sz; i++) { 
		if (!in_circle(c,v[i])) {
			c = circle(v[i], 0);
			for (int j = 0; j < i; j++) { 
				if (!in_circle(c,v[j])) {
					c = circle((v[i] + v[j]).mul(0.5L), (v[i]-v[j]).len()/2.0L);
					for (int k = 0; k < j; k++) {
						if (!in_circle(c,v[k])) {
							c = circumcenter(v[i],v[j],v[k]);
						}
					}
				}
			}
		}
	}
    return c;
}

int main() {

	int n;
	vector<ii> v;

	scanf("%d", &n);

	ii x;
	for(int i=0;i<n;i++) {
		scanf("%d %d", &x.fi, &x.se);
		v.pb(x);
	}

	sort(v.begin(), v.end());
	auto it = unique(v.begin(), v.end());
	v.resize(distance(v.begin(), it));
	
	vector<pt> vv;
	
	for(int i=0;i<v.size();i++) {
		vv.pb({(long double) v[i].fi, (long double) v[i].se});
	}

	circle res = min_spanning_circle(vv);
	
	printf("%.15lf %.15lf\n%.15lf\n", (double)res.fi.x, (double)res.fi.y, (double)	res.se);

}
