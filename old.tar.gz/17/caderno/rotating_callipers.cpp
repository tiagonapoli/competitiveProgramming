#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100

//SOLVES UVA681 - CONVEX HULL FINDING

typedef ll T;

struct pt {

    T x,y;
    pt() {}
    pt(T a, T b) {x=a,y=b;}
    pt operator- (pt b) {
        pt res(x-b.x,y-b.y);
        return res;
    }
	T operator* (const pt b) const {
		return x * b.x + y * b.y;
	}
	T operator^ (const pt b) const {
		return x * b.y - y * b.x;
	}
    bool operator< (const pt b) const {
        if(x == b.x) {
            return y < b.y;
        } else return x < b.x;
    }
    bool operator==(const pt b) const {return ((x == b.x) && (y == b.y));}
    void print() {printf("%lld %lld", x,y);}
};

T cross(pt a, pt b) {
    return a.x*b.y - a.y*b.x;
}

//Retorna a area do 'paralelogramo' com 'sinal'
//AB ^ AC = (B-A)^(C-A) = A^B + B^C + C^A
T area(pt a, pt b, pt c) {
    return cross(a,b) + cross(b,c) + cross(c,a);
}

//Tira o cara do topo de up ou down se for fazer uma curva para esquerda (area positiva)
vector<pt> convex_hull(vector<pt> p) {
    vector<pt> up,dn;
    sort(p.begin(), p.end());

	if(p.size() <= 2) return p;

    up.pb(p[0]);
    up.pb(p[1]);
    //Tirar os colineares area >=
    for(int i=2;i<p.size();i++) {
        while(up.size() >= 2 && area(up[(int)up.size()-2],up[(int)up.size()-1],p[i]) >= 0) {
            up.pop_back();
        }
        up.pb(p[i]);
    }
    dn.pb(p[p.size()-1]);
    dn.pb(p[p.size()-2]);
    for(int i=p.size()-3;i>=0;i--) {
        while(dn.size() >= 2 && area(dn[(int)dn.size()-2],dn[(int)dn.size()-1],p[i]) >= 0) {
            dn.pop_back();
        }
        dn.pb(p[i]);
    }
    for(int i=1;i<dn.size();i++) {
        up.pb(dn[i]);
    }
	reverse(up.begin(), up.end());
    up.pop_back();
	return up;
}

ll dist(pt a, pt b) {
	return (a-b) * (a-b);
}

ll rotating_callipers(vector<pt> &p) {

	vector<ll> res(p.size(),0);
	
	int to = 0;
	pt a,b,c,d;
	pt ab,ac,ad;
	ll aux;
	for(int i=0;i<p.size();i++) {
		a = p[i];
		b = p[(i+1) % p.size()];
		ab = b-a;
		aux = dist(a, p[to]);
		while((to + 1) % p.size() != i) {
			c = p[to];
			d = p[(to+1) % p.size()];
			ac = c-a;
			ad = d-a;
			aux = max(aux, max(dist(a,c), dist(a,d)));
			if(abs(ab ^ ac) <= abs(ab ^ ad)) {
				//distancia de d a reta ab [e maior
				to = (to + 1) % p.size();
			} else break;
		}
		prin(i);
		prin(to);
		separa();
		res[i] = aux;
	}

	ll ret = 0;
	for(int i=0;i<p.size();i++) {
		ret = max(ret, res[i]);
//		printf("[%lld %lld] = %lld\n",p[i].x, p[i].y, res[i]);
	}
	return ret;
}




int main () {

	int n;
	vector<pt> v;
	pt x;

	cin >> n;

	for(int i=0;i<n;i++) {
		cin >> x.x >> x.y;
		v.pb(x);
	}

	vector<pt> convex = convex_hull(v);
	printf("%lld\n", rotating_callipers(convex));

}



