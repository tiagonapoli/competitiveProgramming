#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100

//SOLVES UVA681 - CONVEX HULL FINDING

typedef ll T;

struct pt {

    T x,y;
    pt() {}
    pt(T a, T b) {x=a,y=b;}
    pt operator- (pt b) {
        pt res(x-b.x,y-b.y);
        return res;
    }
	T operator* (const pt b) const {
		return x * b.x + y * b.y;
	}
	T operator^ (const pt b) const {
		return x * b.y - y * b.x;
	}
    bool operator< (const pt b) const {
        if(x == b.x) {
            return y < b.y;
        } else return x < b.x;
    }
    bool operator==(const pt b) const {return ((x == b.x) && (y == b.y));}
    void print() {printf("%lld %lld", x,y);}
};

T cross(pt a, pt b) {
    return a.x*b.y - a.y*b.x;
}

//Retorna a area do 'paralelogramo' com 'sinal'
//AB ^ AC = (B-A)^(C-A) = A^B + B^C + C^A
T area(pt a, pt b, pt c) {
    return cross(a,b) + cross(b,c) + cross(c,a);
}

//Tira o cara do topo de up ou down se for fazer uma curva para esquerda (area positiva)
vector<pt> convex_hull(vector<pt> p) {
    vector<pt> up,dn;
    sort(p.begin(), p.end());

	if(p.size() <= 2) return p;

    up.pb(p[0]);
    up.pb(p[1]);
    //Tirar os colineares area >=
    for(int i=2;i<p.size();i++) {
        while(up.size() >= 2 && area(up[(int)up.size()-2],up[(int)up.size()-1],p[i]) >= 0) {
            up.pop_back();
        }
        up.pb(p[i]);
    }
    dn.pb(p[p.size()-1]);
    dn.pb(p[p.size()-2]);
    for(int i=p.size()-3;i>=0;i--) {
        while(dn.size() >= 2 && area(dn[(int)dn.size()-2],dn[(int)dn.size()-1],p[i]) >= 0) {
            dn.pop_back();
        }
        dn.pb(p[i]);
    }
    for(int i=1;i<dn.size();i++) {
        up.pb(dn[i]);
    }
	reverse(up.begin(), up.end());
	up.pop_back();
	return up;
}

ll dist(pt a, pt b) {
	return (a-b) * (a-b);
}


ll rotating_callipers(vector<pt> &p, vector<pt> &q) {

	int a,b;
	a = b = 0;
	int n = p.size(), m = q.size();
	for(int i=0;i<n;i++) if(p[i].y > p[a].y) a = i;
	for(int i=0;i<m;i++) if(q[i].y > q[b].y) b = i;
	if(n == 0 or m == 0) return 0;
	p.pb(p[0]);
	q.pb(q[0]);

	if(debug) {

		printf("\nConvex 1\n");
		for(int i=0;i<=n;i++) {
			p[i].print();
			cout << endl;
		}
		printf("Convex 2\n");
		for(int i=0;i<=m;i++) {
			q[i].print();
			cout << endl;
		}
		cout << endl;
	}

	ll ans = 0;
	for(int i = 0; i < n ; i++) {
		pt ab,ac,ad;
		ab = p[a+1] - p[a];
		ac = q[b] - p[a];
		ad = q[b+1] - p[a];
		
		prin(a);
		prin(b);
		if(debug) {
			printf("AAA\n");
			printf("A: ");
			p[a].print();
			separa();
			printf("A+1: ");
			p[(a+1)%n].print();
			separa();
			printf("B: ");
			q[b].print();
			separa();
			printf("B+1: ");
			q[(b+1)%m].print();
			separa();
			prin(ab ^ ad);
			prin(ab ^ ac);
			cout << endl;
		}

		for(pt u : {p[a], p[a+1]}) {
			for(pt w : {q[b], q[b+1]}) {
				ans = max(ans, dist(u,w));
			}
		}
		
		while((ab ^ ac) < (ab ^ ad)) {
			b = (b + 1) % m;
			ac = q[b] - p[a];
			ad = q[b+1] - p[a];
			if(debug) {
				cout << endl;
				printf("B: ");
				q[b].print();
				separa();
				printf("B+1: ");
				q[(b+1)%m].print();
				separa();
				prin(ab ^ ad);
				prin(ab ^ ac);
				cout << endl;
			}
			for(pt u : {p[a], p[a+1]}) {
				for(pt w : {q[b], q[b+1]}) {
					ans = max(ans, dist(u,w));
				}
			}
		}

		
		a = (a + 1)%n;
	}
	
	p.pop_back();
	q.pop_back();
	return ans;
}




int main () {

	int n,m;
	vector<pt> v1,v2;
	pt x;

	cin >> n;
	for(int i=0;i<n;i++) {
		cin >> x.x >> x.y;
		v1.pb(x);
	}
	cin >> m;
	for(int i=0;i<m;i++) {
		cin >> x.x >> x.y;
		v2.pb(x);	
	}

	v1 = convex_hull(v1);
	v2 = convex_hull(v2);

	if(debug) {
		cout << rotating_callipers(v1,v2) << endl << endl << endl;
		cout << rotating_callipers(v2,v1) << endl << endl << endl;

	} else {
		cout << max(rotating_callipers(v1,v2), rotating_callipers(v2,v1)) << endl;
	}


}



