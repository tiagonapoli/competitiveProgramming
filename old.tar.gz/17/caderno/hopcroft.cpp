#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define print(a) cout << #a << " = " << (a) << endl
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 500100

int INF = 9999999;
int NIL = 0;
vector<int> adj[N];
int n,m, match[N], dist[N];

//n: number of nodes left side, numbered 1->n
//m: number of nodes rigth side, numbered n+1->n+m
//G = NIL[0] U G1[G[1...n]] U G2[G[n+1...m+n]]


bool bfs() {

    queue<int> fila;
    dist[NIL] = INF;
    for(int i=1;i<=n;i++) {
        dist[i] = INF;
        if(match[i] == NIL) {
            dist[i] = 0;
            fila.push(i);
        }
    }

    while(!fila.empty()) {
        int u = fila.front();
        fila.pop();

        if(u != NIL) {
            for(int v : adj[u]) {
                if(dist[match[v]] == INF) {
                    dist[match[v]] = dist[u] + 1;
                    fila.push(match[v]);
                }
            }
        }

    }
    return (dist[NIL] != INF);
}

bool dfs(int u) {
    if(u == NIL) return true;
    for(int v : adj[u]) {
        if(dist[match[v]] == dist[u] + 1) {
            if(dfs(match[v])) {
                match[u] = v;
                match[v] = u;
                //marca aquele vertice como nao usavel
                dist[u] = INF;
                return true;
            }
        }
    }
    //marca aquele vertice como nao usavel
    dist[u] = INF;
    return false;
}

int hopcroft_karp() {
    int res = 0;
    for(int i=0;i<=n+m+5;i++) {
        match[i] = NIL;
    }

    while(bfs()) {
        for(int i=1;i<=n;i++) {
            if(match[i] == NIL && dfs(i)) {
                res++;    
            }
        }

    }
    return res;
}


int main () {
    
    int p;

    scanf("%d %d %d", &n, &m, &p);
    
    int a,b;
    for(int i=0;i<p;i++) {
        scanf("%d %d", &a, &b);
        adj[a].pb(b+n);
    }

    printf("%d\n", hopcroft_karp());

}
