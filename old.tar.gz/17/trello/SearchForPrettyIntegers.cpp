#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define debug(args...) if(debug) fprintf(stderr,args)
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define frrs(i,a,b) for(int i = (a); i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

int cnt[10];

int main () {

	int n,m;

	cin >> n >> m;

	int a,b;
	
	a = b = 99;
	int x;
	for(int i=0;i<n;i++) {
		cin >> x;
		cnt[x]++;
		a = min(x,a);
	}
	
	for(int i=0;i<m;i++) {
		cin >> x;
		cnt[x]++;
		b = min(x,b);
	}

	for(int i=0;i<10;i++) {
		if(cnt[i] == 2) {
			cout << i << endl;
			return 0;
		}
	}

	cout << min(a,b)*10 + max(a,b) << endl;

	

	return 0;

}



