#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

set<int> batch;
int v[N];

void fim(int x) {
  printf("%d\n", x);
  exit(0);
}

int main () {
  
  int n,x;

  scanf("%d %d", &n, &x);

  for(int i=0;i<n;i++) {
    scanf("%d", &v[i]);
  }

  //0
  for(int i=0;i<n;i++) {
    if(batch.find(v[i]) != batch.end()) fim(0);
    batch.insert(v[i]);
  }

  //1
  for(int i=0;i<n;i++) {
    if((v[i] & x) != v[i] && batch.find(v[i] & x) != batch.end()) fim(1);
  }
  
  //2
  for(int i=0;i<n;i++) {
    if((v[i] & x) != v[i] && batch.find(v[i] & x) != batch.end()) fim(2);
    batch.insert(v[i] & x);
  }
  
  fim(-1); 
  return 0;

}



