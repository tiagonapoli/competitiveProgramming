#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 1010

int n,m;
double a[N], b[N];

bool check(double x) {
  double gasto = 0;
  double w = m + x;
  double aux;
  for(int i=0;i<n;i++) { 
    aux = w/a[i];
    gasto += aux;
    w -= aux;
    aux = w/b[i];
    gasto += aux; 
    w -= aux; 
  } 
  return gasto <= x+eps;
}

time_t ini;
double bs() {
  double lo=0,hi=1000000100.0;
  double mid;
  
  while(((double)(clock() - ini))/CLOCKS_PER_SEC < 0.8) {
    mid = (lo + hi) / 2.0;
    if(check(mid)) {
      hi = mid;
    } else lo = mid;
  }
  return hi;
}

int main () {

  ini = clock();
  scanf("%d %d", &n, &m);

  for(int i=0;i<n;i++) {
    scanf("%lf", &a[i]);
  }

  for(int i=0;i<n;i++) {
    scanf("%lf", &b[i]);
  }

  double res = bs();
  if(res > (1e9)+1) {
    printf("-1\n");
  } else printf("%lf\n", res);

	return 0;

}



