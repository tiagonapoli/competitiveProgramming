#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

ll x,d;
int n,m;
ll calc(ll pos) {
  return pos*(pos+1)/2 + (n-pos-1LL)*(n-pos)/2;
}

int main () {
  

  scanf("%d %d", &n, &m);
  ll res = 0;
  for(int i=0;i<m;i++) {
    scanf("%lld %lld", &x, &d);
    res += n * x;
    if(d > 0) {
      res += d * calc(0);
    } else { 
      res += d * calc(n/2);
    }
  }

  printf("%lf\n", res/(double)n);
  


	return 0;

}



