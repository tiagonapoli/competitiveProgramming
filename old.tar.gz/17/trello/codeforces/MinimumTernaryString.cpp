#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

string res;
queue<char> fila;

int main () {
  
  int cnt = 0;
  string s;

  cin >> s;
  for(int i=0;i<s.size();i++) {
    if(s[i] == '1') cnt++;
    else fila.push(s[i]);
  }
  
  while(!fila.empty()) {
    if(cnt == 0 || fila.front() == '0') {
      res.pb(fila.front());
      fila.pop();
    } else {
      res.pb('1');
      cnt--;
    }
  }

  while(cnt > 0) {
    res.pb('1');
    cnt--;
  }

  cout << res << endl;

	return 0;

}



