#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 200100

int pai[N];
int cnt;
vector<int> lin[N];
vector<int> col[N];

void reset(int x) {
  for(int i=0;i<N;i++) {
    pai[i] = i;
  }
  cnt = x;
}

int find(int x) {
  if(pai[x] == x) return x;
  return pai[x] = find(pai[x]);
}

void join(int a, int b) {
  a = find(a);
  b = find(b);
  if(a != b) {
    pai[b] = a;
    cnt--;
  }
}

int sol(int dim, int sz, vector<int> *v) {
  
  reset(sz);
  prin(dim);
  prin(cnt);
  int zerado = 0;
  for(int i=0;i<dim;i++) { 
    if(v[i].size() == 0) zerado++;
    for(int j : v[i]) {
      join(v[i][0], j);
    }
  }
  prin(cnt);
  separa();
  return cnt - 1 + zerado;
}

int main () {

  int n,m,q;
  scanf("%d %d %d", &n, &m, &q);
  
  

  int x,y;
  for(int i=0;i<q;i++) {
    scanf("%d %d", &x, &y);
    x--;
    y--;
    lin[x].pb(y);
    col[y].pb(x);
  }
  
  int res = min(sol(m,n,col), sol(n,m,lin));
  cout << res << endl;
	return 0;
}



