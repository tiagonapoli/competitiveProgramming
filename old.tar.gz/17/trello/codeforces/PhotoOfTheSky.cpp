#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 200100

ll area(ll x1, ll x2, ll y1, ll y2) {
  return abs(x1 - x2) * abs(y1 - y2);
}

int v[N];
int main () {

  int n;

  scanf("%d", &n);
  for(int i=0;i<2*n;i++) {
    scanf("%d", &v[i]);
  }
  
  sort(v,v+2*n);

  ll res = area(v[0],v[n-1],v[n], v[2*n-1]);
  for(int i=1;i<n;i++) {
    res = min(res, area(v[0],v[2*n-1],v[i], v[i+n-1]));
  }
  cout << res << endl; 

	return 0;

}



