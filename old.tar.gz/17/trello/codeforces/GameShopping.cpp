#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100


int main () {

  int n,m;
  int c[N], a[N];

  cin >> n >> m;

  for(int i=0;i<n;i++) {
    scanf("%d", &c[i]);
  }

  for(int i=0;i<m;i++) {
    scanf("%d", &a[i]);
  }

  int j = 0;
  for(int i=0;i<n;i++) {
    if(j < m and c[i] <= a[j]) j++; 
  }


  cout << j << endl;

	return 0;

}



