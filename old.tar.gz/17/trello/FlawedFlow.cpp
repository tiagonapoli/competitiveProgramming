#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 200100

vector<pair<ii,int> > adj[N];
int dir[2*N];
int fl[N];
int n,m;
int source,sink;

void bfs() {
	for(int i=1;i<=n;i++) {
		for(pair<ii,int> j : adj[i]) {
			fl[i] += j.fi.se;
		}
		fl[i] /= 2;
	}
	queue<int> fila;
	fila.push(source);
	while(!fila.empty()) {
		int x = fila.front();
		fila.pop();
		for(pair<ii,int> e : adj[x]) {
			int id = e.se;
			if(id & 1) id ^= 1;
			if(dir[id] != -1) continue;
			if(e.se & 1) {
				dir[id] = 1;
			} else dir[id] = 0;
			fl[e.fi.fi] -= e.fi.se;
			if(fl[e.fi.fi] == 0 and e.fi.fi != sink) {
				fila.push(e.fi.fi);
			}
		}
	}
}

int main () {

	scanf("%d %d", &n, &m);

	int a,b,c;
	for(int i=1;i<=m;i++) {
		dir[2*i] = -1;
		scanf("%d %d %d", &a, &b, &c);
		adj[a].pb({{b,c},2*i});
		adj[b].pb({{a,c},2*i+1});
	}

	source = 1;
	sink = n;
	bfs();

	for(int i=1;i<=m;i++) {
		printf("%d\n", dir[2*i]);
	}



	return 0;

}



