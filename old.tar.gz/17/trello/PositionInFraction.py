

def main():
	
	a,b,c = map(int, input().split())

	a -= (a//b) * b;

	for i in range(1,1000000):
		a *= 10
		quo = a // b
		if quo == c:
			print(i)
			exit()
		a -= quo * b;
	
	print(-1)
	
	return(0)

main()
