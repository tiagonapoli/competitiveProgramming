#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

const int MAXN = 500; 	//number of vertices
const int INF = 1000000000; //infinity
 
struct node{
	int v,f,c,val;
	node(){}
	node (int _v, int _f, int _c, int _val) {
		v = _v;
		f = _f;
		c = _c;
		val = _val;
	}
};

int vertices;
vector<node> edges;
vector<int> graph[MAXN];
int dist[MAXN], ptr[MAXN], pai[MAXN];

void add_edge (int u, int v, int c, int val) {
	graph[u].pb(edges.size());
	edges.pb(node(v,0,c,val));
	graph[v].pb(edges.size());
	edges.pb(node(u,0,0,-val));
}

ii operator+ (ii a, ii b) {
	a.fi += b.fi;
	a.se += b.se;
	return  a;
}

bool dijkstra(int s, int t) {
	for(int i=0;i<vertices;i++) {
		dist[i] = INF;
		pai[i] = -1;
	}
	dist[s] = 0;
	priority_queue<ii,vector<ii>,greater<ii>> q;
	q.push(ii(0,s));
	
	while(!q.empty()) {
		int d = q.top().fi;
		int u = q.top().se;
		q.pop();
		
		if(d > dist[u]) continue;

		for(auto e : graph[u]) {
			if(dist[u] + edges[e].val < dist[edges[e].v] && edges[e].c-edges[e].f > 0) {
				dist[edges[e].v] = dist[u] + edges[e].val;
				pai[edges[e].v] = u;
				q.push({dist[edges[e].v], edges[e].v});
			}
		}
	}

	return dist[t] != INF;
}

ii dfs_mincost(int s, int t, int f) {
	if(s == t) {
		return ii(0,f);
	}

	for(int &i = ptr[s];i < graph[s].size(); i++) {
		int e = graph[s][i];
		if(pai[edges[e].v] == s && dist[edges[e].v] == dist[s] + edges[e].val && edges[e].c-edges[e].f > 0) {
			ii x = ii(edges[e].val, 0) + dfs_mincost(edges[e].v, t, min(f,edges[e].c - edges[e].f));
			if(x.se) {
				edges[e].f += x.se;
				edges[e^1].f -= x.se;
				return x;
			}
		}
	}
	return ii(0,0);
}

int s,t; 
ii minimum_cost() {
	ii ans(0,0);
	while(dijkstra(s,t)) {
		memset(ptr,0,sizeof ptr);
		ii x;
		while((x = dfs_mincost(s,t,INF)).se) {
			ans = ans + x;
		}
	}
	return ans;
}

 
int qtd[27];
int main () {
	
	string x;

	int nn;
	cin >> x;
	cin >> nn;
	for(int i=0;i<x.size();i++) {
		qtd[x[i]-'a'+1]++;
	}
	s = 0;
	t = 27;
	for(int i=1;i<=26;i++) {
		add_edge(i,t,qtd[i],0);
	}


	string a;
	int lim;
	for(int i=0;i<nn;i++) {
		cin >> a >> lim;
		for(int j=0;j<=26;j++) qtd[j] = 0;
		for(int j=0;j<a.size();j++) {
			qtd[a[j]-'a'+1]++;
		}
		add_edge(s,t+i+1,lim,i+1);
		for(int j=1;j<=26;j++) {
			add_edge(t+i+1,j,qtd[j],0);
		}
	}

	vertices = nn + 30;

	ii r = minimum_cost();
	if(r.se != x.size()) {
		cout << -1 << endl;
		return 0;
	}
	printf("%d %d\n", r.fi, r.se);
	

	return 0;

}
