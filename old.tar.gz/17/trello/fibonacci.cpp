#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 10
#define PI acos(-1.0)
#define sqr(x) x*x
#define debug printf
using namespace std;
const double eps = 1e-9;
typedef int pt_type;
#define N 2

int sz = 2;
void cpy(ll s[N][N], ll t[N][N]) {
	for(int i=0;i<sz;i++) {
		for(int j=0;j<sz;j++) {
			t[i][j] = s[i][j];
		}
	}
}

void mul(ll a[N][N], ll b[N][N], ll c[N][N]) {
	for(int i=0;i<sz;i++) {
		for(int j=0;j<sz;j++) {
			c[i][j] = 0;
			for(int k=0;k<sz;k++) {
				c[i][j] += (a[i][k] * b[k][j]) % MOD;
				c[i][j] %= MOD;
			}
		}
	}
}

ll c[N][N];
ll res[N][N];
void fast_pow(ll asd[N][N], int e) {
	ll b[N][N];
	for(int i=0;i<2;i++) {
		for(int j=0;j<2;j++) {
			b[i][j] = asd[i][j];
		}
	}
	for(int i=0;i<sz;i++) {
		for(int j=0;j<sz;j++) {
			res[i][j] = 0;
			if(i == j) res[i][j] = 1LL;
		}
	}

	while(e > 0) {
		if(e & 1) {
			mul(res,b,c);
			cpy(c,res);
		}
		mul(b,b,c);
		cpy(c,b);
		e >>= 1;
	}
}

int main () {
	int t;
	ll a[][2] = {1LL, 1LL, 
				1LL, 0LL
				};
	int n;
	scanf("%d", &t);
	while(t--) {
		scanf("%d", &n);
		fast_pow(a,n-1);
		printf("%lld\n",(res[0][0] + res[0][1]) % 10);
	}

}




