#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

ll v[20];
ll dp[1<<20][20];
int n,m,k;
ll adj[20][20];

bool setado(int mask, int i) {
	return (mask & (1 << i)) != 0;
}

ll solve(int mask, int last) {
	if(dp[mask][last] != -1LL) return dp[mask][last];	
	if(mask == 0) return dp[mask][last] = 0;
	if(__builtin_popcountll(mask) > m) return dp[mask][last] = 0;	
	ll res = 0;
	for(int i=0;i<n;i++) {
		if(setado(mask,i)) {
			res = max(res, v[i] + solve(mask-(1<<i),i) + adj[last][i]); 	
		}
	}
	return dp[mask][last] = res;
}

int main () {

	cin >> n >> m >> k;

	for(int i=0;i<n;i++) {
		cin >> v[i];
	}

	int a,b;
	for(int i=0;i<k;i++) {
		cin >> a >> b;
		a--;
		b--;
		cin >> adj[a][b];
	}

	for(int i=0;i<(1<<n);i++){ 
		for(int j=0;j<20;j++) {
			dp[i][j] = -1LL;
		}
	}

	ll res = 0;
	for(int i=0;i<(1<<n);i++) {
		res = max(res,solve(i,19));
	}

	cout << res << endl;
	

	return 0;

}



