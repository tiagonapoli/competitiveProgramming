
def main():
	
	k,p = map(int, input().split())

	res = 0
	for i in range(1,k+1):
		s = str(i)
		s += s[::-1]
		res += (int(s) % p)
		res %= p

	print(res)



main()
