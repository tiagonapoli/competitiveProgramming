#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

pair<ii,int> v[8][3];
int grid[400][400];

bool setado(int mask, int i) {
	return (mask & (1 << i)) != 0;
}

bool check2(int x, int y) {
	if(x != y) return 0;
	for(int i=0;i<x;i++) {
		for(int j=0;j<y;j++) {
			if(grid[i][j] == -1) return 0;
		}
	}
	return 1;	
}

void print(int x, int y) {
	cout << x << endl;
	for(int i=0;i<x;i++){
		for(int j=0;j<y;j++) {
			printf("%c", 'A' + grid[i][j]);
		}
		cout << endl;
	}
	cout << endl;
}

void ini(int x, int y) {
	for(int i=0;i<x;i++) {
		for(int j=0;j<y;j++) {
			grid[i][j] = -1;
		}
	}
}

bool check(int xx) {

//	printf("%d/%d[%c] %d/%d[%c] %d/%d[%c]\n", v[xx][0].fi.fi, v[xx][0].fi.se,v[xx][0].se+'A', v[xx][1].fi.fi, v[xx][1].fi.se,v[xx][1].se+'A', v[xx][2].fi.fi, v[xx][2].fi.se,'A'+v[xx][2].se);

	int maxx = 0;
	int maxy = 0;
	if(v[xx][0].fi.fi == v[xx][1].fi.fi  and v[xx][0].fi.fi == v[xx][2].fi.fi) {
		maxx = v[xx][0].fi.fi;
		maxy = v[xx][0].fi.se + v[xx][1].fi.se + v[xx][2].fi.se;
		ini(maxx,maxy);
		for(int i=0;i<v[xx][0].fi.fi;i++) {
			for(int j=0;j<v[xx][0].fi.se;j++) {
				grid[i][j] = v[xx][0].se;
			}
			
		}
		for(int i=0;i<v[xx][0].fi.fi;i++) {
			for(int j=v[xx][0].fi.se;j < v[xx][0].fi.se + v[xx][1].fi.se;j++) {
				grid[i][j] = v[xx][1].se;	
			}
		}	
		for(int i=0;i<v[xx][0].fi.fi;i++) {
			for(int j=v[xx][1].fi.se+v[xx][0].fi.se;j < maxy; j++) {
				grid[i][j] = v[xx][2].se;
			}
		}
//		printf("1!!!\n");
//		print(maxx,maxy);
		if(check2(maxx,maxy)) {
			print(maxx,maxy);
			exit(0);
		}
	}

	maxx = 0;
	maxy = 0;

	if(v[xx][0].fi.fi == v[xx][1].fi.fi and v[xx][0].fi.se + v[xx][1].fi.se == v[xx][2].fi.se) {
		maxx = v[xx][0].fi.fi + v[xx][2].fi.fi;
		maxy = v[xx][2].fi.se;
		ini(maxx,maxy);

		for(int i=0;i<v[xx][0].fi.fi;i++) {
			for(int j=0;j<v[xx][0].fi.se;j++) {
				grid[i][j] = v[xx][0].se;
			}
		}
		for(int i=0;i<v[xx][0].fi.fi;i++) {
			for(int j=v[xx][0].fi.se;j<maxy;j++) {
				grid[i][j] = v[xx][1].se;
			}
		}
		for(int i=v[xx][0].fi.fi;i < maxx;i++) {
			for(int j=0;j<maxy;j++) {
				grid[i][j] = v[xx][2].se;
			}
		}
//		printf("2!!!\n");
//		print(maxx,maxy);
		if(check2(maxx,maxy)) {
			print(maxx,maxy);		
			exit(0);
		}
	}
	
	return 0;
}

int main () {

	cin >> v[0][0].fi.fi >> v[0][0].fi.se >> v[0][1].fi.fi >> v[0][1].fi.se >> v[0][2].fi.fi >> v[0][2].fi.se;
	v[0][0].se = 0;
	v[0][1].se = 1;
	v[0][2].se = 2;

	for(int i=1;i<8;i++) {
		for(int j=0;j<3;j++) {
			v[i][j] = v[0][j];
		}
	}

	for(int i=0;i<8;i++) {
		for(int j=0;j<3;j++) {
			if(setado(i,j)) {
				swap(v[i][j].fi.fi, v[i][j].fi.se);
			}
		}
		sort(v[i],v[i]+3);
	}

	for(int i=0;i<8;i++) {
		prin(i);
		do {
			check(i);
		} while(next_permutation(v[i],v[i]+3));
	}

	cout << -1 << endl;
	return 0;

}



