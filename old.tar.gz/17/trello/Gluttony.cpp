#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

int ordem[30];
int v[30];
int v2[30];

int main () {

	int n;

	cin >> n;

	for(int i=0;i<n;i++) {
		cin >> v[i];
		v2[i] = v[i];
	}

	sort(v2,v2+n);
	
	for(int i=0;i<n;i++) {
		for(int j=0;j<n;j++) {
			if(v2[j] == v[i]) {
				ordem[i] = j;
				break;
			}
		}
	}

	int v3[30];

	for(int i=0;i<n;i++) {
		v3[i] = v2[(ordem[i]+1)%n];
	}

	for(int i=0;i<n;i++) {
		printf("%d ", v3[i]);
	}

	return 0;

}



