#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

int v[N];
int a[N];

int main () {

	int n,k;

	cin >> n >> k;
	
	fr(i,n) {
		cin >> v[i];
	}

	int res = v[0];
	if(k >= 3) {
		int maxi = v[0];
		for(int i=0;i<n;i++) {
			maxi = max(v[i], maxi);
		}
		cout << maxi << endl;
		return 0;
	} else if(k == 1) {
		int mini = v[0];
		for(int i=0;i<n;i++) {
			mini = min(mini, v[i]);
		}
		cout << mini << endl;
		return 0;
	} else {
		a[0] = v[0];
		for(int i=1;i<n;i++) {
			a[i] = min(a[i-1], v[i]);
		}
		int mini = v[n-1];
		for(int i=n-1;i>0;i--) {
			mini = min(mini, v[i]);
			res = max(max(a[n-i-1],mini), res);
		}
		
	}
	
	cout << res << endl;


	return 0;

}



