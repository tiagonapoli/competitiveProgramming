#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 300100

ll alt[N];
ll a,b,c,d,start,len,n;
ll tempo[N];
bool event[N];
multiset<ll> heap;

bool check(ll now, int tnow, int j) {
	prin(now);
	prin(tnow);
	prin(j);
	ll menor = 0;
	if(now < 0) {
		cout << -1 << endl;
		exit(0);
	}
	int sz = heap.size();
	if(!heap.empty()) {
		menor = (*heap.begin());
		if(j-sz-1 >= 0) menor -= alt[j-sz-1];
	}
	prin(menor);
	prin(sz);
	separa();
	if(now + menor >= 0) {
		cout << tnow << endl;
		exit(0);
	}
}

int main () {

	scanf("%lld %lld %lld %lld %lld %lld %lld", &n, &a, &b, &c, &d, &start, &len);

	ll t;
	int ev;
	for(int i=0;i<n;i++) {
		scanf("%lld %d", &t, &ev);
		tempo[i] = t;
		event[i] = ev;
		if(i > 0) alt[i] = alt[i-1];
		if(ev == 0) {
			alt[i] -= d;
		} else {
			alt[i] += c;
		}
	}

	ll now = start;
	int j = 0;
	int tnow = 0;
	while(j < n and tempo[j] < tnow + len) {
		heap.insert(alt[j]);
		j++;
	}

	check(now, tnow,j);
	for(int i=0;i<n;i++) {
		tnow = tempo[i] + 1;
		if(heap.find(alt[i]) != heap.end()) heap.erase(heap.find(alt[i]));
		
		if(event[i] == 0) {
			now -= b;
		} else {
			now += a;
		}

		while(j < n and tempo[j] < tnow + len) {
			heap.insert(alt[j]);
			j++;			
		}

		check(now, tnow,j);
	}

	return 0;

}



