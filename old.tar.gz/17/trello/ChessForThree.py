
n = int(input())

arr = []
for i in range(n):
	arr.append(int(input()))

a = 1
b = 2
idle = 3

for i in range(n):
	if arr[i] == idle:
		print("NO")
		exit()
	
	if a == arr[i]: 
		idle,b = b,idle
	elif b == arr[i]:
		idle,a = a,idle
	
print("YES")


