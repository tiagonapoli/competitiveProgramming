#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 3000

vector<int> dif[N][N];
string v[N];
set<string> t;

int main () {

	int n,k;

	cin >> k >> n;

	for(int i=0;i<k;i++) {
		cin >> v[i];
	}

	for(int i=0;i<k;i++) {
		for(int j=i+1;j<k;j++) {
			for(int l=0;l<n;l++) {
				if(v[i][l] != v[j][l]) {
					dif[i][j].pb(l);
				}
			}
			if(dif[i][j].size() > 4 or dif[i][j].size() == 1) {
				cout << -1 << endl;
				return 0;
			}
		}
	}

	for(int i=0;i<k;i++) {
		for(int j=i+1;j<k;j++) {
			string s = v[i];
			for(int l=0;l<dif[i][j].size();l++) {
				for(int l1=l+1;l1<dif[i][j].size();l1++) {
					swap(s[dif[i][j][l]], s[dif[i][j][l1]]);
					t.insert(s);
					swap(s[dif[i][j][l]], s[dif[i][j][l1]]);
				}
			}
		}
	}

	string x;
	bool res = 0;
	for(string s : t) {
		prin(s);
		for(int i=0;i<k;i++) {
			res = 1;
			int cont = 0;
			for(int j=0;j<n;j++) {
				if(v[i][j] != s[j]) {
					cont++;
					if(cont > 2) break;
				}
				
			}
			prin(v[i]);
			prin(cont);
			if(cont != 0 and cont != 2) {
				res = 0;
				break;
			}
		}
		separa();	
		if(res == 1) { 
			cout << s;
			break;
		}
	}

	if(res == 0) cout << -1 << endl;
	


	return 0;

}



