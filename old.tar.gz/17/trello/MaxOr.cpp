#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define debug(args...) if(debug) fprintf(stderr,args)
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define frrs(i,a,b) for(int i = (a); i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 135000
#define BIT 4
int addbit(int x, int i) {
	if((x & (1 << i)) != 0) return x;
	return (x + (1 << i));
}

int delbit(int x, int i) {
	if(x & (1 << i)) return (x - (1 << i));
	return x;
}

int inv(int x) {
	return ((1 << BIT)-1LL) - x;
}

int b[N];
int c[N];
int dp[N][20];
int cnt[N];

bool is_submask(int x, int f) {
	for(int i=0;i<BIT;i++) {
		if((1 << i) & x) {
			if(((1 << i) & f) == 0) {
				return 0;
			}
		}
	}
	return 1;
}

int m = 0;
int sol(int x, int ult) {
	if(x == m) return 0;
	if(dp[x][ult] != -1) return dp[x][ult];
	if(is_submask(x,m) == 0) {
		for(int i=0;i<BIT+1;i++) {
			dp[x][i] = 0;
		}
		return 0;
	}
//	prin(x);
//	prin(ult);
	int res = cnt[x];
	for(int i=ult;i<BIT;i++) {
		if((x & (1<<i)) == 0) {
			res += sol(addbit(x,i), i+1);
		}
	}
	return dp[x][ult] = res;
}

int main () {
	
	int v[N];
	int n;

	frr(i,0,N-1) {
		c[i] = -1;
		b[i] = -1;
	}

	cin >> n;

	fr(i,n) {
		cin >> v[i];
		c[v[i]] = v[i];
		b[v[i]] = v[i];
		cnt[v[i]]++;
	}
	
	for(int i=0;i<N;i++) {
		for(int j=0;j<BIT+1;j++) {
			dp[i][j] = -1;
		}
	}

	//c[i] guarda as submasks de i que estao em v	
	frr(i,0,(1 << BIT)-1LL) {
		for(int j=0;j<BIT;j++) {
			c[i] = max(c[i], c[delbit(i,j)]);
		}
	}

	//b[i] guarda o maior numero que i e submask
	frrs(i,(1 << BIT)-1LL,0) {
		for(int j=0;j<BIT;j++) {
			b[i] = max(b[i], b[addbit(i,j)]);
		}
	}

	for(int i=0;i<16;i++) {
//		printf("[%d] = %d/%d\n", i,c[i],b[i]);
	}

	for(int i=0;i<n;i++) {
		prin(inv(v[i]));
		if(c[inv(v[i])] != -1) m = max(m, (v[i] | c[inv(v[i])]));
		if(b[inv(v[i])] != -1) m = max(m, (v[i] | b[inv(v[i])]));
	}

	m = v[0] | v[1];
//	prin(m);
	int res = 0;
	for(int i=0;i<n;i++) {
		if(v[i] == m) continue;
		if(is_submask(v[i],m)) {
			//submask de m que contenha necessariamente os bits em (m - v[i])
//			prin(i);
//			prin(v[i]);
//			prin(m-v[i]);
			res += sol(m-v[i],0);
//			prin(sol(m-v[i],0));
//			prin(res);
//			separa();
					
		}
	}

	res /= 2;
	res += (cnt[m] * (cnt[m]-1))/2;
	res += (cnt[m] * (n - cnt[m]));

	printf("%d %d\n", m,res);
	
	return 0;

}



