#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
const ll MOD = 1e15 + 37;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 1001000

string s;
int n;
ll suf[N];
ll suf_i[N];
ll pot[N];

ll mul(ll a, ll b) {
	if(a > b) swap(a,b);
	ll res = 0;
	while(a > 0) {
		if(a & 1) {
			res += b;
			res %= MOD;
		}
		b <<= 1;
		b %= MOD;
		a >>= 1;
	}
	return res;
}

ll hash_range(int a, int b) {	
	ll res = suf[b];
	res -= mul(suf[a-1], pot[b-a+1]);
	res = (res + MOD)%MOD;
	return res;
}

bool check(int l1, int l2, int l3) {
	if(l1 < 0 or l2 < 0 or l3 < 0) return 0;
	if(s[0] == '0' and l1 > 1) return 0;
	if(s[l1] == '0' and l2 > 1) return 0;
	if(s[l1+l2] == '0' and l3 > 1) return 0;
	ll a = suf[l1];
	ll b = hash_range(l1+1,l1+l2);
	ll c = suf_i[n-l3 + 1];
/*	prin(l1);
	prin(l2);
	prin(l3);
	prin(a);
	prin(b);
	prin(c);
	separa();
*/	if((a + b) % MOD == c) {
		return 1;
	}
	return 0;
}

bool print(int l1, int l2, int l3) {
	cout << s.substr(0,l1);
	printf("+");
	cout << s.substr(l1,l2);
	printf("=");
	cout << s.substr(l1+l2,l3) << endl;
	exit(0);
}

int main () {

	char c;

	scanf(" %c", &c);
	while(c != '\n') {
		s.pb(c);
		scanf("%c", &c);
	}
	
	n = s.size();

	pot[0] = 1;
	for(int i=1;i<n+10;i++) {
		pot[i] = (pot[i-1] * 10LL) % MOD;
	}

	for(int i=1;i<=n;i++) {
		suf[i] = (s[i-1]-'0');
		suf[i] += (suf[i-1] * 10) % MOD;
		suf[i] %= MOD;
	}

	for(int i=n;i>=1;i--) {
		suf_i[i] = ((s[i-1]-'0') * pot[n-i]) % MOD;
		suf_i[i] += suf_i[i+1];
		suf_i[i] %= MOD;
	}

	int l1,l2,l3;
	for(int i=n;i >= 1; i--) {
		l3 = n-i+1;
		//l1 = l3
		l1 = l3;
		l2 = n - l1 - l3;
		if(check(l1,l2,l3)) {
			print(l1,l2,l3);	
		}

		//l1 = l3-1
		l1 = l3-1;
		l2 = n - l1 - l3;
		if(check(l1,l2,l3)) {
			print(l1,l2,l3);	
		}

		//l2 = l3
		l2 = l3;
		l1 = n - l3 - l2;
		if(check(l1,l2,l3)) {
			print(l1,l2,l3);	
		}

		//l2 = l3 - 1
		l2 = l3-1;
		l1 = n - l2 - l3;
		if(check(l1,l2,l3)) {
			print(l1,l2,l3);	
		}

	}


	return 0;

}



