#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100000
#define int ll

vector<int> adj[N];
int n,m,cnt;
//int dicio2[N];
map<int,int> dicio;
bool done[N];
bool leaf[N];
int dp[N];

void add(int x) {
	while(x != 1) {
		int dad = x/2;
		if(dicio.find(dad) == dicio.end()) {
			dicio[dad] = cnt++;
//			dicio2[cnt-1] = dad;
		}
		if(done[dicio[dad]] == 1) return;
		done[dicio[dad]] = 1;
		if(dicio.find(dad*2) == dicio.end()) {
			dicio[dad*2] = cnt++;
//			dicio2[cnt-1] = dad*2;
		}
		if(dad*2+1 <= n) {
			if(dicio.find(dad*2+1) == dicio.end()) {
				dicio[dad*2+1] = cnt++;
//				dicio2[cnt-1] = dad*2+1;
			}
			adj[dicio[dad]].pb(dad*2+1);
			adj[dicio[dad*2+1]].pb(dad);
		}
		adj[dicio[dad]].pb(dad*2);
		adj[dicio[dad*2]].pb(dad);
		x /= 2;
	}
}

int conta(int x) {
	if(x > n) return 0;
	if(dp[dicio[x]] != 0) return dp[dicio[x]];
	if(leaf[dicio[x]]) {
		int res = 1;
		int a,b;
		a = 2*x;
		b = 2*x + 1;
		while(b <= n) {
			res += b - a + 1;
			a = 2*a;
			b = 2*b + 1;
		}
		if(a <= n) res += n - a + 1;
		return dp[dicio[x]] = res;
	}
	return dp[dicio[x]] = 1;
}

int vis[N];
ll dfs(int x, int sz) {
	ll me = conta(x);
	ll res = me % MOD;
	if(sz == 1) {
		res *= me;
		res %= MOD;
	}
	vis[dicio[x]] = 1;
	prin(me);
	prin(x);
	separa();
	for(int v : adj[dicio[x]]) {
		if(vis[dicio[v]] == 0) {
			res += me * dfs(v,sz+1);
			res %= MOD;
		}
	}
	vis[dicio[x]] = 0;
	return res % MOD;
	
}

void folha(int x, int ant) {
	if(adj[dicio[x]].size() == 1 && x != 1) {
		leaf[dicio[x]] = 1;
//		printf("leaf %d\n", x);
	}
	for(int v : adj[dicio[x]]) {
		if(ant == v) continue;
		folha(v,x);
	}
}

 main() {
	
	cin >> n >> m;

	vector<ii> asd;
	int a,b;
	for(int i=0;i<m;i++) {
		cin >> a >> b;
		add(a);
		add(2*a);
		add(2*a+1);
		add(b);
		add(2*b);
		add(2*b+1);
		asd.pb({a,b});
	}
	folha(1,1);
	//printf("cnt %lld\n", cnt);
	for(ii x : asd) {
		adj[dicio[x.fi]].pb(x.se);
		adj[dicio[x.se]].pb(x.fi);
	}
	
/*	for(int i=1;i<=n;i++) {
	 			printf("conta(%d) = %d\n", i, conta(i));
	}
*/
	if(m == 0) {
		printf("%lld\n", ((ll)n * (ll)n) % MOD);
		return 0;
	}
/*	for(int i=0;i<cnt;i++) {
		printf("%d: ", dicio2[i]);
		for(int x : adj[i]) {
			printf("%d ", x);
		}
		cout << endl;
	}
*/	ll res = 0;
	for(ii x : dicio) {
//		printf("\nCHAMA %d\n", x.fi);
		int aux = dfs(x.fi,1);
		prin(aux);
		res += aux;
		res %= MOD;
	}

	cout << res << endl;

}
