#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define debug(args...) if(debug) fprintf(stderr,args)
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define frrs(i,a,b) for(int i = (a); i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 5100

vector<int> adj[N];
ll dp[N];
bool sum[N];
ll x[N];

bool dfs(int u) {

	if(adj[u].size() == 0) {
		dp[u] = 0;
		return 1;
	}

	for(int v : adj[u]) dfs(v);

	for(int i=0;i<=5000;i++) {
		sum[i] = 0;
	}
	
	ll tot = 0;
	
	int cnt = 0;
	for(int v : adj[u]) {
		tot += dp[v];
		tot += x[v];
		for(int j=5000;j>=0;j--) {
			if(sum[j] == 1) {
				sum[j] = 0;
				if(j + dp[v] <= 5000) sum[j+dp[v]] = 1;
				if(j + x[v] <= 5000) sum[j+x[v]] = 1;
			}
		}
		if(cnt == 0 && dp[v] <= 5000) sum[dp[v]] = 1;
		if(cnt == 0 && x[v] <= 5000) sum[x[v]] = 1;
		cnt++;
	}

	ll r = 100000000LL;
	for(int j=0;j<=x[u];j++) {
		if(sum[j] == 1) r = j;
	}
	
	if(r > x[u]) {
		printf("IMPOSSIBLE\n");
		exit(0);
	}	
	dp[u] = (tot - r);
}

int main () {

	int n;

	scanf("%d", &n);
	int p;
	for(int i=2;i<=n;i++) {
		cin >> p;
		adj[p].pb(i);
	}
	
	for(int i=1;i<=n;i++) {
		cin >> x[i];
	}

	dfs(1);	
	printf("POSSIBLE\n");

	//for(int i=1;i<=n;i++) {
//		printf("[%d] = %lld %lld\n", i,x[i], dp[i]);
//	}

	return 0;

}



