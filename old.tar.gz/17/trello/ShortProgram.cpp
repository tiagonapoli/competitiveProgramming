#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 500100

int op[N];
int v[N];
int n;

int extr(int bit, int x){
	return (((1<<bit) & x) != 0);
}

ii decide(int bit) {
	int a = 0;
	int b = 1;
	for(int i=0;i<n;i++) {
		if(op[i] == 0) {
			a &= extr(bit,v[i]);
			b &= extr(bit,v[i]);
		} else if(op[i] == 1) {
			a |= extr(bit,v[i]);
			b |= extr(bit,v[i]);
		} else {
			a ^= extr(bit,v[i]);
			b ^= extr(bit,v[i]);
		}
	}

	if(a == 0) {
		if(b == 0) {
			return {0,0};
		} else return {0,1};
	} else {
		if(b == 0) {
			return {2,1};
		} else return {1,1};
	}
}

int main () {
	
	cin >> n;

	char a;
	int b;
	for(int i=0;i<n;i++) {
		cin >> a >> b;
		if(a == '&') {
			op[i] = 0;
		} else if(a == '|'){
			op[i] = 1;
		} else op[i] = 2;
		v[i] = b;
	}
	
	int r1,r2,r3;
	r1=r2=r3 = 0;

	for(int i=0;i<10;i++) {
		ii r = decide(i);
		if(r.fi == 0) {
			r1 += (r.se << i);
		} else if(r.fi == 1) {
			r1 += (1 << i);
			r2 += (r.se << i);
		} else {
			r1 += (1 << i);
			r3 += (r.se << i);
		}
	}

	printf("3\n");
	printf("& %d\n", r1);
	printf("| %d\n", r2);
	printf("^ %d\n", r3);



	return 0;

}



