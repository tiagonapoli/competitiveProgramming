#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 200100

vector<int> adj[N];
bool tirado[N];
vector<int> res;

//A dfs encontra o par mais abaixo. A partir dessa par mais abaixo, a dfs2 so elimina os pares, que sempre estarao na raiz da arvore.


void dfs2(int v, int pai) {
	res.pb(v);
	tirado[v] = 1;
	for(int x : adj[v]) {
		if(x != pai and tirado[x] == 0) dfs2(x,v);
	}
}

int dfs(int v, int pai) {
	
	for(int x : adj[v]) {
		if(x != pai and tirado[x] == 0) dfs(x,v);
	}	

	int g = 0;
	for(int x : adj[v]) {
		if(tirado[x] == 0) g++;
	}

	if(g % 2 == 0) {
		res.pb(v);
		tirado[v] = 1;
		for(int x : adj[v]) {
			if(x != pai and tirado[x] == 0) dfs2(x,v);
		}	

	}

}



int main () {

	int n;

	cin >> n;

	int x;
	for(int i=1;i<=n;i++) {
		scanf("%d", &x);
		if(x == 0) continue;
		adj[x].pb(i);
		adj[i].pb(x);
	}
	
	if(n % 2 == 0) {
		printf("NO\n");
		return 0;
	}

	dfs(1,-1);
	//printf("%d\n", res.size());
	printf("YES\n");
	for(int x : res) {
		printf("%d\n", x);
	}
	printf("\n");
	return 0;
}



