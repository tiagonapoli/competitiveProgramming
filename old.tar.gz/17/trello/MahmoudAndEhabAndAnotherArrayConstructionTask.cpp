#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 2500100

vector<int> a;
vector<int> b;
bool tem[N];

void tira(int x) {
	for(int k=x;k<N;k+=x) {
		tem[k] = 0;
	}
}

int pos = 2;
int pega(int maior=0) {
	if(maior == 0) {
		while(tem[pos] == 0) {
			pos++;
		}
		return pos;
	}
	while(tem[maior] == 0) {
		maior++;
	}
	return maior;
}

vector<int> fact(int x) {
	vector<int> ret;
	for(int j=2;j*j<=x;j++) {
		if(x % j == 0) ret.pb(j);
		while(x % j == 0) x /= j;
	}
	if(x >= 2) ret.pb(x);
	return ret;
}

int main () {
	
	int n;
	for(int i=2;i<N;i++) {
		tem[i] = 1;
	}

	scanf("%d", &n);
	
	int val;
	for(int i=0;i<n;i++) {
		scanf("%d", &val);
		a.pb(val);
	}

	int i=0;
	for(bool continua=1;i<n and continua;i++) {
		int x = a[i];
		vector<int> f = fact(x);
		for(int j : f) {
			if(tem[j] == 0) {
				x = pega(a[i]);  
				continua = 0;
				break;
			}
		}
		b.pb(x);
		f = fact(x);
		for(int j : f) {
			tira(j);
		}
	}
	
	for(;i<n;i++) {
		b.pb(pega());
		tira(pega());
	}

	for(int i : b) printf("%d ", i);
	printf("\n");

	return 0;

}



