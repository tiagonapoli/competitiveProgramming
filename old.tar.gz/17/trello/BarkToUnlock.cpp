#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define debug(args...) if(debug) fprintf(stderr,args)
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define frrs(i,a,b) for(int i = (a); i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

string s;

bool check(string a) {
	prin(a);
	for(int i=0;i<a.size();i++) {
		int j = 0;
		while(j < s.size() && a[i+j] == s[j]) j++;
		if(j == s.size()) return 1;
	}
	return 0;
}

string v[N];
int main () {
	
	int n;
	
	cin >> s >> n;

	fr(i,n) {
		cin >> v[i];
	}

	for(int i=0;i<n;i++) {
		for(int j=0;j<n;j++) {
			if(check(v[i]+v[j])){
				cout << "YES" << endl;
				return 0;
			}
		}
	}

	cout << "NO" << endl;


	return 0;

}



