#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

int diameter;
vector<int> adj[N];
vector<int> prefix;
vector<int> suffix;
int dist[N];
int n;

ii bfs(int ini) {
	for(int i=1;i<=n;i++) {
		if(dist[i] == -2) continue;
		dist[i] = -1;
	}
	queue<int> fila;
	dist[ini] = 0;
	fila.push(ini);
	while(!fila.empty()) {
		ini = fila.front();
		fila.pop();
		for(int x : adj[ini]) {
			if(dist[x] == -1) {
				fila.push(x);
				dist[x] = dist[ini] + 1;
			}
		}
	}
	
	ii maxi = {ini,0};
	for(int i=1;i<=n;i++) 
		if(maxi.se < dist[i]) maxi = {i,dist[i]};
	
	maxi.se++;
	return maxi;
}


bool dfs(int now, int obj, int ant, int tp) {
	if(now == obj) return 1;	
	for(int x : adj[now]) {
		if(ant == x) continue;
		if(dfs(x,obj,now,tp) && adj[x].size() <= 2) {
			if(tp == 0) {
				prefix.pb(x);
			} else suffix.pb(x);
			return 1;
		}
	}
	return 0;
}



void start(int sz1, int sz2, int tp) {
	for(int i=1;i<=n;i++) dist[i] = -1;
	for(int i=1;i<=sz1;i++) {
		dist[prefix[i-1]] = -2;
	}
	for(int i=1;i<=sz2;i++) {
		dist[suffix[i-1]] = -2;
	}
}

bool check(int sz1, int sz2, int tp) {
	start(sz1,sz2,tp);
	ii ini;
	for(int i=1;i<=n;i++) {
		if(dist[i] == -1) {
			ini = bfs(i);
			break;
		}
	}
	start(sz1,sz2,tp);
	ini = bfs(ini.fi);
	return (ini.se == diameter - sz1 - sz2);
}

int bs1(int sz1, int tp) {
	int i,f;
	int m;
	int sz = suffix.size();
	if(tp == 0) sz = prefix.size();
	i = 1;
	f = sz+1;
	int a,b;
	while(f > i) {
		m = (f+i)/2;
		if(tp == 0) {
			a = m;
			b = 0;
		} else {
			a = sz1;
			b = m;
		}
		if(check(a,b,tp)) {
			i = m+1;
		} else f = m;
	}
	return i-1;
}

int main () {

	cin >> n;
	int a,b;

	for(int i=0;i<n-1;i++) {
		cin >> a >> b;
		adj[a].pb(b);
		adj[b].pb(a);
	}

	ii aux;
	
	aux = bfs(1);
	a = aux.fi;
	aux = bfs(aux.fi);
	b = aux.fi;
	diameter = aux.se;
	if(aux.se == n) {
		cout << n-1 << endl;
		return 0;
	}

	if(dfs(a,b,a,0)) prefix.pb(a);
	if(dfs(b,a,b,1)) suffix.pb(b);

	for(int i=0;i<prefix.size() && !suffix.empty();i++) {
		if(prefix[i] == suffix.back()) {
			suffix.pop_back();
		} else break;
	}

	prin(a);
	prin(b);
	prin(diameter);
/*	printf("prefix: ");
	for(int x : prefix) {
		printf("%d ", x);
	}
	cout << endl;

	printf("suffix: ");
	for(int x : suffix) {
		printf("%d ", x);
	}
	cout << endl;
*/
	int res = bs1(0,0);
	res += bs1(res,1);


	cout << res << endl;
	


	return 0;

}



