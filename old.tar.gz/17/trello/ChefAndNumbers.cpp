#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double eps = 1e-9;
using namespace std;
#define N 200100

typedef complex<double> Complex;
const double PI = acos(-1.0L);
//O TAMANHO DOS VETORES SAO ALTERADOS PARA POTENCIAS DE 2
// Computes the DFT of vector v if type = 1, or the IDFT if type = -1
vector<Complex> FFT(vector<Complex> &v, int type) {
    int n = v.size();
    while(n&(n-1)) { v.push_back(0); n++; }
    int logn = __builtin_ctz(n);
    vector<Complex> v2(n);
    for(int i=0; i<n; i++) {
        int mask = 0;
        for(int j=0; j<logn; j++) if(i&(1<<j)) mask |= (1<<(logn - 1 - j));
        v2[mask] = v[i];
    }
    for(int s=0, m=2; s<logn; s++, m<<=1) {
        Complex wm(cos(2.L * type * PI / m), sin(2.L * type * PI / m));
        for(int k=0; k<n; k+=m) {
            Complex w = 1;
            for(int j=0; 2*j<m; j++) {
                Complex t = w * v2[k + j + (m>>1)], u = v2[k + j];
                v2[k + j] = u + t; v2[k + j + (m>>1)] = u - t;
                w *= wm;
            }
        }
    }
    if(type == -1) for(Complex &c: v2) c /= n;
    return v2;
}

int n,k,q;
int v[N];
vector<Complex> x;
void expo() {
	//ate 200000 -> 2 ^ 18
	x.resize(4);
	int j=0;
	int cnt = 1;
	x[0] = Complex(1.0,0.0);
	vector<Complex> b;
	
	int t = clock();

	while(cnt < 19) {
	
		while(j < k and v[j] < x.size()/2) {
			x[v[j]] = Complex(1.0, 0);
			j++;
		}
		prin(1 << cnt);
		prin(x.size());

		/*for(int i=0;i<x.size(); i++) {
			if(x[i].real() > eps) 
				 printf("[%d]%.0f ", i, x[i].real());
		}
		cout << endl;
*/
		separa();
		
		b.resize(x.size());
		for(int i=0;i<x.size();i++) {
			if(3*i < x.size()) {
				b[i] = x[i];
			} else b[i] = Complex(0.0,0.0);
		}

		b = FFT(b,1);
		x = FFT(x,1);
		for(int i=0;i<x.size();i++) {
			x[i] *= x[i];
			x[i] *= b[i];
		}
		
		//v estara na proxima potencia
		x = FFT(x,-1);
		for(int i=0;i<x.size();i++) {
			if(x[i].real() < eps) {
				x[i] = Complex(0.0, 0.0);
			} else {
				x[i] = Complex(1.0, 0.0);
			}
		}
		x.resize(x.size() * 2);
		cnt++;
	}

}



int main () {
	

	scanf("%d %d %d", &n, &k, &q);
	for(int i=0;i<k;i++) {
		scanf("%d", &v[i]);
	}

	sort(v,v+k);

	expo();
	

	int a;
	for(int i=0;i<q;i++) {
		scanf("%d", &a);
		if(x[a].real() < eps) {
			printf("No\n");
		} else printf("Yes\n");
	}


	return 0;

}



