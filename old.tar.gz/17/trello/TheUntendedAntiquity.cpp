#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define ii pair<ll,ll>
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 3000

map<ii,ii> hashmp;
ii bit[N][N];
int n,m;

ii sum1(int x, int id) {
	ii res = {0,0};
	while(id > 0) {
		res.fi += bit[x][id].fi;
		res.se += bit[x][id].se;
		id -= id & (-id); 
	}
	return res;
}

ii sum(int x, int y) {
	ii res = {0,0};
	ii aux;
	while(x > 0) {
		aux = sum1(x,y);
		res.fi += aux.fi;
		res.se += aux.se;
		x -= x & (-x);
	}
	return res;
}

void upd1(int x, int id, ii val) {
	while(id < N) {
		bit[x][id].fi += val.fi;
		bit[x][id].se += val.se;
		id += id & (-id);
	}
}

void upd(int x, int y, ii val) {
	while(x < N) {
		upd1(x,y,val);
		x += x & (-x);
	}
}

ii soma(ii a, ii b){ 
	ii res = {a.fi+b.fi,a.se+b.se};
	return res;
}

ii sub(ii a, ii b) {
	ii res = {a.fi-b.fi,a.se-b.se};
	return res;
}

void db(int x, int y) {
	ii aux = sum(x,y);
	printf("sum(%d,%d) = %lld/%lld\n", x,y,aux.fi, aux.se);
}

ii sozinho(int x, int y) {
	ii res = sum(x,y);
	res = sub(res, sum(x-1,y));
	res = sub(res, sum(x,y-1));
	res = soma(res, sum(x-1,y-1));
/*	db(x,y);
	db(x-1,y);
	db(x,y-1);
	db(x-1,y-1);
	separa();
*/	return res;
}

int main () {

	int q;
	cin >> n >> m >> q;
	srand(2000000);
	ii r1,r2;
	int t,a,b,c,d;
	for(int i=0;i<q;i++) {
		cin >> t >> a >> b >> c >> d;
		if(t == 1) {
			ii h = {rand() % 100000000LL, rand() % 100000000LL};
			ii hi = {-h.fi,-h.se};
			hashmp[{a,b}] = h;
			upd(a,b,h);
			upd(c+1,b,hi);
			upd(a,d+1,hi);
			upd(c+1,d+1,h);
		} else if (t == 2) {
			ii h = hashmp[{a,b}];
			ii hi = {-h.fi, -h.se};
			upd(a,b,hi);
			upd(c+1,b,h);
			upd(a,d+1,h);
			upd(c+1,d+1,hi);
		} else if(t == 3) {
			r1 = sum(a,b);
			r2 = sum(c,d);
			prin(r1.fi);
			prin(r1.se);
			prin(r2.fi);
			prin(r2.se);
			separa();
			if(r1 == r2) {
				cout << "Yes\n" << endl;
			} else cout << "No\n" << endl;
		}
/*	
		printf("Hash\n");
		for(auto it = hashmp.begin(); it != hashmp.end(); it++) {
			printf("%d/%d = %d/%d\n", it->fi.fi, it->fi.se, it->se.fi, it->se.se);
			
		}

		for(int j=1;j<=n;j++) {
			for(int k=1;k<=m;k++) {
				ii aux = sozinho(j,k);
				printf("%d.%d ", aux.fi, aux.se);
			}
			separa();
		}
		separa();

		separa();
*/	}

	return 0;

}



