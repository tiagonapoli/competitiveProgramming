#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

int n,q;
ll res;
vector<int> vis;
vector<pair<pii, int> > query;
bool added[1<<21];
int v[N];
ll r[N];

int main () {
	
	scanf("%d %d", &n, &q);
	
	for(int i=0;i<n;i++) {
		scanf("%d", &v[i]);
	}

	for(int i=0;i<q;i++) {
		pair<pii, int> x;
		scanf("%d %d", &x.fi.fi, &x.fi.se);
		x.fi.fi--;
		x.se = i;
		query.pb(x);
	}

	sort(query.begin(), query.end());
	added[0] = 1;
	vis.pb(0);
	res = 1;
	int pos = 0;
	for(int i=0;i<n;i++) {
		if(added[v[i]] == 0) {
			int aux = vis.size();
			for(int j=0;j<aux;j++) {
				vis.pb(v[i] xor vis[j]);
				added[v[i] xor vis[j]] = 1;
			}
		} else {
			res *= 2;
			res %= MOD;
		}
		prin(vis.size());
		prin(res);
		separa();
		
		while(pos < query.size() and query[pos].fi.fi == i) {
			if(added[query[pos].fi.se] == 0) {
				r[query[pos].se] = 0;
			} else r[query[pos].se] = res;
			pos++;
		}
	}

	for(int i=0;i<q;i++) {
		printf("%lld\n", r[i]);
	}

	

	return 0;

}



