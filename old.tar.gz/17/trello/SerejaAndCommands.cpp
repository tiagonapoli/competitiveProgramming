#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define debug(args...) if(debug) fprintf(stderr,args)
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define frrs(i,a,b) for(int i = (a); i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007LL
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

ll bit[N];

//range update
//point query

int upd(int id, ll x){
	while(id < N) {
		bit[id] += x;
		bit[id] = (bit[id] + 2LL*MOD) % MOD;
		id += id & (-id);
	}
}

ll sum(int id) {
	ll res = 0;
	while(id > 0) {
		res += bit[id];
		res = (res + 2LL*MOD) % MOD;
		id -= id & (-id);
	}
	return res;
}

int main () {

	int t;
	int n;
	int m;
	cin >> t;

	ll v[N];
	pair<int,ii> op[N];
	while(t--) {
		fr(i,N) bit[i] = 0;	
		fr(i,N) v[i] = 0; 
		cin >> n >> m;
	
		for(int i=1;i<=m;i++) {
			cin >> op[i].fi >> op[i].se.fi >> op[i].se.se;
			upd(i,1);
			upd(i+1,-1LL);
		}	

		for(int i=1;i<=m;i++) {
			prin(i);
			prin(sum(i));
		}
		
		ll qtd;
		for(int i=m;i>=1;i--) {
			if(op[i].fi == 2) {
				qtd = sum(i);
				upd(op[i].se.fi,qtd);
				upd(op[i].se.se+1,-qtd);
			}
		}
		
		for(int i=1;i<=m;i++) {
			if(op[i].fi == 1) {
				v[op[i].se.fi] += sum(i) + 2LL*MOD;
				v[op[i].se.fi] %= MOD;
				v[op[i].se.se+1] -= sum(i) + 2LL*MOD;
				v[op[i].se.se+1] %= MOD;
			}
		}

		ll now = 0;
		for(int i=1;i<=n;i++) {
			now += v[i];
			now += 2LL*MOD;
			now %= MOD;
			v[i] = now;
		}

		for(int i=1;i<=n;i++) {
			printf("%lld ", v[i]);
		}
		printf("\n");

	}
	
	return 0;

}



