#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 50100

vector<pii> adj;
int v[N];
int dist[N];
int inf = 1000000010;
int mini = N;

void dijkstra() {
	set<pii> heap;
	for(int i=0;i<mini;i++) dist[i] = inf;
	for(int i=1;i<mini;i++) heap.insert({inf,i});
	heap.insert({0,0});
	dist[0] = 0;
	
	int aux,p;
	while(!heap.empty()) {
		pii now = *heap.begin();
		heap.erase(heap.begin());
		int id = now.se;
		int d = now.fi;
		dist[id] = d;
		for(pii u : adj) {
			aux = d + u.fi;
			p = (id + u.se) % mini;
			if(aux > 1000000000 or dist[p] <= aux) continue;
			heap.erase({dist[p],p});
			heap.insert({aux,p});
			dist[p] = aux;
		}
	}


}

int aux[N];
int main () {

	int n;
	
	scanf("%d", &n);
	
	for(int i=0;i<n;i++) {
		scanf("%d", &v[i]);
		mini = min(mini, v[i]);
	}

	for(int i=0;i<n;i++) {
		int id = v[i] % mini;
		if(aux[id] == 0) {
			aux[id] = v[i];
		} else aux[id] = min(aux[id], v[i]);
	}

	for(int i=1;i<mini;i++) if(aux[i] != 0) adj.pb({aux[i], i});
	sort(adj.begin(), adj.end());

	dijkstra();
	
	for(int i=0;i<mini;i++) {
		printf("%d -> %d\n", i, dist[i]);
	}

	int k;
	scanf("%d", &k);
	int a;
	for(int i=0;i<k;i++) {
		scanf("%d", &a);
		if(dist[a % mini] <= a) {
			printf("TAK\n");
		} else printf("NIE\n");
	}


	return 0;

}



