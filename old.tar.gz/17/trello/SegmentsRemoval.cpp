#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 200100

bool morto[N];
vector<ii> v;
int ant[N];
int prox[N];
int aa[N];
int n;

struct str {
	int fi, se;
	bool operator< (const str b) const {
		if(fi == b.fi) {
			return se > b.se;
		} else return fi < b.fi;
	}
};

priority_queue<str> heap;

int main () {

	cin >> n;

	for(int i=0;i<n;i++) {
		cin >> aa[i];
	}

	for(int i=0;i<n;i++) {
		if(!v.empty() and v.back().se == aa[i]) {
			v.back().fi++;
		} else v.pb({1,aa[i]});
	}

	n = v.size();
	for(int i=0;i<v.size();i++) {
		ant[i] = i-1;
		prox[i] = i+1;
	}

	for(int i=0;i<v.size();i++) {
		heap.push({v[i].fi, i});
	}

	int res = 0;
	while(!heap.empty()) {
		str t = heap.top();
		heap.pop();
		prin(t.se);
		int id = t.se;
		if(morto[id] == 0) {
			res++;
			morto[id] = 1;
			v[id].fi = 0;
			int a,b;
			a = ant[id];
			b = prox[id];
			if(a != -1) prox[a] = b;
			if(b != n) ant[b] = a; 
			if(a != -1 and b != n and v[a].se == v[b].se) {
				v[a].fi += v[b].fi;
				v[b].fi = 0;
				prox[a] = prox[b];
				int c = prox[b];
				if(c != n) ant[c] = a;
				morto[b] = 1;
				heap.push({v[a].fi,a});
			}
		}
	}
	
	cout << res << endl;


	return 0;

}



