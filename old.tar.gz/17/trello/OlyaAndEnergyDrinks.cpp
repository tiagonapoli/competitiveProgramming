#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 1010

int n,m,k;
int grid[N][N];
int dist[N][N];

ii nova(int dir, ii a, int j) {
	if(dir == 0) {
		a.fi += j;
	} else if(dir == 1) { 
		a.fi -= j;
	} else if(dir == 2) {
		a.se += j;
	} else a.se -= j;
	return a;
}

int bfs(ii ini, ii fim) {

	for(int i=0;i<=n;i++) {
		for(int j=0;j<=m;j++) {
			dist[i][j] = -1;
		}
	}
	queue<ii> fila;
	dist[ini.fi][ini.se] = 0;
	fila.push(ini);
	while(!fila.empty()) {
		ii now = fila.front();
		fila.pop();
		//printf("%d %d [%d]\n", now.fi, now.se, dist[now.fi][now.se]);
		for(int dir=0;dir<4;dir++) {
			for(int j=1;j<=k;j++) {
				ii pos = nova(dir,now,j);
				if(pos.fi <= 0 or pos.fi > n or pos.se <= 0 or pos.se > m) break;
				if(grid[pos.fi][pos.se] == 1) break;
				if(dist[pos.fi][pos.se] != -1 and dist[pos.fi][pos.se] <= dist[now.fi][now.se]) break;
				if(dist[pos.fi][pos.se] != -1) continue;
				dist[pos.fi][pos.se] = dist[now.fi][now.se] + 1;
				fila.push(pos);
			}
		}
	}
	return dist[fim.fi][fim.se];
}

int main () {

	scanf("%d %d %d", &n, &m, &k);

	char c;
	for(int i=1;i<=n;i++) {
		for(int j=1;j<=m;j++) {
			scanf(" %c" ,&c);
			if(c == '#') grid[i][j] = 1;
		}
	}

	ii ini, fim;
	cin >> ini.fi >> ini.se >> fim.fi >> fim.se;

	cout << bfs(ini,fim) << endl;

	return 0;

}



