#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

int a[N], n;
int b[N];
int sz = 300;
int rmqa[1000], rmqb[1000];


void build() {
	int block = -1;
	int qtd = 0;
	for(int i=0;i<n;i++) {
		if(qtd == 0) {
			block++;
			qtd = sz;
			rmqa[block] = a[i];
			rmqb[block] = b[i];
		}
		qtd--;
		rmqa[block] = min(rmqa[block], a[i]);
		rmqb[block] = max(rmqb[block], b[i]);
	}
}

int query_a(int x, int y) {
	int fi,la,res;
	fi = x/sz;
	la = y/sz;
	res = a[x];
	for(int i=fi+1;i<=la-1;i++) res = min(res, rmqa[i]);
	for(int i=x;i<=y and i/sz == fi; i++) res = min(res, a[i]);
	for(int i=y;i>=x and i/sz == la; i--) res = min(res, a[i]);
	return res;
}
/*
int query_b(int x, int y) {
	int fi,la,res;
	fi = x/sz;
	la = y/sz;
	res = b[x];
	for(int i=fi+1;i<=la-1;i++) res = max(res, rmqb[i]);
	for(int i=x;i<=y and i/sz == fi; i++) res = max(res, b[i]);
	for(int i=y;i>=x and i/sz == la; i--) res = max(res, b[i]);
	return res;
}
*/

set<int> done;
int query_b(int x, int y) {
	auto it = done.lower_bound(x);
	if(it == done.end() or *it > y) return false;
	return true;
}

map<int, vector<int> > v;

int sol() {
	int res = 0;
	for(auto j = v.rbegin(); j != v.rend(); j++) {
		int ant = -1;
		for(int i : j->se) {
			if(b[i] == a[i]) continue;
			if(debug) {
				printf("i: %d %d\n", j->fi, i);
				printf("ant: %d\n", ant);
				printf("query_a(%d,%d)=%d  query_b(%d,%d)=%d\n", ant, i, query_a(ant,i), ant, i, query_b(ant,i));
			}

			if(ant == -1) {
				res++;
			} else if(query_a(ant, i) < b[i] or query_b(ant, i)) res++;
			ant = i;
			prin(res);
			separa();
		}
		for(int i : j->se) {
			done.insert(i);
		}
	}
	return res;
}

bool cmp(pii a, pii b) {
	if(a.fi == b.fi) {
		return a.se < b.se;
	} else return a.fi > b.fi;
}

int main () {
	
	int t;


	scanf("%d", &t);

	while(t--) {
		
		scanf("%d", &n);

		done.clear();
		v.clear();

		for(int i=0;i<n;i++) {
			scanf("%d", &a[i]);
		}


		for(int i=0;i<n;i++) {
			scanf("%d", &b[i]);
			v[b[i]].pb(i);
		}

		build();

		bool fim = false;
		for(int i=0;i<n;i++) {
			if(a[i] < b[i]) fim = true; 
		}

		if(fim) printf("-1\n");
		else printf("%d\n", sol());
	}


	return 0;

}



