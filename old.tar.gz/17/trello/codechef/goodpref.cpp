#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 3010

ll acum[N];

int go(int x) {
	return x + 1020;
}

int main () {

	int t;
	string s;
	ll n;

	cin >> t;

	while(t--) {
		
		cin >> s >> n;

		for(int i=0;i<N;i++) acum[i] = 0;
	
		ll cnt = 0;
		ll positive = 0;
		for(int i=0;i<s.size();i++) {
			if(s[i] == 'a') {
				cnt++;
			} else cnt--;
			if(cnt > 0) positive++;
			acum[go(cnt)]++;
		}

		for(int i=1;i<N;i++) acum[i] = acum[i] + acum[i-1];

		ll res = 0;
		ll aux = 0;
		while(cnt != 0 and n > 0 and abs(aux) < 1000) {
			res += acum[go(1000)] - acum[go(aux)];
			/*prin(res);
			prin(n);
			prin(aux);
			separa();*/
			aux -= cnt;
			n--;
		}
		
		if(cnt > 0) res += n * (ll)s.size();
		if(cnt == 0) res += (acum[go(1000)] - acum[go(0)]) * n;
		cout << res << endl;

	}


	return 0;

}



