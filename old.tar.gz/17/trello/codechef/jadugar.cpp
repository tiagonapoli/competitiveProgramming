#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
const int N = 10000010;
//usando generating functions chegamos a uma recorrencia linear
//nF_n = (2n - 3)(A + 2KB)F_{n-1} - A^2(n-3)F_{n-2}
//F_0 = 0
//F_1 = K

ll dp[3];
ll inv[N];

ll fat[N];
ll invfat[N];

ll A,B,K;
int n;

inline int go(int pos) {
	return ((pos%3)+3)%3;
}

inline ll mul(ll a, ll b) {
	a %= MOD;
	b %= MOD;
	return (a * b) % MOD;
}

inline ll normaliza(ll x) {
	x %= MOD;
	x = (x + MOD) % MOD;
	return x;
}

ll fastpow(ll b, int e) {
	ll res = 1;
	while(e > 0) {
		if(e & 1) {
			res *= b;
			res %= MOD;
		}
		b *= b;
		b %= MOD;
		e >>= 1;
	}
	
	return res;
}

void init() {

	fat[0] = 1;
	for(int i=1;i<N;i++) {
		fat[i] = (fat[i-1] * i) % MOD;
	}

	invfat[N-1] = fastpow(fat[N-1], MOD-2);
	for(int i=N-2;i >= 0; i--) {
		invfat[i] = (invfat[i+1] * (i+1)) % MOD;
	}

	for(int i=1;i<N;i++) {
		inv[i] = (invfat[i] * fat[i-1]) % MOD;
	}
}



ll sol() {
	//para dar certo as condicoes iniciais, dp[0] = K/A
	dp[0] = mul(K, fastpow(A,MOD-2)); 
	dp[1] = K % MOD;
	prin(dp[0]);
	prin(dp[1]);
	ll m1 = normaliza(A + 2*K*B);
	ll m2 = normaliza(A*A);
	for(int i=2;i<=n;i++) {
		ll aux = mul(mul((2*i-3),m1),dp[go(i-1)]) - mul(mul(m2,(i-3)),dp[go(i-2)]);
		aux = normaliza(aux);
		prin(aux);
		dp[go(i)] = (aux * inv[i]) % MOD;
		if(debug) printf("dp[%d] = %lld\n", i, dp[go(i)]);
		
	}
	return dp[go(n)];
}

int main () {

	init();
	
	cin >> n >> K >> A >> B;

	cout << sol() << endl;


	return 0;

}



