#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-6;
using namespace std;
#define N 100100

int v[20], d[20], p[20], c[20];
double next(double ti, double delta, int i) {
	double t_ini, t_fim;
	t_ini = -p[i]/(double)v[i]; 
	t_fim = t_ini + abs(c[i])/(double)abs(v[i]);
	prin(ti);
	prin(ti + delta);
	prin(t_ini);
	prin(t_fim);
	separa();
	if(ti > t_fim + eps or ti + delta < t_ini - eps) return ti + delta;
	return t_fim + delta;
}

int main () {

	int t,n,s,y;

	scanf("%d", &t);

	while(t--) {
		
		scanf("%d %d %d", &n, &s, &y);
		
		for(int i=0;i<n;i++) {
			scanf("%d", &v[i]);
		}

		for(int i=0;i<n;i++) {
			scanf("%d", &d[i]);
			if(d[i] == 0) d[i] = -1;
			v[i] *= d[i];
		}

		for(int i=0;i<n;i++) {
			scanf("%d", &p[i]);
		}

		for(int i=0;i<n;i++) {
			scanf("%d", &c[i]);
		}

		double res = 0;
		double cross = y/(double)s; 
		for(int i=0;i<n;i++) {
			res = next(res, cross, i);
		}

		printf("%lf\n", res);
	}

	return 0;

}



