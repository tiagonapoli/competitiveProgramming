#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 5000000

ll fat[N], inv[N];
int p,q,c,m;

ll fastp(ll b, ll e) {
	ll res = 1;
	while(e > 0) {
		if(e & 1) {
			res *= b;
			res %= MOD;
		}
		b *= b;
		b %= MOD;
		e >>= 1;
	}
	return res;
}

ll comb(int n, int k) {
	//n escolhe k
	if(n < 0 or k < 0) return 0;
	ll res = (fat[n] * inv[k]) % MOD;
	res *= inv[n-k];
	res %= MOD;
	return res;
}

void init() {
	fat[0] = 1;
	for(int i=1;i<N;i++) {
		fat[i] = (fat[i-1] * i) % MOD;
	}
	inv[N-1] = fastp(fat[N-1],MOD-2);
	for(int i=N-2;i>=0;i--) {
		inv[i] = (inv[i+1] * (i+1)) % MOD;
	}
}

ll normal_path(pii p, pii q) {
	if(p.fi > q.fi or p.se > q.se) return 0;
	if(debug) printf("Caminho normal %d,%d -> %d,%d\n", p.fi, p.se, q.fi, q.se);
	ll aux = comb(q.fi-p.fi + q.se-p.se, q.se-p.se);
	prin(aux);
	return aux;
}

ll paths(pii p, pii q) {
	//y < x - c a todo momento!!
	if(p.se >= p.fi - c) return 0;
	if(q.se >= q.fi - c) return 0;

	pii p_img;
	int reta_x, reta_y;
	reta_x = p.fi;
	reta_y = reta_x - c;

	p_img.se = reta_y;
	p_img.fi = reta_x - (reta_y - p.se);

	if(debug) printf("Caminho %d/%d para %d/%d\n", p.fi, p.se, q.fi, q.se);
	if(debug) printf("%d/%d -> %d/%d\n", p.fi, p.se, p_img.fi, p_img.se);

	ll ret = normal_path(p,q) - normal_path(p_img, q);
	ret = (ret + 10*MOD) % MOD;
	prin(ret);
	separa();


	return ret;
}


ll dp[3010];
vector<pii> v;
int main () {

	init();

	scanf("%d %d %d %d", &p, &q, &c, &m);
	c--;
	pii ini = {0,0};
	pii fim = {p,q};

	pii x;
	set<pii> unico;
	for(int i=0;i<m;i++) {
		scanf("%d %d", &x.fi, &x.se);
		if(fim == x) {
			printf("0\n");
			return 0;
		}
		unico.insert(x);
	}
	unico.insert(fim);
	if(unico.find(ini) != unico.end()) {
		printf("0\n");
		return 0;
	}
	while(ini.fi - ini.se <= c) {
		ini.fi++;
		if(unico.find(ini) != unico.end()) {
			printf("0\n");
			return 0;
		}
	}
	if(debug) printf("ini %d %d\n", ini.fi, ini.se);

	

	for(pii i : unico) {
		v.pb(i);
	}
	m = v.size();

	for(int i=0;i<m;i++) {
		dp[i] = paths(ini, v[i]);
		for(int j=0;j<i;j++) {
			dp[i] -= (dp[j] * paths(v[j],v[i])) % MOD;
			dp[i] = (dp[i] + 10*MOD) % MOD;
		}
		if(debug) printf("%d/%d %lld\n",v[i].fi, v[i].se, dp[i]); 
		if(v[i] == fim) {
			printf("%lld\n", dp[i]);
		//	return 0;	
		}
	}

	return 0;

}



