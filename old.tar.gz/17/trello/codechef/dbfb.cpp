#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100010

void mul(ll a[2][2], ll b[2][2], ll c[2][2]) {
	for(int i=0;i<2;i++) {
		for(int j=0;j<2;j++) {
			c[i][j] = 0;
			for(int k=0;k<2;k++) {
				c[i][j] += (a[i][k] % MOD) * (b[k][j] % MOD);
				c[i][j] %= MOD;
			}
		}
	}
}

void cpy(ll from[2][2], ll to[2][2]) {
	for(int i=0;i<2;i++) {
		for(int j=0;j<2;j++) {
			to[i][j] = from[i][j];
		}
	}
}


void print(ll x[2][2]) {
	if(debug) printf("%lld %lld\n%lld %lld\n\n", x[0][0], x[0][1], x[1][0], x[1][1]);
}

ll c[2][2];
ll res[2][2];
void fpow(ll b[2][2], ll e) {

	res[0][1] = res[1][0] = 0;
	res[0][0] = res[1][1] = 1;

	while(e > 0) {
		if(e & 1) {
			mul(res,b,c);
			cpy(c,res);
		}
		mul(b,b,c);
		cpy(c,b);
		e >>= 1;
	}
	print(res);

}

int main () {

	int t;
	ll m, n;
	ll a[N], b[N];

	scanf("%d", &t);
	while(t--) {
		
		ll f[][2] = {1 ,1,
					 1, 0};

		scanf("%lld %lld", &m, &n);

		ll sa,sb;
		sa = sb = 0;
		for(int i=0;i<m;i++) {
			scanf("%lld", &a[i]);
			sa += a[i];
			sa %= MOD;
		}

		for(int i=0;i<m;i++) {
			scanf("%lld", &b[i]);
			sb += b[i];
			sb %= MOD;
		}

		sa = (sa * m) % MOD;
		sb = (sb * m) % MOD;
		
		ll ret = 0;
		if(n >= 3) {
			fpow(f,n-2LL);
			ret = ((sa * res[0][1]) % MOD) + ((sb * res[0][0]) % MOD);
		} else if(n == 2) {
			ret = sb;
		} else if(n == 1) {
			ret = sa;
		}
		ret %= MOD;

		cout << ret << endl;
	}


	return 0;

}



