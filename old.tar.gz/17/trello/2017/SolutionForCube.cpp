#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

int v[25];
int vv[25];

void pre() {
	for(int i=1;i<=24;i++) {
		vv[i] = v[i];
	}
}

bool check() {
	for(int i=1;i<=24;i+=4) {
		if(vv[i] != vv[i+1] or vv[i+1] != vv[i+2] or vv[i+2] != vv[i+3]) return 0;
	}
	return 1;
}

int v1(int cnt) {
	pre();
	int a,b;
	while(cnt--) {
		a = vv[1];
		b = vv[3];
	
		vv[1] = vv[22];
		vv[3] = vv[24];

		vv[22] = vv[9];
		vv[24] = vv[11];

		vv[9] = vv[5];
		vv[11] = vv[7];

		vv[5] = a;
		vv[7] = b;
	}
}

void v2(int cnt) {
	pre();
	int a,b;
	while(cnt--) {
		a = vv[2];
		b = vv[4];
		
		vv[2] = vv[21];
		vv[4] = vv[23];

		vv[21] = vv[10];
		vv[23] = vv[12];

		vv[10] = vv[6];
		vv[12] = vv[8];

		vv[6] = a;
		vv[8] = b;
	}
}

void v3(int cnt) {
	pre();
	int a,b;
	while(cnt--) {
		a = vv[3];
		b = vv[4];
		
		vv[3] = vv[14];
		vv[4] = vv[16];

		vv[14] = vv[9];
		vv[16] = vv[10];

		vv[9] = vv[17];
		vv[10] = vv[19];

		vv[17] = a;
		vv[19] = b;
	}
}

void v4(int cnt){ 
	pre();
	int a,b;
	while(cnt--) {
		a = vv[1];
		b = vv[2];
		
		vv[1] = vv[13];
		vv[2] = vv[15];

		vv[13] = vv[11];
		vv[15] = vv[12];

		vv[11] = vv[18];
		vv[12] = vv[20];

		vv[18] = a;
		vv[20] = b;
	}
}

void v5(int cnt){ 
	pre();
	int a,b;
	while(cnt--) {
		a = vv[5];
		b = vv[6];
		
		vv[5] = vv[13];
		vv[6] = vv[14];

		vv[13] = vv[21];
		vv[14] = vv[22];

		vv[21] = vv[17];
		vv[22] = vv[18];

		vv[17] = a;
		vv[18] = b;
	}
}

void v6(int cnt){ 
	pre();
	int a,b;
	while(cnt--) {
		a = vv[7];
		b = vv[8];
		
		vv[7] = vv[15];
		vv[8] = vv[16];

		vv[15] = vv[23];
		vv[16] = vv[24];

		vv[23] = vv[19];
		vv[24] = vv[20];

		vv[19] = a;
		vv[20] = b;
	}
}

int main () {

	for(int i=1;i<=24;i++) {
		cin >> v[i];
	}

	int a,b;

	v1(1);
	if(check()) {
		cout << "YES\n" << endl;
		return 0;
	}
	v1(3);
	if(check()) {
		cout << "YES\n" << endl;
		return 0;
	}
	v2(1);
	if(check()) {
		cout << "YES\n" << endl;
		return 0;
	}
	v2(3);
	if(check()) {
		cout << "YES\n" << endl;
		return 0;
	}
	v3(1);
	if(check()) {
		cout << "YES\n" << endl;
		return 0;
	}
	v3(3);
	if(check()) {
		cout << "YES\n" << endl;
		return 0;
	}
	v4(1);
	if(check()) {
		cout << "YES\n" << endl;
		return 0;
	}
	v4(3);
	if(check()) {
		cout << "YES\n" << endl;
		return 0;
	}
	v5(1);
	if(check()) {
		cout << "YES\n" << endl;
		return 0;
	}
	v5(3);
	if(check()) {
		cout << "YES\n" << endl;
		return 0;
	}
	v6(1);
	if(check()) {
		cout << "YES\n" << endl;
		return 0;
	}
	v6(3);
	if(check()) {
		cout << "YES\n" << endl;
		return 0;
	}

	cout << "NO\n" << endl;
	return 0;

}



