#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 1005

ll g[2][N][N];
int n;

void upd(int r, int c, int l, int s) {
	
	g[0][r][c] += s;
	g[0][min(n,r+l)][c] -= s;
	g[1][min(n,r+l)][c+1] -= s;
	g[1][min(n,r+l)][min(c+1+l,n)] += s;

	
}

int main () {

	int q;

	scanf("%d %d", &n, &q);


	int r,c,l,s;
	for(int i=0;i<q;i++) {
		scanf("%d %d %d %d", &r, &c, &l, &s);
		r--, c--;
		upd(r,c,l,s);
	}
	
	ll sum = 0;
	for(int i=0;i<n; i++) {
		sum = 0;
		for(int j=0;j<n;j++) {
			sum += g[1][i][j];
			g[1][i][j] = sum;
		}
	}

	for(int i=0;i<n; i++) {
		sum = 0;
		for(int j=0;j<n;j++) {
			sum += g[0][j][i];
			g[0][j][i] = sum;
		}
	}
	
	for(int i=0;i<n;i++) {
		sum = 0;
		for(int j=0;i+j<n;j++) {
			sum += g[0][i+j][j] + g[1][i+j][j];
			g[0][i+j][j] = sum;
		}
		if(i == 0) continue;
		sum = 0;
		for(int j=0;i+j<n;j++) {
			sum += g[0][j][i+j] + g[1][j][i+j];
			g[0][j][i+j] = sum;
		}
	}

	for(int i=0;i<n;i++) {
		for(int j=0;j<n;j++) {
			printf("%lld ", g[0][i][j]);
		}
		cout << endl;
	}
	cout << endl;

	return 0;

}



