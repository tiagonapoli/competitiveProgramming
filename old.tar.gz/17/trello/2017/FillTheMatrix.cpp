#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define debug(args...) if(debug) fprintf(stderr,args)
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define frrs(i,a,b) for(int i = (a); i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

vector<ii> adj[N];
int cor[N];

bool dfs(int u, bool x) {
	cor[u] = x;
	bool prox = x;
	bool res = 1;
	for(ii v : adj[u]) {
		prox = x;
		if(v.se == 1) prox = !x;
		if(cor[v.fi] == -1) {
			res &= dfs(v.fi,prox);
		} else if(cor[v.fi] != prox) return 0;
	}
	return res;
}

int main () {

	int t;

	cin >> t;

	int n,q;
	while(t--) {
	
		cin >> n >> q;
		
		fr(i,n+1) {
			cor[i] = -1;
			adj[i].clear();
		}

		int x,y,z;

		fr(i,q) {
			cin >> x >> y >> z;
			adj[x].pb({y,z});
			adj[y].pb({x,z});
		}

		bool res  = 1;
		for(int i=1;i<=n && res;i++) {
			if(cor[i] == -1) {
				res = dfs(i,0);	
			}
		}

		printf("%s\n", res ? "yes" : "no");

	}


	return 0;

}



