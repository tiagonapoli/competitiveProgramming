#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 200100

int pai[N][25];
ll cost[N];
ll val[N];
int logg[N], h[N];
vector<int> adj[N];

void pre() {
	logg[1] = 0;
	for(int i=2;i<N;i++) {
		logg[i] = logg[i/2] + 1;
	}
}

int dfs(int u) {
	cost[u] += val[u];
	for(int v : adj[u]) {
		if(v != pai[u][0]) {
			pai[v][0] = u;
			h[v] = h[u] + 1;
			cost[v] = cost[u];
			dfs(v);
		}
	}
}

int sobe(int u, int x) {
	int j=0;
	while(x > 0) {
		if(x & 1) {
			u = pai[u][j];
		}
		x >>= 1;
		j++;
	}
	return u;
}

int lca(int u, int v) {
	//u esta mais embaixo
	if(h[u] < h[v]) swap(u,v);
	u = sobe(u,h[u] - h[v]);
	if(u == v) return v;
	prin(u);
	prin(v);
	for(int i=19;i >= 0; i--) {
		if(pai[u][i] != pai[v][i]) {
			u = pai[u][i];
			v = pai[v][i];
		}
	}
	return pai[u][0];
}

ll go(int a, int b) {
	int lc = lca(a,b);
	prin(lc);
	prin(cost[a]);
	prin(cost[b]);
	prin(cost[lc]);
	return cost[a] + cost[b] - 2 * cost[lc] + 2 * val[lc] - val[a] - val[b];
}

int main () {

	int n;

	pre();

	scanf("%d", &n);

	for(int i=1;i<=n;i++) {
		scanf("%lld", &val[i]);
	}

	int a,b;
	for(int i=0;i<n-1;i++) {
		scanf("%d %d", &a, &b);
		adj[a].pb(b);
		adj[b].pb(a);
	}

	cost[1] = 0;
	h[1] = 0;
	pai[1][0] = 1;
	dfs(1);
	for(int i=1;i<20;i++) {
		for(int j=1;j<=n;j++) {
			pai[j][i] = pai[pai[j][i-1]][i-1];
		}
	}

	/*for(int i=1;i<=n;i++) {
		printf("%d: ", i);
		for(int j=0;j<5;j++) {
			printf("%d ", pai[i][j]);
		}
		cout << endl;
	}
	*/

	int q;

	scanf("%d", &q);

	for(int i=0;i<q;i++) {
		scanf("%d %d", &a, &b);
		cout << go(a,b) << endl;
	}

	return 0;

}



