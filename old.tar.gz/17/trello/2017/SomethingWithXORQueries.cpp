#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

int a[5100], b[5100];
int a0b[5100];
int ab0[5100];
bool va[5100], vb[5100];
int n;
int ra[5100];

bool check() {
	for(int i=0;i<n;i++) {
		va[i] = vb[i] = 0;
	}
	for(int i=0;i<n;i++) {
		if(a[i] > n or va[a[i]] != 0) return 0;
		va[a[i]] = 1;
		if(b[i] > n or vb[b[i]] != 0) return 0;
		vb[b[i]] = 1;
		if(b[i] > n or a[b[i]] != i) return 0;
	}

	for(int i=0;i<n;i++) {
		ra[i] = a[i];
	}
	return 1;
}

int main () {


	cin >> n;
	
	for(int i=0;i<n;i++) {
		printf("? 0 %d\n", i);
		fflush(stdout);
		cin >> a0b[i]; 
	}

	for(int i=0;i<n;i++) {
		printf("? %d 0\n", i);
		fflush(stdout);
		cin >> ab0[i];
	}

	int res = 0;
	for(int i=0;i<n;i++) {
		a[0] = i;
		for(int j=0;j<n;j++) {
			b[j] = a0b[j] xor a[0];	
		}

		for(int j=0;j<n;j++) {
			a[j] = ab0[j] xor b[0];
		}

		if(check()) {
			res++;
		}
	}

	printf("!\n");
	printf("%d\n", res);
	if(res != 0) {
		for(int i=0;i<n;i++) {
			printf("%d ", ra[i]);
		}
		printf("\n");
	}
	fflush(stdout);

	return 0;

}



