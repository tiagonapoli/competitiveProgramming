import sys
sys.setrecursionlimit(1001000)
ants = "What are you doing while sending \""
ant = len(ants)
meios = "\"? Are you busy? Will you send \""
meio = len(meios)
fims = "\"?"
fim = len(fims)

base = "What are you doing at the end of the world? Are you busy? Will you save us?"
f = [0]
f[0] = len(base)

for i in range(1,100001):
	f.append(2*f[i-1] + ant + meio + fim)
	if(f[i] >= int(1e18) + 10):
		f[i] = int(1e18) + 10



def busca(n,k):
	
	while True:
		if n == 0:
			if k > len(base):
				return "."
			else:
				return base[k-1]

		if k <= ant:
			return ants[k-1]
		
		k -= ant
		if k <= f[n-1]:
			n-=1
			continue
		k -= f[n-1]
		
		if k <= meio:
			return meios[k-1]
		k -= meio
		
		if k <= f[n-1]:
			n -= 1
			continue
		k -= f[n-1]

		if k <= fim:
			return fims[k-1]
		return "."
		

def main():

	q =	int(input())
	for i in range(0,q):
		n,k = map(int, input().split())
		print (busca(n,k), end='')

	print()	



main()
