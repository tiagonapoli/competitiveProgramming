#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

int bit[4][11][11][N];
char let[] = {'C', 'G', 'T', 'A'};
int id[200];

int sum(int a, int b, int c, int id) {
	int res = 0;
	while(id > 0) {
		res += bit[a][b][c][id];
		id -= id & (-id);
	}
	return res;
}

void upd(int a, int b, int c, int id, int x){
	while(id < N) {
		bit[a][b][c][id] += x;
		id += id & (-id);
	}
}

int range(int a, int b, int c, int l, int r) {
	return sum(a,b,c,r) - sum(a,b,c,l-1);
}


int main () {
	
	id['C'] = 0;
	id['G'] = 1;
	id['T'] = 2;
	id['A'] = 3;

	string s;

	cin >> s;

	for(int i=0;i<s.size();i++) {
		for(int j=1;j<=10;j++) {
			upd(id[s[i]],j,(i+1)%j,i+1,1);
		}
	}

	int q;
	int a,b;
	string e;

	cin >> q;

	char x;
	int op;
	for(int i=0;i<q;i++) {
		cin >> op >> a;
		if(op == 1) {
			cin >> x;
			for(int j=1;j<=10;j++) {
				upd(id[s[a-1]],j,a%j,a,-1);
			}
			s[a-1] = x;
			for(int j=1;j<=10;j++) {
				upd(id[s[a-1]],j,a%j,a,1);
			}
		} else {
			cin >> b >> e;
			int res = 0;
			int sz = e.size();
			for(int i=0;i<sz;i++) {
				res += range(id[e[i]],sz,(i+a)%sz,a,b);
			}
			cout << res << endl;
		}
	}


	return 0;

}



