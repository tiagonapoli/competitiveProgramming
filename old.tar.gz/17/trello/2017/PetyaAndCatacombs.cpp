#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 200100

int adj[N];
bool vis[N];
int n;
int res = 0;

int dfs(int now) {
	vis[now] = 1;
	if(adj[now] == 0) return 0;
	if(vis[adj[now]] == 0) {
		res--;
		dfs(adj[now]);
	}
}

int main () {

	cin >> n;

	res = n;
	for(int i=1;i<=n;i++) {
		cin >> adj[i];
	}
	
	for(int i=n;i>=1;i--) {
		
		if(vis[i] == 0) {
			dfs(i);
		}
	}

	cout << res << endl;

	return 0;

}



