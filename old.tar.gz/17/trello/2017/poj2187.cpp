#include <cstdio>
#include <vector>
#include <set>
#include <algorithm>
#include <map>
#include <math.h>
#include <iostream>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100

//SOLVES UVA681 - CONVEX HULL FINDING

typedef ll T;

struct pt {

    T x,y;
    pt() {}
    pt(T a, T b) {x=a,y=b;}
    pt operator- (pt b) {
        pt res(x-b.x,y-b.y);
        return res;
    }
	T operator* (pt b) {
		return x * b.x + y * b.y;
	}
    bool operator< (const pt b) const {
        if(x == b.x) {
            return y < b.y;
        } else return x < b.x;
    }
	double len() {return hypot(x,y);}
	bool operator==(const pt b) const {return ((x == b.x) && (y == b.y));}
    void print() {printf("%lld %lld", x,y);}
};

T cross(pt a, pt b) {
    return a.x*b.y - a.y*b.x;
}

//Retorna a area do 'paralelogramo' com 'sinal'
//AB ^ AC = (B-A)^(C-A) = A^B + B^C + C^A
T area(pt a, pt b, pt c) {
    return cross(a,b) + cross(b,c) + cross(c,a);
}

//Tira o cara do topo de up ou down se for fazer uma curva para esquerda (area positiva)
vector<pt> convex_hull(vector<pt> p) {
    vector<pt> up,dn;
	if(p.size() <= 2) {
		return p;
	}
	sort(p.begin(), p.end());
 
    up.pb(p[0]);
    up.pb(p[1]);
    //Tirar os colineares area >=
    for(int i=2;i<p.size();i++) {
        while(up.size() >= 2 && area(up[(int)up.size()-2],up[(int)up.size()-1],p[i]) >= 0) {
            up.pop_back();
        }
        up.pb(p[i]);
    }
    dn.pb(p[p.size()-1]);
    dn.pb(p[p.size()-2]);
    for(int i=p.size()-3;i>=0;i--) {
        while(dn.size() >= 2 && area(dn[(int)dn.size()-2],dn[(int)dn.size()-1],p[i]) >= 0) {
            dn.pop_back();
        }
        dn.pb(p[i]);
    }
    for(int i=1;i<dn.size();i++) {
        up.pb(dn[i]);
    }
    reverse(up.begin(), up.end());
    return up;
}


double dist_pt_reta(pt x, pt a, pt b) {
	pt ab = b-a;
	ll aux = area(x,a,b);
	if(aux < 0) aux = -aux;
	return aux/ab.len();
}

T dist(pt a, pt b) {
	return (a-b) * (a-b);
}

ll rotating_callipers(vector<pt> convex) {
	
	int sz = convex.size();
	int a,b;
	T res = 0;
	a = 0;
	b = 0;
	pt x1,x2;
	pt z1,z2;
	while(b < sz-1) {
		x1 = convex[a];
		x2 = convex[a+1];
		z1 = convex[b];
		z2 = convex[b+1];

		prin(a);
		prin(b);
		separa();

		res = max(res, max(dist(z1,x1), dist(z1,x2))); 
		
		if(dist_pt_reta(z2,x1,x2) < dist_pt_reta(z1,x1,x2)) {
			a++;
		} else b++;
	}
	
	while(a < b and b < sz) {
		x1 = convex[a];
		x2 = convex[a+1];
		z1 = convex[b];	
		res = max(res, max(dist(z1,x1), dist(z1,x2))); 
		prin(a);
		prin(b);
		separa();
		a++;

	}
	return res;
}

int main () {

	int n;

	cin >> n;
	vector<pt> p;
	pt x;
	for(int i=0;i<n;i++) {
		cin >> x.x >> x.y;
		p.pb(x);
	}

	vector<pt> convex = convex_hull(p);

	printf("%lld\n", rotating_callipers(convex));

}



