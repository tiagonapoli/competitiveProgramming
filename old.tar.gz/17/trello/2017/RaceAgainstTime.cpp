#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define debug(args...) if(debug) fprintf(stderr,args)
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define frrs(i,a,b) for(int i = (a); i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

double h,m,s;
double t1,t2;

bool bet2(double b, double a, double c){
	if(b <= c and c <= 12) return 1;
	if(0 <= c and c <= a) return 1;
	return 0;
}


bool bet(double a, double b, double c) {
	if(a <= c and c <= b) {
		return 1;			
	}
	return 0;
}

int main () {

	double v[3];
	cin >> v[0] >> v[1] >> v[2] >> t1 >> t2;


	if(v[0] == 12.0) v[0] = 0;
	v[0] += ((v[1]*60.0 + v[2])/3600.0);
	v[1] += v[2]/60.0;
	v[1] /= 5.0;
	v[2] /= 5.0;

	sort(v,v+3);
	prin(v[0]);
	prin(v[1]);

	prin(v[2]);
	if(t2 == 12.0) t2 = 0;
	if(t1 == 12.0) t1 = 0;

	bool res = 0;
	if(bet(v[0],v[1],t1) and bet(v[0],v[1],t2)){
		res = 1;
	} else if(bet(v[1],v[2],t1) and bet(v[1],v[2],t2)) {
		res = 1;
	} else if(bet2(v[2],v[0],t1) and bet2(v[2],v[0],t2)) {
		res = 1;
	}

	if(res){
		cout << "yes" << endl;
	} else cout << "no" << endl;


	return 0;

}



