#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define endl "\n"
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define For(i,x,y) for(int i=x; i<y; i++)
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
#define MOD 1000000007
#define PI acos(-1.0)
using namespace std;
const double eps = 1e-9;
#define N 100100

//SOLVES UVA681 - CONVEX HULL FINDING

typedef int T;

struct pt {

    T x,y;
    pt() {}
    pt(T a, T b) {x=a,y=b;}
    pt operator- (pt b) {
        pt res(x-b.x,y-b.y);
        return res;
    }
	T operator* (const pt b) const {
		return x * b.x + y * b.y;
	}
	T operator^ (const pt b) const {
		return x * b.y - y * b.x;
	}
    bool operator< (const pt b) const {
        if(x == b.x) {
            return y < b.y;
        } else return x < b.x;
    }
    bool operator==(const pt b) const {return ((x == b.x) && (y == b.y));}
    void print() {printf("%d %d", x,y);}
};

T cross(pt a, pt b) {
    return a.x*b.y - a.y*b.x;
}

//Retorna a area do 'paralelogramo' com 'sinal'
//AB ^ AC = (B-A)^(C-A) = A^B + B^C + C^A
T area(pt a, pt b, pt c) {
    return cross(a,b) + cross(b,c) + cross(c,a);
}

//Tira o cara do topo de up ou down se for fazer uma curva para esquerda (area positiva)
vector<pt> convex_hull(vector<pt> p) {
    vector<pt> up,dn;
    sort(p.begin(), p.end());

	if(p.size() <= 2) return p;

    up.pb(p[0]);
    up.pb(p[1]);
    //Tirar os colineares area >=
    for(int i=2;i<p.size();i++) {
        while(up.size() >= 2 && area(up[(int)up.size()-2],up[(int)up.size()-1],p[i]) >= 0) {
            up.pop_back();
        }
        up.pb(p[i]);
    }
    dn.pb(p[p.size()-1]);
    dn.pb(p[p.size()-2]);
    for(int i=p.size()-3;i>=0;i--) {
        while(dn.size() >= 2 && area(dn[(int)dn.size()-2],dn[(int)dn.size()-1],p[i]) >= 0) {
            dn.pop_back();
        }
        dn.pb(p[i]);
    }
    for(int i=1;i<dn.size();i++) {
        up.pb(dn[i]);
    }
	reverse(up.begin(), up.end());
    up.pop_back();
	return up;
}

int dist(pt a, pt b) {
	return (a-b) * (a-b);
}


vector<int> antipodal[N];
int rotating_callipers(vector<pt> &p) {

	int sz = p.size();
	int to;
	pt a,b,c,d;
	pt ab,ac,ad;
	int aux;
	
	if(debug){
	printf("convex\n");
	for(int i=0;i<sz;i++){
		printf("[%d] %d %d\n", i, p[i].x, p[i].y);
	}
	cout << endl;
	}
	to = 0;
	a = p[sz-1];
	b = p[0];
	ab = b-a;
	while((to + 1) % sz != sz-1) {
		c = p[to];
		d = p[(to+1) % sz];
		ac = c-a;
		ad = d-a;
		if((ab ^ ac) < (ab ^ ad)) {
			to = to + 1;
		} else break;
	}
	if(debug) printf("ini to %d\n", to);

	for(int i=0;i<sz;i++) {
		a = p[i];
		b = p[(i+1) % sz];
		ab = b-a;
		aux = dist(a, p[to]);
		antipodal[i].pb(to);
		if(debug) printf("ini %d %d\n", i, to);
		while((to + 1) % sz != i) {
			c = p[to];
			d = p[(to+1) % sz];
			ac = c-a;
			ad = d-a;
			aux = max(aux, max(dist(a,c), dist(a,d)));
			if((ab ^ ac) < (ab ^ ad)) {
				//distancia de d a reta ab [e maior
				to = (to + 1) % sz;
			} else break;
			antipodal[i].pb(to);
		}

		if((ab ^ ac) == (ab ^ ad)) {
			antipodal[i].pb((to+1) % sz);
			antipodal[(i+1) % sz].pb(to);
			to = (to + 1) % sz;
		}

		if(debug) printf("fim %d %d\n", i, to);
		separa();
	}

	int ret = 0;
	for(int i=0;i<sz;i++) {
//		printf("%d: ",i);
		ret += antipodal[i].size();	
		for(int j : antipodal[i]) {
//			printf("%d ", j);
		}
//		cout << endl;
	}
//	cout << endl;

	return ret;	
}




int main () {

	int n;
	vector<pt> v;
	pt x;

	cin >> n;

	for(int i=0;i<n;i++) {
		cin >> x.x >> x.y;
		v.pb(x);
	}

	vector<pt> convex = convex_hull(v);
	rotating_callipers(convex);

	int res = 0;
	for(int i=0;i<n;i++) {
		for(int j : antipodal[i]) {
			res = max(res, dist(convex[i],convex[j]));
		}
	}

	printf("%lf\n", sqrt(res));

}



