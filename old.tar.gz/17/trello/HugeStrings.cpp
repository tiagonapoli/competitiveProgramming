#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define debug(args...) if(debug) fprintf(stderr,args)
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define frrs(i,a,b) for(int i = (a); i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 202

string pre[N];
string suf[N];
bool num[N][14][10000];

void cria(string s, int i) {
	for(int k=1;k<=min(13,(int)s.size());k++) {
		int r = 0;
		for(int j=0;j<k;j++) {
			r += (1 << j) * (s[s.size()-1-j] - '0');
		}
		num[i][k][r] = 1;
		for(int j=s.size()-k-1;j>=0;j--) {
			r /= 2;
			r += (1 << (k-1)) * (s[j] - '0');
			num[i][k][r] = 1;

		}
//		cout << endl;
	}
}

int main () {

	int n,m;

	cin >> n;

	string s;
	for(int i=0;i<n;i++) {
		cin >> s;
		pre[i] = s.substr(0,min(13,(int)s.size()));
		suf[i] = s.substr(((int)s.size())-min(13,(int)s.size()), min(13,(int)s.size()));
		prin(pre[i]);
		prin(suf[i]);
		cria(s,i);
	}

	cin >> m;

	int a,b;
	for(int i=n;i<n+m;i++) {
		cin >> a >> b;
		a--;
		b--;
		pre[i] = pre[a];
		if(pre[i].size() < 13) {
			int falta = 13 - (int)pre[i].size();
			pre[i] += pre[b].substr(0,min(falta,(int)pre[b].size()));
		}
		suf[i] = suf[b];
		if(suf[i].size() < 13) {
			int falta = 13 - (int)suf[i].size();
			suf[i] = suf[a].substr(((int)suf[a].size())-min(falta,(int)suf[a].size()),min(falta,(int)suf[a].size())) + suf[i];
		}
		prin(pre[i]);
		prin(suf[i]);
		cria(suf[a] + pre[b],i);
		
		for(int k=1;k<=13;k++) {
			for(int j=0;j<=(1<<k);j++) {
				num[i][k][j] |= num[a][k][j] or num[b][k][j];
			}
		}

		int res = 0;
		for(int k=13;k>0;k--) {
			bool aux = 1;
			for(int j=0;j<(1<<k);j++) {
				if(num[i][k][j] == 0) {
					aux = 0;
					break;
				}
			}
			if(aux) {
				res = k;
				break;
			}
		}
		cout << res << endl;
	}


	return 0;

}



