#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 200100
#define int ll

string astr,bstr,s;
int lcp[N];
pair<ii, int> r[N];
int P[20][N];
int suf_arr[N];
int onde[N];
int n;
int pot[30], logg[N];

void build_lcp() {
	lcp[0] = -1LL;
	int a,b;
	for(int i=1;i<n;i++) {
		lcp[i] = 0;
		a = suf_arr[i-1];
		b = suf_arr[i];
		for(int j=logg[n]; j >= 0 and a < n and b < n; j--) {
			if(P[j][a] == P[j][b]) {
				lcp[i] += pot[j];
				a += pot[j];
				b += pot[j];
			}
		}
	}
}

void build_arr() {
	n = s.size();
	for(int i=0;i<n;i++) {
		r[i].fi.fi = s[i];
		r[i].se = i;
		P[0][r[i].se] = r[i].fi.fi;
		if(i + 1 < n) {
			r[i].fi.se = s[i+1];
		} else r[i].fi.se = -1LL;
	}
	sort(r,r+n);
	for(int i=0;i<n;i++) onde[r[i].se] = i;
	int cnt = 0;
	for(int k = 2; k <= n; k *= 2) {
		cnt++;
		ii prev_r = r[0].fi;
		r[0].fi.fi = P[cnt][r[0].se] = 0;
		for(int i=1;i<n;i++) {
			if(r[i].fi == prev_r) {
				r[i].fi.fi = r[i-1].fi.fi;
			} else {
				prev_r = r[i].fi;
				r[i].fi.fi = i;
			}
			P[cnt][r[i].se] = r[i].fi.fi;
		}
		for(int i=0;i<n;i++) {
			if(r[i].se + k < n) {
				r[i].fi.se = r[onde[r[i].se+k]].fi.fi;
			} else r[i].fi.se = -1LL;
		}
		sort(r,r+n);
		for(int i=0;i<n;i++) onde[r[i].se] = i;
	}
	for(int i=0;i<n;i++) {
		suf_arr[i] = r[i].se;
	}
	build_lcp();	
}

int conta(int pos_hash) {

	int res = 0;
	
	for(int i=0;i<n;i++) {
		int x = suf_arr[i];
		if(s[x] == '#') continue;
		prin(i);
		int asd = res;
		if(pos_hash - x > 0) {
			//b
			res += pos_hash - x - max(0LL, lcp[i]);	
		} else {
			//a
			res += n - x - max(0LL, lcp[i]);
		}
		prin(res - asd);
		separa();
	}
	return res;
}

main () {

	logg[1] = 0;
	for(int i=2;i<N;i++) {
		logg[i] = logg[i/2] + 1;
	}

	pot[0] = 1;
	for(int i=1;i<20;i++) {
		pot[i] = pot[i-1] * 2;
	}

	cin >> astr >> bstr;
	
	int ca,cb,cab;

	s = astr + "#" + bstr;
	build_arr();
/*
	for(int i=0;i<n;i++) {
		int x = suf_arr[i];
		cout << s.substr(x, s.size() - x) << " " << lcp[i] << endl;
	}
	cout << endl;
*/

	cab = conta(astr.size());

	s = astr;
	build_arr();
	ca = conta(astr.size());
	

	s = bstr;
	build_arr();
	cb = conta(bstr.size());

	prin(ca);
	prin(cb);
	prin(cab);

	
	cout << 2 * cab - ca - cb << endl;

	return 0;

}



