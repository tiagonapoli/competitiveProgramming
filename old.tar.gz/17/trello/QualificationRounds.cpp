#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define debug(args...) if(debug) fprintf(stderr,args)
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define frrs(i,a,b) for(int i = (a); i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

map<int,int> cnt;
int sum[4];
int pot=15;

bool solve(int k) {
	if(k >= 6) return 0;
	int aux;
	bool res = 0;
	k++;
	
	for(int i=0;i<=pot;i++) {
		if(cnt[i] <= 0) continue;
		//prin(k);
		//prin(i);
		cnt[i]--;
		aux = i;
		for(int j=0;j<4;j++) {
			sum[j] += aux % 2;
		//	printf("%d ", sum[j]);
			aux /= 2;
		}
		
		//cout << endl;
		res = 1;
		for(int j=0;j<4;j++) {
			if(2*sum[j] > k) {
				res = solve(k);
				break;
			}
		}
		aux = i;
		for(int j=0;j<4;j++) {
			sum[j] -= aux % 2;
			aux /= 2;
		}
		cnt[i]++;
		if(res) return 1;
	}
	return 0;
}

int main () {

	int n,k;

	scanf("%d %d", &n, &k);

	int a;
	for(int i=0;i<n;i++) {
		int res = 0;
		for(int j=0;j<k;j++) {
			scanf("%d", &a);;
			res += a * (1  << j);
		}
		cnt[res]++;
	}
/*	for(ii x : cnt) {
		printf("%d = %d\n", x.fi, x.se);
	}
	cout << endl;
*/
	if(solve(0)) {
		cout << "yes" << endl;
	} else cout << "no" << endl;
	return 0;

}



