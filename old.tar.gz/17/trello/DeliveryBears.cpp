#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100

//DINIC
const int MAXN = 200; 	//number of vertices
const int INF = 1000000000; //infinity
 
struct edge {
	int a, b, cap, flow;
};
 
int sz, s, t, d[MAXN], ptr[MAXN], q[MAXN];
vector<edge> e;
vector<int> g[MAXN];
 
void add_edge (int a, int b, int cap) {
	edge e1 = { a, b, cap, 0 };
	edge e2 = { b, a, 0, 0 };
	g[a].push_back ((int) e.size());
	e.push_back (e1);
	g[b].push_back ((int) e.size());
	e.push_back (e2);
}
 
bool bfs() {
	int qh=0, qt=0;
	q[qt++] = s;
	memset (d, -1, sz * sizeof d[0]);
	d[s] = 0;
	while (qh < qt && d[t] == -1) {
		int v = q[qh++];
		for (size_t i=0; i<g[v].size(); ++i) {
			int id = g[v][i],
				to = e[id].b;
			if (d[to] == -1 && e[id].flow < e[id].cap) {
				q[qt++] = to;
				d[to] = d[v] + 1;
			}
		}
	}
	return d[t] != -1;
}
 
int dfs (int v, int flow) {
	if (!flow)  return 0;
	if (v == t)  return flow;
	for (; ptr[v]<(int)g[v].size(); ++ptr[v]) {
		int id = g[v][ptr[v]],
			to = e[id].b;
		if (d[to] != d[v] + 1)  continue;
		int pushed = dfs (to, min (flow, e[id].cap - e[id].flow));
		if (pushed) {
			e[id].flow += pushed;
			e[id^1].flow -= pushed;
			return pushed;
		}
	}
	return 0;
}
 
int dinic() {
	int flow = 0;
	for (;;) {
		if (!bfs())  break;
		memset (ptr, 0, sz * sizeof ptr[0]);
		while (int pushed = dfs (s, INF))
			flow += pushed;
	}
	return flow;
}

////

vector<ii> adj[N];
int n,m,x;

void build(double cargo) {
	e.clear();
	for(int i=0;i<sz;i++) g[i].clear();
	add_edge(s,1,1000000);
	add_edge(n,t,1000000);
	for(int i=1;i<=n;i++) {
		ll aux;
		for(ii j : adj[i]) {
			aux = j.se;
			aux = aux / cargo;
			aux = min(aux, 100000LL);
			prin(aux);
			if(aux != 0) {
				add_edge(i,j.fi,aux);
			}
		}
	}
}

double bs(double maxi) {
	double i,f,m;
	i = 0;
	f = maxi;
	time_t tempo = clock();
	while(((double)(clock() - tempo))/CLOCKS_PER_SEC < 1.9) {
		m = (i+f)/2.0;
	//	printf("[%.3f]->[%.3f]  [%.3f]\n",i,f,m); 
		build(m);
		int flux = dinic();
		prin(flux);
		if(flux >= x) {
			i = m;
		} else if(flux < x) {
			f = m;
		}
		separa();
	}
	return f * x;
}

int main () {

	cin >> n >> m >> x;
	
	int a,b,c;
	int maxi = 0;
	for(int i=0;i<m;i++) {
		cin >> a >> b >> c;
		adj[a].pb({b,c});
		maxi = max(maxi,c);
	}

	s = 0;
	t = n+1;
	sz = n+10;

	printf("%f\n", bs(maxi));


	return 0;

}
