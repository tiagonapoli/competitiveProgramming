#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100


void ruim() {
	cout << "NO" << endl;
	exit(0);
}

int p[200];
int a[200];
bool start[200];
bool vis[200];
string res;
bool flag[200];

void dfs(int x) {
	vis[x] = 1;
	res.pb((char)x);
	if(p[x] == -1) return;
	if(vis[p[x]] == 1) ruim();
	dfs(p[x]);
}

int main () {

	int n;

	cin >> n;

	for(int i=0;i<200;i++) {
		p[i] = a[i] = -1;
	}

	string str[N];
	for(int i=0;i<n;i++) {
		cin >> str[i];
	}

	string x;
	for(int i=0;i<n;i++) {
		x = str[i];

		start[x[0]] = 1;
		flag[x[0]] = 1;
		if(x.size() == 1) continue;

		for(int j=0;j<x.size();j++) {
			char c = x[j];
			flag[c] = 1;
			if(j != x.size()-1 and p[c] != -1 and p[c] != x[j+1]) ruim();
			if(j != 0 and a[c] != -1 and a[c] != x[j-1]) ruim();
			if(j != x.size()-1) p[c] = x[j+1];
			if(j != 0) a[c] = x[j-1];
		}

		
	}

	for(int i=0;i<200;i++) {
		if(a[i] == -1 and start[i] and vis[i] == 0) {
			dfs(i);
		}
	}

	for(int i=0;i<200;i++) {
		if(flag[i] == 1 and vis[i] == 0) ruim();
	}

	cout << res << endl;

	return 0;

}



