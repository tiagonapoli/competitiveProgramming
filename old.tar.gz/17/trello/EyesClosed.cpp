#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

double seg[4*N];
int n;

struct lz {
	double a,b;
	lz() : a(1), b(0) {}
	lz(double x, double y) : a(x), b(y) {}
} lazy[4*N];

lz& operator+= (lz& a, const lz &b) {
	a.a *= b.a;
	a.b *= b.a;
	a.b += b.b;
	return a;
}

void push(int id, int l, int r) {
	lz t = lazy[id];
	lazy[id] = lz();
	seg[id] = seg[id] * t.a + t.b * (r - l + 1);
	if(l != r) {
		lazy[id*2] += t; 
		lazy[id*2+1] += t;
	}
}

double query(int a, int b, int id=1, int l=1, int r=n) {
	if(a > r or b < l) return 0.0L;
	push(id,l,r);
	if(a <= l and r <= b) {
		return seg[id];
	}
	int mid = (l+r)/2;
	return query(a,b,id*2,l,mid) + query(a,b,id*2+1,mid+1,r);
}

void build(int id=1, int l=1, int r=n) {
	lazy[id] = lz();
	if(l == r) {
		int x;
		cin >> x;
		seg[id] = x;
		return;
	}
	int mid = (l+r)/2;
	build(id*2,l,mid);
	build(id*2+1,mid+1,r);
	seg[id] = seg[id*2] + seg[id*2+1];
}

void upd(int a, int b, lz x, int id=1, int l=1, int r = n) {
	push(id,l,r);
	if(a > r or b < l) return;
	if(a <= l and r <= b) {
		lazy[id] = x;
		push(id,l,r);
		return;
	}
	int mid = (l+r)/2;
	upd(a,b,x,id*2,l,mid);
	upd(a,b,x,id*2+1,mid+1,r);
	seg[id] = seg[id*2] + seg[id*2+1];
}

void print() {
	for(int i=1;i<=n;i++) {
		printf("%f ", query(i,i));
	}
	cout << endl;
}

int main () {

	int q;
	scanf("%d %d", &n, &q);

	build();

	int a,b,t;
	int c,d;
	for(int i=0;i<q;i++) {
		scanf("%d", &t);
		scanf("%d %d", &a, &b);
		if(t == 1) {
			scanf("%d %d", &c, &d);
			double sum1, sum2;
			sum1 = query(a,b) / (b - a + 1);
			sum2 = query(c,d) / (d - c + 1);
			upd(a,b, lz((double) (b - a)/(b - a + 1), sum2 /(b - a + 1)));
			upd(c,d, lz((double) (d - c)/(d - c + 1), sum1 /(d - c + 1)));
	//		print();
		} else {
			printf("%f\n", query(a,b));
		}

	}

	return 0;

}



