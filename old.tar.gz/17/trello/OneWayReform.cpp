#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 210

int n,m;
int adj[N][N];
map<ii,int> res;
vector<int> scc[N];
bool vis[N];
int grau[N];
int cnt = 0;
int tot[N];

void dfs(int x) {
	prin(x);
	vis[x] = 1;
	scc[cnt].pb(x);
	for(int i = 1;i <= n;i++) {
		if(adj[x][i] > 0 and vis[i] == 0) {
			dfs(i);
		}
	}
}

void dfs_euler(int x) {
	prin(x);
	while(grau[x] < tot[x]/2) {
		for(int i=1;i<=n;i++) {
			while(adj[x][i] > 0) {
				res[{x,i}]++;
				adj[x][i]--;
				adj[i][x]--;
				grau[x]++;
				dfs_euler(i);
			}
		}
	}

}


int main () {

	int t;

	cin >> t;

	while(t--) {
		cin >> n >> m;
	
		cnt = 0;
		res.clear();
		for(int i=1;i<=n;i++) {
			grau[i] = 0;
			impar[i] = 0;
			vis[i] = 0;
			scc[i].clear();
			for(int j=1;j<=n;j++) {
				adj[i][j] = 0;
			}
		}

		int a,b;
		for(int i=1;i<=m;i++) {
			cin >> a >> b;
			adj[a][b]++;
			adj[b][a]++;
		}

		int r = 0;
		for(int i=1;i<=n;i++) {
			if(vis[i] == 0) {
				cnt++;
				prin(cnt);
				dfs(i);
			}
			tot[i] = 0;
			for(int j=1;j<=n;j++) {
				tot[i] += adj[i][j];
			}
			if(tot[i] % 2 == 0) r++;
		}
		separa();
		
		for(int i=1;i<=cnt;i++) {
			vector<int> odd;
			for(int x : scc[i]) {
				if(tot[x] % 2) {
					odd.pb(x);
				} 
			}
			for(int i=0;i<odd.size();i+=2) {
				adj[odd[i]][odd[i+1]]++;
				adj[odd[i+1]][odd[i]]++;
				tot[odd[i]]++;
				tot[odd[i+1]]++;
			}

			separa();
			dfs_euler(scc[i][0]);
			for(int i=0;i<odd.size();i+=2) {
				if(res[{odd[i],odd[i+1]}] > 0) {
					res[{odd[i],odd[i+1]}]--;
				} else {
					res[{odd[i+1],odd[i]}]--;
				}
			}
		}
		cout << r << endl;
		for(auto x : res) {
			if(x.se > 0) printf("%d %d\n", x.fi.fi, x.fi.se);
		}
	}

	return 0;

}



