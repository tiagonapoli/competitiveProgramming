#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

vector<int> a;
vector<int> b;
int v[N];
int n,m;

int brute(int pos, int to, bool onde) {
	int sz;
	for(int i=pos;i<to;i++) {
		if(onde) {
			sz = a.size();
			for(int j=0;j<sz;j++) {
				a.pb((v[i] + a[j]) % m);
			}
		} else {
			sz = b.size();
			for(int j=0;j<sz;j++) {
				b.pb((v[i] + b[j]) % m);
			}
		}
	}
}

int main () {

	cin >> n >> m;

	for(int i=0;i<n;i++) {
		cin >> v[i];
	}

	int mid = n/2;
	a.pb(0);
	b.pb(0);
	brute(0,mid,1);
	brute(mid,n,0);
	sort(a.begin(), a.end());
	sort(b.begin(), b.end());

	for(int x : a) {
//		printf("%d ", x);
	}
//	cout << endl;
	for(int x : b) {
//		printf("%d ", x);
	}

	int res = 0;
	for(int x : a) {
		prin(x);
		prin(m - x - 1);
		int other = lower_bound(b.begin(), b.end(), m - x) - b.begin();
		other--;
		if(other == -1) continue;
		prin(b[other]);
		res = max(res, (x + b[other]) % m);
	}
	
	cout << res << endl;


	return 0;

}



