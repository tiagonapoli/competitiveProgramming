#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 1000100

bool has[N];

int main () {
	
	int n;

	int v[N];
	int mini = 9999999;
	cin >> n;
	for(int i=0;i<n;i++) {
		cin >> v[i];
		has[v[i]] = 1;
		mini = min(mini, v[i]);
	}
	
	vector<int> res;
	for(int i=0;i<n;i++) {
		res.pb(v[i]);
		res.pb(mini);
	}
	
	int c = res[0];
	for(int i=0;i<n;i++) {
		c = __gcd(v[i],c);
		if(has[c] == 0) {
			cout << -1 << endl;
			return 0;
		}
	}

	printf("%d\n", res.size());

	for(int x : res) {
		printf("%d ", x);
	}
	cout << endl;




	return 0;

}



