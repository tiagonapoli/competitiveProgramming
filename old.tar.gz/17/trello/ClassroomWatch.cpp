#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

int x;

bool check(int a, int b) {
	int s = 0;
	if(b <= 0) return 0;
	while(b != 0) {
		s += b % 10;
		b /= 10;
	}
	return (a == s);
}

int main () {
	
	cin >> x;
	vector<int> res;
	for(int i=0;i<=81;i++) {
		if(check(i,x-i)) {
			res.pb(x-i);
		}
	}

	sort(res.begin(), res.end());

	printf("%d\n", res.size());
	for(int i : res) {
		printf("%d\n", i);
	}


	return 0;

}



