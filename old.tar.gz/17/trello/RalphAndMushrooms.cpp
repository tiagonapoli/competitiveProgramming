#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 1000100

vector<ii> adj[N];
vector<int> adjinv[N];
vector<ii> adjscc[N];
int scc[N];
int cnt = 1;
bool vis[N];
stack<int> ordem;
ll rscc[N];

ll acum[51000];
ll pa[51000];
ll qtd(ll x) {
	int pos = lower_bound(pa,pa+50005,x) - pa;
	if(pa[pos] > x) pos--;
	return x*(ll)(pos+1) - acum[pos];
}

void dfs2(int x) {
	prin(x);
	scc[x] = cnt;
	vis[x] = 1;
	for(int y : adjinv[x]) {
		if(vis[y] == 0) dfs2(y);
	}
}

void dfs(int x) {
	vis[x] = 1;
	for(ii y : adj[x]) {
		if(vis[y.fi] == 0) dfs(y.fi);
	}
	ordem.push(x);
}

ll dp[N];
ll solve(int now) {
	if(dp[now] != -1LL) return dp[now];
	ll res = rscc[now];
	for(ii x : adjscc[now]) {
		res = max(res, rscc[now] + (ll)x.se + solve(x.fi)); 
	}
	return dp[now] = res;
}

ll brute(ll x) {
	ll res = 0;
	ll conta = 1;
	while(x > 0) {
		res += x;
		x -= conta;
		conta++;
	}
	return res;
}

int main () {

	int n,m;
	
	for(int i=1;i<=50010;i++) {
		pa[i] = pa[i-1] + i;
		acum[i] = acum[i-1] + pa[i];
	}

	for(int i=0;i<N;i++) dp[i] = -1LL;

	cin >> n >> m;
	
	int a,b,c;
	for(int i=0;i<m;i++) {
		scanf("%d %d %d", &a, &b, &c);
		adj[a].pb({b,c});
		adjinv[b].pb(a);
	}

	int s;

	cin >> s;

	for(int i=1;i<=n;i++) {
		if(vis[i] == 0) dfs(i);
	}

	for(int i=0;i<=n;i++) vis[i] = 0;

	while(!ordem.empty()) {
		int now = ordem.top();
		prin(now);
		ordem.pop();
		if(vis[now] == 0) {
			dfs2(now);
			cnt++;
		}
	}
/*
	for(int i=1;i<=n;i++) {
		printf("%d -> %d\n", i, scc[i]);
	}
*/
	for(int i=1;i<=n;i++) {
		for(ii y : adj[i]) {
			if(scc[i] != scc[y.fi]) {
				adjscc[scc[i]].pb({scc[y.fi],y.se});
			} else rscc[scc[i]] += qtd(y.se);
		}
	}
/*
	for(int i=1;i<cnt;i++) {
		printf("%d: ", i);
		for(ii x : adjscc[i]) {
			printf("%d/%d ", x.fi, x.se);
		}
		
		separa();
	}
	separa();
*/	cout << solve(scc[s]) << endl;


	return 0;

}



