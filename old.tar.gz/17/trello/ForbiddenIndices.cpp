#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug =0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double eps = 1e-9;
const double PI = acos(-1.0);
using namespace std;
#define N 201000
#define int ll

int n;
int sa[N];
int P[32][N];
int lcp[N];
int logg[N];
int pot2[N];
int onde[N];
pair<ii, int> rk[N];
string s;

void print() {
	for(int i=0;i<s.size();i++) {
		cout << s.substr(rk[i].se, s.size() - rk[i].se) << " ";
		printf(" %lld lcp %lld\n",sa[i], lcp[i]);
	}
	cout << endl;
}

void build_lcp() {
	lcp[0] = -1;
	int a,b;
	for(int i=1;i<s.size();i++) {
		lcp[i] = 0;
		a = sa[i];
		b = sa[i-1];
		for(int j=logg[s.size()];j >= 0 and a < s.size() and b < s.size();j--) {
			if(P[j][a] == P[j][b]) {
				lcp[i] += pot2[j];
				a += pot2[j];
				b += pot2[j];
			} 
		}
	}
}

void build() {
	
	int sz = s.size();

	for(int i=0;i<s.size();i++) {
		rk[i].fi.fi = s[i];
		if(i != s.size()-1) {
			rk[i].fi.se = s[i+1];
		} else rk[i].fi.se = -9999;
		rk[i].se = i;
		sa[i] = i;
		P[0][rk[i].se] = rk[i].fi.fi;
	}

	sort(rk, rk + sz);
	for(int i=0;i<sz; i++) {
		onde[rk[i].se] = i;	
	}

	int cnt = 0;
	for(int k = 2; k <= sz; k *= 2) {	
		cnt++;
		ii prev_rank = rk[0].fi;
		rk[0].fi.fi = 0;
		P[cnt][rk[0].se] = 0;
		for(int i=1;i<sz;i++) {
			if(rk[i].fi == prev_rank) {
				rk[i].fi.fi = rk[i-1].fi.fi;	
			} else {
				prev_rank = rk[i].fi;
				rk[i].fi.fi = i; 
			}
			P[cnt][rk[i].se] = rk[i].fi.fi;
		}
		int quem;
		for(int i=0;i<sz;i++) {
			if(rk[i].se+k >= sz) {
				rk[i].fi.se = -1;
				continue;
			}
			quem = onde[rk[i].se + k];
			rk[i].fi.se = rk[quem].fi.fi;
		}
		sort(rk, rk + sz);
		for(int i=0;i<sz; i++) {
			onde[rk[i].se] = i;	
		}
	}

	for(int i=0;i<sz;i++) {
		sa[i] = rk[i].se;
	}
	
	build_lcp();
}


main () {

	string p;
	logg[1] = 0;
	for(int i=2;i<N;i++) {
		logg[i] = logg[i/2] + 1;
	}

	pot2[0] = 1;
	for(int i=1;i<20;i++) {
		pot2[i] = pot2[i-1] * 2;
	}

	cin >> n;

	cin >> s;
	cin >> p;
	reverse(s.begin(), s.end());
	reverse(p.begin(), p.end());
	build();

	int res = 0;
	lcp[0] = 0;
	vector<ii> asd;
	for(int i=n-1;i>=0;i--) {
		if(p[sa[i]] == '1') {
			if(asd.size() > 0 and asd[asd.size()-1].fi > lcp[i]) {
				asd[asd.size()-1].fi = lcp[i];
			}
			continue;
		}
		res = max(res, n - sa[i]);
		asd.pb({lcp[i], i});
	}

	reverse(asd.begin(), asd.end());
//  print();
	n = asd.size();
/*	for(int i=0;i<n;i++) {
		cout << s.substr(sa[asd[i].se], s.size() - sa[asd[i].se]) << " " << i << " lcp " << lcp[asd[i].se] << endl;
	}
	cout << endl;
*/	stack<ii> pilha;
	
	asd.pb({0,0});
	for(int i=0;i<=n;i++) {
		prin(i);
		int aux = i;
		while(!pilha.empty() and pilha.top().fi >= asd[i].fi) {
			ii now = pilha.top();
			pilha.pop();
			prin(now.fi);
			prin(now.se);
			prin(i - now.se + 1);
			separa();
			aux = min(aux,now.se);
			res = max(res, now.fi * (i - now.se + 1));
		}
		pilha.push({asd[i].fi, aux});
	}

	cout << res << endl;




	return 0;

}



