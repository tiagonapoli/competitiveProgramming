#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 110

int n,k;
bool grid[N][N];
int res[N][N];

int go(int i, int j) {
	if(grid[i][j]) return 0;
	int res = 0;
	int auxv = 1;
	int auxh = 1;
	for(int x=1;x<k and i+x<n;x++) {
		if(grid[i+x][j] == 1) break;
		auxv++;
	}
	for(int x=1;x<k and i-x >= 0;x++) {
		if(grid[i-x][j] == 1) break;
		auxv++;
	}
	for(int x=1;x<k and j+x<n;x++) {
		if(grid[i][j+x] == 1) break;
		auxh++;
	}
	for(int x=1;x<k and j-x >= 0;x++) {
		if(grid[i][j-x] == 1) break;
		auxh++;
	}
	return max(0,auxv-k+1) + max(0,auxh-k+1);
}

int main () {

	cin >> n >> k;

	char c;
	for(int i=0;i<n;i++) {
		for(int j=0;j<n;j++) {
			scanf(" %c" ,&c);
			if(c == '.') {
				grid[i][j] = 0;
			} else grid[i][j] = 1;
		}
	}

	int maxi = 0;
	for(int i=0;i<n;i++) {
		for(int j=0;j<n;j++) {
			res[i][j] += go(i,j);
			maxi = max(maxi, res[i][j]);
		}
	}

	for(int i=0;i<n;i++) {
		for(int j=0;j<n;j++) {
			if(maxi == res[i][j]) {
				printf("%d %d\n", i+1, j+1);
				return 0;
			}
		}
	}

	return 0;

}



