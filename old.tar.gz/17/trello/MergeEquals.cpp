#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

map<ll, set<int> > pos;

int main () {
	
	int n;

	scanf("%d", &n);
	int x;
	for(int i=0;i<n;i++) {
		scanf("%d", &x);
		pos[x].insert(i);
	}

	vector<pair<int,ll> > res;
	int aux;
	for(auto it=pos.begin(); it!=pos.end();) {
		if(it->se.size() <= 1) {
			for(int i : it->se) {
				res.pb({i,it->fi});
			}
			it = pos.erase(it);
		} else {
			pos[2*it->fi].insert(*(++it->se.begin()));
			it->se.erase(it->se.begin());
			it->se.erase(it->se.begin());
		}
	}

	sort(res.begin(), res.end());
	printf("%d\n", (int) res.size());
	for(pair<int,ll> i : res) {
		printf("%lld ", i.se);
	}

	return 0;

}



