#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 210

vector<int> adj[N];
vector<int> iadj[N];
vector<int> scc[N];
int idscc[N];
int cnt = 0;
int n,m;
stack<int> pilha;
int vis[N];

void dfs1(int x) {
	vis[x] = 1;
	for(int p : adj[x]) {
		if(vis[p] == 0) {
			dfs1(p);
		}
	}
	pilha.push(x);
}

void dfs2(int x) {
	prin(x);
	vis[x] = 1;
	scc[cnt].pb(x);
	idscc[x] = cnt;
	for(int p : iadj[x]) {
		if(vis[p] == 0) {
			dfs2(p);
		}
	}
}

bool sat() {
	for(int i=2;i<=2*n+1;i++) {
		if(vis[i] == 0) dfs1(i);
	}

	for(int i=0;i<=2*n+1;i++) vis[i] = 0;

	while(!pilha.empty()) {
		int now = pilha.top();
		prin(now);
		pilha.pop();
		if(vis[now] == 0) {
			cnt++;
			prin(cnt);
			dfs2(now);
			separa();
		}

	}
	
	for(int i=2;i<=2*n+1;i++) {
		if(idscc[i] == idscc[i xor 1]) return 0;
	}
	return 1;
}


void foo(int a, int b, bool nA, bool nB) {
	if(nA) a = a ^ 1;
	if(nB) b = b ^ 1;
	adj[a xor 1].pb(b);
	adj[b xor 1].pb(a);
	iadj[b].pb(a xor 1);
	iadj[a].pb(b xor 1);
}

void add(int a, int b, int c) {
	if(c == 0) {
		foo(a,b,0,1);
		foo(a,b,1,0);
	} else {
		foo(a,b,0,0);
		foo(a,b,1,1);
	}
}

vector<int> v0,v1;
void dfs3(int x) {
	if(vis[x/2] == 1) return; 
	vis[x/2] = 1;
//	printf("dfs3 %d\n", x);
	
	if(x & 1) {
		v1.pb(x);
	} else v0.pb(x);
	for(int p : adj[x]) {
		if(vis[p/2] == 0) {
			dfs3(p);
		}
	}
}

int main () {

	cin >> n >> m;

	int a,b;
	bool c;
	for(int i=0;i<m;i++) {
		cin >> a >> b >> c;
		add(2*a,2*b,!c);
	}

	/*
	for(int i=2;i<=2*n+1;i++) {
		printf("%d: ", i);
		for(int x : adj[i]) {
			printf("%d ", x);
		}
		cout << endl;
	}
*/
	if(sat() == 0) {
		cout << "Impossible" << endl;
		return 0;
	}
	
	vector<int> res;
	for(int i=0;i<=2*n+1;i++) vis[i] = 0;

	for(int i=1;i<=cnt;i++) {
		v1.clear();
		v0.clear();
		prin(i);
		dfs3(scc[i][0]);
		prin(scc[i][0]);
		prin(v1.size());
		prin(v0.size());
		separa();
		if(v1.size() > v0.size()) {
			res.insert(res.end(), v0.begin(), v0.end());
		} else res.insert(res.end(), v1.begin(), v1.end());
	}
	

	cout << res.size() << endl;
	for(int i : res) {
		printf("%d ", i/2);
	}
	cout << endl;


	return 0;

}



