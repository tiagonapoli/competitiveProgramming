#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

vector<pii> l[2];
pii v[N];
bool t[N];
int n;

pii sub(pii a, pii b) {
	return pii(a.fi-b.fi, a.se-b.se);
}

ll cross(pii a, pii b, pii c) {
	pii ab = sub(b,a);
	pii ac = sub(c,a);
	return (ll)ab.fi * (ll)ac.se - (ll)ab.se * (ll)ac.fi;
}

bool check() {
	vector<pii> a;
	vector<pii> b;
	if(l[0].size() == 2) {
		a.pb(l[0][0]);
		a.pb(l[0][1]);
	} else if(l[1].size() == 2) {
		a.pb(l[1][0]);
		a.pb(l[1][1]);
	} else return false;
	
	for(int i=0;i<n;i++) {
		if(cross(a[0],a[1],v[i]) == 0) {
			t[i] = 0;
		} else {
			t[i] = 1;
			if(b.size() < 2) b.pb(v[i]);
		}
	}
	
	if(b.size() < 2) return true;

	for(int i=0;i<n;i++) {
		if(t[i] == 1 and cross(b[0],b[1],v[i]) != 0) return false;
	}
	
	return true;
}	

int main () {


	scanf("%d", &n);

	for(int i=0;i<n;i++) {
		scanf("%d %d", &v[i].fi, &v[i].se);
	}

	l[0].pb(v[0]);
	for(int i=1;i<=2;i++) {
		l[0].pb(v[i]);
		if(check()) {
			break;
		} else {
			l[0].pop_back();
			l[1].pb(v[i]);
		}
	}

	for(int i=0;i<n;i++) {
		//printf("%d %d %d\n", t[i], v[i].fi, v[i].se);
	}

	if(check()) {
		printf("YES\n");
	} else printf("NO\n");

	return 0;

}



