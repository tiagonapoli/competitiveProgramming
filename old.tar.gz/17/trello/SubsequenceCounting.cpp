#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100


int main () {

	ll x,d;

	cin >> x >> d;

	ll sum = 0;
	vector<ll> res;
	ll last = 1;
		
	for(int i=30;i>0;i--) {
		prin(i);
		while(sum - 1LL + (1LL<<i) <= x and res.size() < 10000) {
			sum += -1LL + (1LL<<i);
			for(int j=0;j<i;j++) {
				res.pb(last);
			}
			last += d;
			prin(sum);
		}
		separa();
	}

	if(sum < x or res.size() > 10000) {
		printf("-1\n");
	} else {
		printf("%d\n", (int)res.size());
		for(ll i : res){
			printf("%lld ", i);
		}
		cout << endl;

	}

	return 0;

}



