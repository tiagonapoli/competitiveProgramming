#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 1001000


string a,b;
ll fact[N];
ll fact_i[N];

ll fast_pow(ll b, ll e) {
	ll res = 1;
	while(e > 0) {
		if(e % 2 == 1) {
			res *= b;
			res %= MOD;
		}
		b *= b;
		b %= MOD;
		e /= 2;
	}
	return res;
}

ll solve(string str) {
	int cnt[26];
	for(int i=0;i<26;i++) cnt[i] = 0;
	for(int i=0;i<a.size();i++) {
		cnt[a[i] - 'a']++;
	}
	ll res = 0;
	for(int i=0;i<str.size();i++) {
		ll aux = fact[str.size()-i-1];
		for(int j=0;j<26;j++) {
			aux *= fact_i[cnt[j]];
			aux %= MOD;
		}
		for(int j=0;j <str[i]-'a';j++) {
			if(cnt[j] == 0) continue;
			res += (((aux * fact[cnt[j]])%MOD) * fact_i[cnt[j]-1])%MOD;
			res %= MOD;
		}
		
		if(cnt[str[i]-'a'] != 0) {
			cnt[str[i]-'a']--;
		} else break;
	}
	return res;
}

int main () {

	fact[0] = 1;
	fact_i[0] = 1;
	for(int i=1;i< N; i++) {
		fact[i] = fact[i-1] * i;
		fact[i] %= MOD;
		fact_i[i] = fast_pow(fact[i], MOD-2LL);
	}

	cin >> a >> b;
	cout << (((solve(b) - solve(a) - 1) + MOD) % MOD) << endl;
	return 0;

}



