#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

int a[N];
int v[N];
int vv[N];
int n;

int dist(int cnt) {
	int errado = 0;
	for(int i=1;i<n-1;i++) {
		if(cnt % 2 == 0) {
			if(a[i] > n/2) errado++;
		} else {
			if(a[i] <= n/2) errado++;
		}
		cnt++;
	}
	return errado/2;
}

int main () {
	
	int t;

	cin >> t;
	int x,y;
	while(t--) {

		cin >> n;
		
		for(int i=0;i<n;i++) {
			cin >> a[i];
		}
		
		for(int i=0;i<n;i++) {
			vv[i] = a[i];
			if(a[i] == n/2) x = i;
			if(a[i] == n/2+1) y = i;
		}

		int res = 0;
		if(x != 0) {
			res++;
			if(a[0] == n/2+1) swap(x,y);
			swap(a[x],a[0]);
		}
		if(y != n-1) {
			res++;
			swap(a[y],a[n-1]);
		}
		res += dist(1);

		for(int i=0;i<n;i++) {
			a[i] = vv[i];
			if(a[i] == n/2) x = i;
			if(a[i] == n/2+1) y = i;
		}

		int aux = 0;
		if(x != n-1) {
			aux++;
			if(a[n-1] == n/2+1) swap(x,y);
			swap(a[x],a[n-1]);
			
		}
		if(y != 0) {
			aux++;
			swap(a[y],a[0]);
		}
		res = min(res,aux+dist(0));
			

		
		cout << res << endl;

	}


	return 0;

}




