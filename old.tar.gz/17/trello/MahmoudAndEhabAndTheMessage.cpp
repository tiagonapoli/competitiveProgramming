#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

map<string,int> dicio;

int pai[N];
int find(int x) {
	if(pai[x] == x) return x;
	return pai[x] = find(pai[x]);
}

int cost[N];

void join(int a, int b) {
	a = find(a);
	b = find(b);
	pai[a] = b;
	cost[b] = min(cost[a], cost[b]);
}

int main () {

	int n,k,m;

	cin >> n >> k >> m;

	string s;
	for(int i=1;i<=n;i++) {
		cin >> s;
		dicio[s] = i;
		pai[i] = i;
	}

	for(int i=1;i<=n;i++) {
		cin >> cost[i];
	}

	for(int i=0;i<k;i++) {
		int x, g,g1;
		cin >> x;
		cin >> g;
		for(int j=1;j<x;j++) {
			cin >> g1;
			join(g,g1);
		}
	}

	ll res = 0;
	for(int i=0;i<m;i++) {
		cin >> s;
		res += cost[find(dicio[s])];
	}

	cout << res << endl;

	

	return 0;

}



