#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

ll sqr(ll x) {return x*x;}

bool cmp(pii a, pii b) {
	return abs(a.fi-a.se) > abs(b.fi-b.se);
}

int a[N], b[N];
vector<pii> v;
int main () {

	int n;
	int k1,k2;

	cin >> n >> k1 >> k2;

	for(int i=0;i<n;i++) {
		cin >> a[i];
	}

	for(int i=0;i<n;i++) {
		cin >> b[i];
	}

	for(int i=0;i<n;i++) {
		v.pb({a[i], b[i]});
	}

	sort(v.begin(), v.end(), cmp);

	for(pii x : v) {
//		printf("asd %d %d\n", x.fi, x.se);
	}

	while(k1 > 0) {
		if(v[0].fi < v[0].se) {
			v[0].fi++;
		} else v[0].fi--;
		k1--;
		sort(v.begin(), v.end(), cmp);
	}
	
	while(k2 > 0) {
		if(v[0].fi < v[0].se) {
			v[0].se--;
		} else v[0].se++;
		k2--;
		sort(v.begin(), v.end(), cmp);
	}
	
	ll res = 0;
	for(int i=0;i<v.size();i++) {
		res += sqr(v[i].fi - v[i].se);
	}

	cout << res << endl;

	return 0;

}



