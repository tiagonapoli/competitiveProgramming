#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 110

map<char, int> st[N];
ll m[N][N][N];
int n,x;
string s;

void init() {
	int pf[N];
	pf[0] = 0;
	for(int i=1;i<s.size();i++) {
		pf[i] = pf[i-1];
		while(pf[i] > 0 and s[i] != s[pf[i]]) {
			pf[i] = pf[pf[i]-1];
		}
		if(s[i] == s[pf[i]]) {
			pf[i]++;
		}
	}

	for(int i='0';i<='1';i++) {
		st[0][i] = (s[0] == i);
	}

	for(int i=1;i<=n;i++) {
		for(int j='0';j<='1';j++) {
			if(s[i] == j) {
				st[i][j] = i+1;
			} else st[i][j] = st[pf[i-1]][j];
		}
	}

	for(int i=0;i<2;i++) {
		for(int j=0;j<=n;j++) {
			m[i][j][j] += 1;
			m[i][j][st[j]['0'+i]] += 1;
		}

		for(int j=0;j<=n;j++) {
			m[i][j][n+1] = m[i][j][n]; 
		}
		m[i][n][n+1]--;
		m[i][n+1][n+1] = 2;
	}
	

}

void mul(ll a[N][N],ll b[N][N], ll res[N][N]) {
	for(int i=0;i<=n+1;i++) {
		for(int j=0;j<=n+1;j++) {
			res[i][j] = 0;
			for(int k=0;k<=n+1;k++) {
				res[i][j] += (a[i][k] * b[k][j]) % MOD;
				res[i][j] %= MOD;
			}
		}
	}
}

int main () {


	cin >> n >> x >> s;

	init();		
	
	ll res = 0;
	ll novo,ant, now;
	ant = 0;
	for(int i=2;i<=x;i++) {
		mul(m[i-1], m[i-2], m[i]);
	}

	cout << m[x][0][n+1] << endl;
	

	return 0;

}



