#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 60


ll inf = 1e10;
ll dp[N][N][N][N];
vector<int> adj[N];
int dist[N][N];
int n,m;
ll v[N];
bool leaf[N];

int dfs(int ant, int now) {
	int tot = v[now];
	if(adj[now].size() == 1) leaf[now] = 1;
	for(int u : adj[now]) {
		if(u == ant) continue;
		tot += dfs(now,u);
	}
	return tot;
}

int sol(int src, int dest, int k, int a) {
	if(k == 0) return 0;
	if(a == 0) return inf;
	ll &res = dp[src][dest][k][a]; 
	if(res != -1LL) return res;
	if(leaf[dest]) {
		printf("leaf %d %d %d %d\n",src,dest,k,a);
		res =  dist[src][dest] + sol(dest,src,k-a,k-a);

		printf("dp[%d][%d][%d][%d] = %lld\n\n", src,dest,k,a,res);
		prin(res);
		separa();
		separa();
		return res; 
	}

	int prox;
	//minimo dos maximos
	int mini = inf;
	for(int u : adj[dest]) {
		if(u == src) continue;
		prox = u;
		int maxi = 0;
		for(int i=1;i<=k;i++) {
			if(sol(dest,prox,k,i) > maxi) maxi = sol(dest,prox,k,i);	
		}
		if(maxi = 0) maxi = inf;
		mini = min(maxi,mini);
	}
	if(mini == inf) mini = 0;
	res = mini + dist[src][dest];
	printf("binaria dp[%d][%d][%d][%d] = %lld\n\n", src,dest,k,a,res);
	return res;

}


int main () {
	
	cin >> n;

	int a,b,c;

	int cnt = 0;
	for(int i=0;i<n-1;i++) {
		cin >> a >> b >> c;
		adj[a].pb(b);
		adj[b].pb(a);
		dist[a][b] = dist[b][a] = c;
	}

	for(int i=0;i<=51;i++) {
		for(int j=0;j<=51;j++) {
			for(int k=0;k<=51;k++) {
				for(int kk=0;kk<=51;kk++) {
					dp[i][j][k][kk] = -1LL;
				}
			}
		}
	}
	
	int s;

	cin >> s;

	cin >> m;

	
	for(int i=0;i<n;i++) {
		cin >> a;
		v[a]++;
	}

	int res = inf;

	if(adj[s].size() == 1) leaf[s] = 1;
	for(int u : adj[s]) {
		int aux = dfs(s,u);
		if(aux == 0) continue;
		res = min(res, dist[s][u] + sol(s,u,m, aux));
	}
	
	dfs(s,s);
	//sol(3,1,2,2);

	cout << res << endl;

	return 0;

}



