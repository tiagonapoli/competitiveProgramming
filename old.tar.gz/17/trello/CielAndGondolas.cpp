#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 4100

int n,k;

int dp[810][N];
int A[810][N];
int c[N][N];
int sum[N][N];
int inf = 1000000000;

int cost1(int x1, int y1, int x2, int y2) {
	return sum[x2][y2] - sum[x2][y1-1] - sum[x1-1][y2] + sum[x1-1][y1-1];
}

int cost(int a, int b) {
	if(b < a) return inf;
	return cost1(a,a,b,b)/2;
}

void fill(int g, int l, int r, int kl, int kr) {
	
	if(l <= 0 or l > n or r <= 0 or r > n or r < l) return;

	if(g == 1) {
		for(int i=l;i<=r;i++) {
			dp[g][i] = cost(l,i);
		//	printf("dp[%d][%d] = %lld\n", g,i,dp[g][i]);
		}
		return;
	}
/*
	prin(g);
	prin(l);
	prin(r);
	prin(kl);
	prin(kr);
*/
	int mid = (l+r)/2;
	A[g][mid] = kl;
	dp[g][mid] = inf;

	ll aux;
	for(int i=kl;i<=kr;i++) {
		aux = dp[g-1][i] + cost(i+1,mid);
		if(aux < dp[g][mid]) {
			dp[g][mid] = aux;
			A[g][mid] = i;
		}
	}

	fill(g,l,mid-1,kl,A[g][mid]);
	fill(g,mid+1,r,A[g][mid],kr);
	
}

int main () {

	scanf("%d%d\n",&n,&k);
	char buffer[10000];
	for(int i=1; i<=n; i++) {
  		gets(buffer);
  		for(int j=1; j<=n; j++)
    		c[i][j] = buffer[2 * (j - 1)] - '0';
	}

	sum[1][1] = c[1][1];
	for(int i=2;i <= n;i++) {
		sum[1][i] = sum[1][i-1] + c[1][i];
		sum[i][1] = sum[i-1][1] + c[i][1];
	}
	
	
	for(int i=2;i<=n;i++) {
		for(int j=2;j<=n;j++) {
			sum[i][j] = c[i][j] + cost1(i,1,i,j-1) + cost1(1,j,i-1,j) + cost1(1,1,i-1,j-1);
		}
	}

	for(int i=1;i<=k;i++) {
		fill(i,1,n,1,n);
	}

	printf("%d\n", dp[k][n]);

	return 0;

}



