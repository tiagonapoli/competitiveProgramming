#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double eps = 1e-9;
using namespace std;
#define N 100100

//typedef complex<double> base;
typedef long double ld;
const ld PI = acos(-1.0);
inline ld sqr(ld x) {return x*x;}
struct base {
    ld re, im;
    base() {re = 0.0; im = 0.0;}
	base(ld re) : re(re) {im = 0.0;}
    base(ld re, ld im): re(re), im(im) { }
    ld slen() const { return sqr(re) + sqr(im); }
    ld real() { return re; }
};
 

inline base conj(const base& a) { return base(a.re, -a.im); }
inline base operator+ (const base& a, const base& b) { return base(a.re + b.re, a.im + b.im); }
inline base operator- (const base& a, const base& b) { return base(a.re - b.re, a.im - b.im); }
inline base operator* (const base& a, const base& b) { return base(a.re * b.re - a.im * b.im, a.re * b.im + a.im * b.re); }
inline base operator/ (const base& a, const ld& b) { return base(a.re / b, a.im / b); }
inline base operator/ (const base& a, const base& b) { return base(a.re * b.re + a.im * b.im, a.im * b.re - a.re * b.im) / b.slen(); }
inline base& operator/= (base& a, const ld& b) { a.re /= b, a.im /= b; return a; }


//Escrever a propria estrutura para complexos pode melhorar a complexidade em uns 20%
//O TAMANHO DOS VETORES DEVEM SER POTENCIAS DE 2
// Computes the DFT of vector v if type = 0, or the IDFT if type = 1

void fft (vector<base> & a, bool invert) {
	int n = (int) a.size();

	for (int i=1, j=0; i<n; ++i) {
		int bit = n >> 1;
		for (; j>=bit; bit>>=1)
			j -= bit;
		j += bit;
		if (i < j)
			swap (a[i], a[j]);
	}
 
	for (int len=2; len<=n; len<<=1) {
		ld ang = 2*PI/len * (invert ? -1 : 1);
		base wlen (cos(ang), sin(ang));
		for (int i=0; i<n; i+=len) {
			base w ((ld) 1);
			for (int j=0; j<len/2; ++j) {
				base u = a[i+j],  v = a[i+j+len/2] * w;
				a[i+j] = u + v;
				a[i+j+len/2] = u - v;
				w = w * wlen;
			}
		}
	}
	
	if (invert)
		for (int i=0; i<n; ++i)
			a[i] /= n;
}
 
//Controlar o grau dos polinomios [e bem mais eficiente, senao pode acontecer do tamanho do resultado sempre dobrar, aumentando o tempo
void multiply (const vector<int> & a, const vector<int> & b, vector<int> & res, int grauA = -1, int grauB = -1) {
	vector<base> fa (a.begin(), a.end()),  fb (b.begin(), b.end());
	size_t n = 1;
	if(grauA == -1 or grauB == -1) {
	    while (n < max(a.size(),b.size()))  n <<= 1;
		n <<= 1;
	} else {
	    while (n <= grauA+grauB) n <<= 1;
	}
	
	fa.resize (n),  fb.resize (n);
	fft (fa, false),  fft (fb, false);
	for (size_t i=0; i<n; ++i)
		fa[i] = fa[i] * fb[i];
	fft (fa, true);
 
	res.resize (n);

	ld aux = 0.5;
	for (size_t i=0; i<n; ++i)
		res[i] = int (fa[i].real() + aux); //MAY GENERATE PROBLEMS WITH NEGATIVE NUMBERS
}




int v[1010];
vector<int> res,a;
int n,k;

void fast(int e) {
    a.resize(1024);
	res.pb(1);
	int grauA, grauRes;
	grauRes = 1;
    grauA = 0;
	for(int i=0;i<n;i++) {
		a[v[i]] = 1;
		grauA = max(grauA,v[i]);
	}
	while(e) {
		if(e & 1) {
			multiply(res,a,res,grauRes, grauA);
			prin(res.size());
			grauRes += grauA;
			for(int i=0;i<res.size();i++) 
			    if(res[i]) res[i] = 1;
			    else res[i] = 0;
		}
		multiply(a,a,a, grauA, grauA);
		grauA *= 2;
		prin(a.size());
		int maxi = 0;
		for(int i=0;i<a.size();i++) {
		    if(a[i]) {
		        maxi = i;
		        a[i] = 1;
		    } else a[i] = 0;
		}
		prin(maxi);
		e >>= 1;
	}
}

int main () {
	

	scanf("%d %d", &n, &k);

	for(int i=0;i<n;i++) {
		scanf("%d", &v[i]);
	}

	fast(k);

	for(int i=0;i<res.size();i++) {
		if(res[i] != 0) {
			printf("%d ", i);
		}
	}

	
	return 0;

}



