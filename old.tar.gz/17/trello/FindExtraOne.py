
n = int(input())

maior = 0
menor = 0

for i in range(0,n):
	x,y = map(int, input().split())
	if x < 0:
		maior += 1
	elif x > 0:
		menor += 1

if maior <= 1 or menor <= 1:
	print("Yes")
else:
	print("No")
