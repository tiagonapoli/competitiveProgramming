#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define debug(args...) if(debug) fprintf(stderr,args)
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define frrs(i,a,b) for(int i = (a); i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

ll dp[N][25];
int v[N];
int n;
ll inf = 100000000000000LL;

/*
dp[i][k] = min(dp[j][k-1] + cost(i+1,j))
Para i+1 <= j < n

*/

ll solve(int ini, int k) {
	if(k < 0) return inf;
	if(dp[ini][k] != -1LL) return dp[ini][k];
	if(ini >= n) {
		if(k == 0) {
			return 0;
		} else return inf;
	}

	ll res = inf;
	map<int,ll> cnt;
	ll c = 0;
	for(int i=ini;i<=n-k;i++) {	
		c -= cnt[v[i]] * (cnt[v[i]]-1LL) / 2LL;
		cnt[v[i]]++;
		c += cnt[v[i]] * (cnt[v[i]]-1LL) / 2LL;
		res = min(res, c + solve(i+1,k-1));
	}
	return dp[ini][k] = res;
}

int main () {
	
	int k;

	scanf("%d %d", &n, &k);

	fr(i,n) {
		scanf("%d", &v[i]);
	}

	fr(i,n+10) {
		fr(j,k+3) {
			dp[i][j] = -1LL;
		}
	}

	cout << solve(0,k) << endl;


	return 0;

}



