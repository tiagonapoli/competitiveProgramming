#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 200100

int logg[N];
int pot2[30];
int sufix_arr[N];
int lcp[N];
pair<ii, int> r[N];
int P[32][N]; 
char s[N];
int n;
int onde[N];
string str;

void build_lcp() {
	
	lcp[0] = 9999999;
	for(int i=1;i<n;i++) {
		int a = sufix_arr[i-1];
		int b = sufix_arr[i];
		lcp[i] = 0;
		for(int j = logg[n]; j >= 0 and a < n and b < n; j--) {
			if(P[j][a] == P[j][b]) {
				lcp[i] += pot2[j];
				a += pot2[j];
				b += pot2[j];
			}
		}
	}

}

void build_sa() {

	for(int i=0;i<n;i++) {
		r[i].fi.fi = s[i];
		r[i].se = i;
		P[0][r[i].se] = r[i].fi.fi;
		if(i + 1 < n) {
			r[i].fi.se = s[i+1];
		} else r[i].fi.se = -1;
	}
	sort(r,r+n);
	for(int i=0;i<n;i++) {
		onde[r[i].se] = i;
	}

	int cnt = 0;
	for(int k=2;k <= n; k *= 2) {
		cnt++;
		ii prev_r = r[0].fi;
		r[0].fi.fi = 0;
		P[cnt][r[0].se] = 0;
		for(int i=1;i<n;i++) {
			if(r[i].fi == prev_r) {
				r[i].fi.fi =  r[i-1].fi.fi;
			} else {
				prev_r = r[i].fi;
				r[i].fi.fi = i;
			}
			P[cnt][r[i].se] = r[i].fi.fi;
		}

		for(int i=0;i<n;i++) {
			if(r[i].se + k >= n) {
				r[i].fi.se = -1;
			} else {
				r[i].fi.se = r[onde[r[i].se+k]].fi.fi;
			}
		}
		sort(r,r+n);

		for(int i=0;i<n;i++) onde[r[i].se] = i;
	}
	
	for(int i=0;i<n;i++) {
		sufix_arr[i] = r[i].se;
		onde[r[i].se] = i;
	}

	build_lcp();
}

int rmq[20][N];

int query(int a, int b) {
	if(a > b) swap(a,b);
	a++;
	prin(a);
	prin(b);
	if(b < a) return 0;
	int l = b-a+1;
	int res = 9999999;
	int j = 0;
	while(l > 0) {
		if(l & 1) {
			res = min(res, rmq[j][a]);
			a += 1 << j;
		}
		j++;
		l >>= 1;
	}
	return res;
}

int palindromo() {

	
	for(int j=n-1;j >= 0; j--) {
		rmq[0][j] = lcp[j];
		prin(j);
		prin(rmq[0][j]);
		for(int i=1;i<=logg[n-j];i++) {
			rmq[i][j] = min(rmq[i-1][j], rmq[i-1][j + pot2[i-1]]);	
			//printf("rmq[%d][%d] = %d\n", i,j, rmq[i][j]);
		}
		separa();
	}

	//even
	int res = 1;
	int sz = (n - 1)/2;
	for(int i=1;i<sz;i++) {
		int a = onde[i];
		int b = onde[n-i];
		prin(str.substr(i,n-i));
		prin(str.substr(n-i,i));
		prin(query(a,b));
		separa();
		res = max(res, 2*query(a,b));
	}

	//odd
	//printf("odd\n");
	
	for(int i=1;i+1<sz;i++) {
		
		int a = onde[i+1];
		int b = onde[n-i];
		prin(str.substr(i+1,n-i-1));
		prin(str.substr(n-i,i));
		prin(query(a,b));
		separa();
		res = max(res, 1+2*query(a,b));
	}

	return res;
}

int main () {

	logg[1] = 0;
	for(int i=2;i<N;i++) {
		logg[i] = logg[i/2] + 1;
	}
	pot2[0] = 1;
	for(int i=1;i<22;i++) {
		pot2[i] = pot2[i-1] * 2;
	}

	scanf("%d", &n);
	scanf(" %s", s);

	s[n] = '#';
	for(int i=n+1;i<2*n+1;i++) {
		s[i] = s[2*n-i];
	}
	s[2*n+1] = '\0';

	n = 2*n+1;

	build_sa();
/*
	str = string(s);
	for(int i=0;i<n;i++) {
		int x = sufix_arr[i];
		cout << str.substr(x,str.size()-x) << " " << lcp[i] << endl;
	}
*/
	cout << palindromo() << endl;

	return 0;

}



