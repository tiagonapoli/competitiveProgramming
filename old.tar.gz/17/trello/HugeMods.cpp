#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

pii cycle(int b, int m) {
	map<int,int> repete;	
	b %= m;
	int c = 1;
	int now = b;
	while(repete.find(now) == repete.end()) {
		repete[now] = c;
		now *= b;
		now %= m;
		c++;
	}
	return {repete[now]-1, c - repete[now]};
}

int fastp(int b, int e, pii g) {
	int r = 1;
	if(b == 1) return 1;
	
	int cnt = 0;
	while(cnt < e and r <= g.fi) {
		r *= b;
		cnt++;
	}

	if(r > g.fi) {
		r = 1;
		b %= g.se;
		while(e > 0) {
			if(e & 1) {
				r *= b;
				r %= g.se;
			}
			b *= b;
			b %= g.se;
			e >>= 1;
		}
	} else return r;

	int ret = (r - (g.fi % g.se) + 2*g.se) % g.se;
	if(ret == 0) ret = g.se;
	return g.fi + ret;
}

int v[20];
int go(int i, int b, pii g) {
	if(debug) printf("%d (%d,%d)\n\n", b, g.fi, g.se);
	if (i == 0) return fastp(b,1,g);
	pii c = cycle(b, g.se);
	i--;
	int e = go(i, v[i], c); 
	if(debug) printf("%d (%d,%d)  e= %d\n", b, g.fi, g.se, e);
	return fastp(b,e,g);
}

int main () {
	
	int m,n;
	char l[10];

	int test = 1;
	scanf(" %s", l);
	while(l[0] != '#') {
	
		sscanf(l, "%d", &m);
		scanf("%d", &n);
		for(int i=0;i<n;i++) {
			scanf("%d", &v[n-i-1]);
		}
		
		int res = go(n-1,v[n-1], {0,m}) % m;
		printf("Case #%d: %d\n", test++, res);
		scanf(" %s", l);
		//if(l[0] != '#') printf("\n");
	}


	return 0;

}



