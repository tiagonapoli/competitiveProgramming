#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

int tem[26][N];
string s;

bool check(int l, int k) {
	for(int i=1;i+k-1<=s.size();i++) {
		if(tem[l][i+k-1] - tem[l][i-1] == 0) return 0;
	}
	return 1;
}

int bs(int l) {
	int fim = s.size()+1;
	int ini = 1;
	while(fim > ini) {
		int md = (fim + ini)/2;
		if(check(l,md)) {
			fim = md;
		} else ini = md+1;
	}
	return fim;
}

int main () {

	cin >> s;

	for(int i=0;i<26;i++) {	
		for(int j=1;j<=s.size();j++) {
			tem[i][j] = tem[i][j-1];
			if(s[j-1] == (i + 'a')) {
				tem[i][j]++;
			}
		}
	}

	int res = s.size();
	for(int i=0;i<26;i++) {
		prin(i);
		prin(bs(i));
		separa();
		res = min(res, bs(i));
	}

	cout << res << endl;

	return 0;

}



