#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

//weigth -> max number o edges
map<int,int> seti[N];

void add(int node, int w, int val) {
	if(debug) printf("Add [%d] -> %d/%d\n", node, w, val);
	auto it = seti[node].lower_bound(w);
	if(it == seti[node].begin() or (--it)->se < val) {
		seti[node][w] = max(seti[node][w], val);
	}
	it = seti[node].lower_bound(w+1);
	while(it != seti[node].end() and it->se <= val) {
		it = seti[node].erase(it);
	}
}

int get(int node, int w) {
	auto it = seti[node].lower_bound(w);
	it--;
	if(debug) printf("get %d %d -> %d/%d\n", node, w, it->fi, it->se);
	return it->se + 1;
}

int main () {
	
	int n,m;

	scanf("%d %d", &n, &m);
	
	for(int i=1;i<=n;i++) seti[i][-999] = 0;
	

	int a,b,c;
	for(int i=0;i<m;i++) {
		scanf("%d %d %d", &a, &b, &c);
		add(b, c, get(a, c));
	}

	if(debug) {
		for(int i=1;i<=n;i++) {
			printf("%d:\n", i);
			for(pii j : seti[i]) {
				printf("w[%d] = %d\n", j.fi, j.se);
			}
			printf("\n");
		}
	}

	int res = 0;
	for(int i=1;i<=n;i++) {
		auto it = seti[i].rbegin();
		res = max(res, it->se);
	}

	cout << res << endl;


	return 0;

}



