#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define debug(args...) if(debug) fprintf(stderr,args)
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define frrs(i,a,b) for(int i = (a); i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 3110

int n,q,m;
int p[N][13];
int h[N];
vector<int> adj[N];
int fim[N],ini[N];
int cnt = 1;
int dfs(int u, int f, int alt,int poison) {
	ini[u] = cnt++;
	if(poison) {
		p[u][0] = -1;
	} else p[u][0] = f;
//	prin(u);
//	prin(f);
//	prin(alt);
	h[u] = alt;
	//cout << endl;
	int aux = 99999;
	for(int v : adj[u]) {
		if(ini[v] == 0) {
			aux = min(aux,dfs(v,u,alt+1,poison));	
		} else if(fim[v] == 0){ 
			aux = min(ini[v],aux); 
		}
		if(aux != 99999) poison = 1;
	
	}
//	prin(u);
//	prin(poison);
//	cout << endl;
	fim[u] = cnt++;
	if(aux == ini[u]) return 99999;
	return aux;
}

int busca(int now, int alt) {
//	prin(now);
//	prin(alt);
	if(p[now][0] == -1) return -1;
	if(alt > h[now]) return -1;
	int sobe = h[now] - alt;
	int j = 0;
//	prin(sobe);
	while(sobe > 0) {
		if(sobe % 2) {
			now = p[now][j];		
		}
//		prin(1 << j);
//		prin(now);
		j++;
		sobe /= 2;
	}
	return now;
}

void clean() {
	cnt = 1;
	for(int i=1;i<=n;i++) {
		fim[i] = ini[i] =  0;
		for(int j=0;j<=12;j++) p[i][j] = -1;
	}
}

void pre() {
	for(int k=1;k<=12;k++) {
		for(int j=1;j<=n;j++) {
			if(p[j][0] == -1) continue;
			p[j][k] = p[p[j][k-1]][k-1];
		}
	}
}


vector<pair<ii,int> > qu[400100];

int main () {
	
	int a,b,c;
	scanf("%d %d %d", &n, &m, &q);

	int u,v;

	for(int i=0;i<m;i++) {
		scanf("%d %d", &u, &v);
		adj[u].pb(v);
	}

	for(int i=1;i<=n;i++) sort(adj[i].begin(), adj[i].end());

	int res[400100];
	for(int i=0;i<q;i++) {
		scanf("%d %d %d", &a, &b, &c);
		qu[a].pb({{b,c},i});
	}

	for(int i=1;i<=n;i++) {
		clean();
		dfs(i,i,1,0);
		pre();
		for(pair<ii,int> x : qu[i]) {
			res[x.se] = busca(x.fi.fi, x.fi.se);
		}
	}

	for(int i=0;i<q;i++) {
		printf("%d\n", res[i]);
	}
	

	return 0;

}



