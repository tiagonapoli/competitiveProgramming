#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 200100

int n;
ll v[N];
vector<int> adj[N];
ll total[N], down[N];
int sz[N];

void dfs1(int x, int pai) {
	sz[x] = 1;
	for(int y : adj[x]) {
		if(y != pai) {
			dfs1(y,x);
			down[x] += -down[y];
			down[x] %= MOD;
			sz[x] += sz[y];
		}
	}

	down[x] += (v[x] * sz[x]) % MOD;
	down[x] %= MOD;
	down[x] += 2*MOD;
	down[x] %= MOD;
}

void dfs2(int x, int pai) {
	total[x] = down[x];
	if(pai != 0) total[x] = down[x] + v[x]*(n-sz[x]) - (total[pai] + down[x] - (sz[x] * v[pai]));
	total[x] %= MOD;
	total[x] += 2*MOD;
	total[x] %= MOD;
	for(int y : adj[x]) {
		if(y != pai) dfs2(y,x);
	}
}

int main () {
	
	scanf("%d", &n);

	for(int i=1;i<=n;i++) {
		scanf("%lld", &v[i]);
	}

	int a,b;
	for(int i=0;i<n-1;i++) {
		scanf("%d %d", &a, &b);
		adj[a].pb(b);
		adj[b].pb(a);
	}
	
	dfs1(1,0);
	dfs2(1,0);

	ll res = 0;
	for(int i=0;i<=n;i++) {
		res += total[i];
		res %= MOD;	
	}

	printf("%lld\n", res);

	return 0;

}



