#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000009;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

inline ll normalize(ll x) {
	if(abs(x) >= MOD) x %= MOD;
	if(x < 0) x = ((x % MOD) + MOD) % MOD;
	return x;
}

inline ll mul(ll a, ll b) {
	a = normalize(a);
	b = normalize(b);
	return normalize(a*b);
}

inline ll add(ll a, ll b) {
	return normalize(a + b);
}

ll fpow(ll b, ll e) {
	ll res = 1;
	while(e > 0) {
		if(e & 1LL) {
			res *= b;
			res %= MOD;
		}
		b *= b;
		b %= MOD;
		e >>= 1;
	}
	return res;
}

inline ll inverse(ll x) {
	return fpow(x,MOD-2);
}

ll v[N];

int main () {

	ll n,a,b,k;

	cin >> n >> a >> b >> k;
	char c;
	for(int i=0;i<k;i++) {
		v[i] = 1;
		scanf(" %c" ,&c);
		if(c == '-') v[i] = -1LL; 
	}

	ll x = 0;
	for(int i=0;i<k;i++) {
		x = add(x, mul(v[i], mul(fpow(a,n-i),fpow(b,i))));
	}

	ll q = fpow(mul(b,inverse(a)),k);
	ll qtd = (n+1)/k;
	prin(q);
	ll res; 
	if(q == 1) {
		res = mul(x, qtd);
	} else res = mul(mul(x, add(fpow(q,qtd),-1LL)), inverse(add(q,-1LL)));

	cout << res << endl;

	return 0;

}



