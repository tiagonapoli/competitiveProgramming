#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 500

//DINIC
const int MAXN = 500; 	//number of vertices
const int INF = 1000000000; //infinity
 
struct edge {
	int a, b, cap, flow;
};
 
int sz, s, t, d[MAXN], ptr[MAXN], q[MAXN];
vector<edge> e;
vector<int> g[MAXN];
 
void add_edge (int a, int b, int cap) {
	edge e1 = { a, b, cap, 0 };
	edge e2 = { b, a, 0, 0 };
	g[a].push_back ((int) e.size());
	e.push_back (e1);
	g[b].push_back ((int) e.size());
	e.push_back (e2);
}
 
bool bfs() {
	int qh=0, qt=0;
	q[qt++] = s;
	memset (d, -1, sz * sizeof d[0]);
	d[s] = 0;
	while (qh < qt && d[t] == -1) {
		int v = q[qh++];
		for (size_t i=0; i<g[v].size(); ++i) {
			int id = g[v][i],
				to = e[id].b;
			if (d[to] == -1 && e[id].flow < e[id].cap) {
				q[qt++] = to;
				d[to] = d[v] + 1;
			}
		}
	}
	return d[t] != -1;
}
 
int dfs (int v, int flow) {
	if (!flow)  return 0;
	if (v == t)  return flow;
	for (; ptr[v]<(int)g[v].size(); ++ptr[v]) {
		int id = g[v][ptr[v]],
			to = e[id].b;
		if (d[to] != d[v] + 1)  continue;
		int pushed = dfs (to, min (flow, e[id].cap - e[id].flow));
		if (pushed) {
			e[id].flow += pushed;
			e[id^1].flow -= pushed;
			return pushed;
		}
	}
	return 0;
}
 
int dinic() {
	int flow = 0;
	for (;;) {
		if (!bfs())  break;
		memset (ptr, 0, sz * sizeof ptr[0]);
		while (int pushed = dfs (s, INF))
			flow += pushed;
	}
	return flow;
}

////

set<int> prime;
bool aux[30000];
void sieve() {
	for(int i=2;i<30000;i++) {
		if(aux[i] == 0) {
			prime.insert(i);
			for(int j=i;j<30000;j+=i) {
				aux[j] = 1;
			}
		}
	}
}

vector<int> res[N];
vector<ii> odd,even;
bool vis[N];
int cnt;
vector<int> adj[N];
vector<int> gr[N];
void dfs(int x) {
	vis[x] = 1;
	prin(x);
	res[cnt].pb(x);
	for(int p : gr[x]) {
		if(vis[p] == 0) {
			dfs(p);
		}
	}
}


int main () {

	int n;
	
	

	sieve();
	cin >> n;

	int x;
	for(int i=0;i<n;i++) {
		cin >> x;
		if(x % 2 == 0) {
			even.pb({x,i+1});
		} else odd.pb({x,i+1});
	}

	/*
		why does have to happen that #even = #odd?
			For each cycle we will make a chain:
				even - odd - even - odd ... -  odd
			So for every cycle, we have pairs of unique (in index) evens and odds
			So it must hold that #even = #odd
	   */
	if(even.size() != odd.size()) {
		cout << "Impossible" << endl;
		return 0;
	}

	/* Now for every odd, it have to match with exactly 2 evens, that will be its neighbors */
	
	s = 0;
	t = n+2;
	sz = n + 20;
	for(ii j : odd) {
		add_edge(s,j.se,2);
	}

	for(ii j : even) {
		add_edge(j.se,t,2);
	}

	for(ii i : odd) {
		for(ii j : even) {
			if(prime.find(i.fi + j.fi) != prime.end()) {
				adj[i.se].pb(e.size());
				add_edge(i.se,j.se,1);
			}
		}
	}

	int aux = dinic();
	if(aux != 2 * even.size()) {
		cout << "Impossible" << endl;
		if(n == 200) printf("%d\n", aux);
		return 0;
	}

	for(ii i : odd) {
		for(int p : adj[i.se]) {
			if(e[p].flow == 1) {
				gr[i.se].pb(e[p].b);
				gr[e[p].b].pb(i.se);
			}
		}
	}

	for(ii i : odd) {
		if(vis[i.se] == 0) {
			cnt++;
			dfs(i.se);
			separa();
		}
	}

	cout << cnt << endl;
	for(int i=1;i<=cnt;i++) {
		printf("%d ",(int) res[i].size());
		for(int j : res[i]) {
			printf("%d ", j);
		}
		cout << endl;
	}
	cout << endl;
	

	

	return 0;

}
