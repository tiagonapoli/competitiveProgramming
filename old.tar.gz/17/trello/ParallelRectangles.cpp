#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

int S = 270;
vector<int> muitosy;
vector<int> poucosy;
set<int> pt[N];
map<int,int> y1y2[N];

int main () {
	
	int n;

	scanf("%d", &n);

	int a,b;

    int maxi = 0;
	for(int i=0;i<n;i++) {
		scanf("%d %d", &a, &b);
	    maxi = max(maxi,a);
		pt[a].insert(b);
	}

	for(int it = 1; it <= maxi; it++) {
		if(pt[it].empty()) continue;
		if(pt[it].size() <= S) {
			poucosy.pb(it);
		} else muitosy.pb(it);
	}

	ll res = 0;

	for(int x1 : poucosy) {
		for(auto i = pt[x1].begin(); i != pt[x1].end(); i++) {
		    auto j = i;
		    j++;
			for(;j != pt[x1].end(); j++) {
				y1y2[*i][*j]++;	
			}
		}
	}
	int sz = 0;


	for(int i=1;i<=100000;i++) {
        if(y1y2[i].size() == 0) continue;
		for(auto it = y1y2[i].begin(); it != y1y2[i].end(); it++) {
			res += it->se * (it->se - 1LL)/2LL;
		}
	}

	for(int x1 : poucosy) {
		for(int x2 : muitosy) {
			ll cnt = 0;
			for(int y : pt[x1]) {
				if(pt[x2].find(y) != pt[x2].end()) {
					cnt++;		
				}
			}
			res += cnt*(cnt-1LL)/2LL;
		}
	}

    int x1,x2;
	for(int i=0;i<muitosy.size(); i++) {
		for(int j=i+1;j<muitosy.size();j++) {
		    x1 = muitosy[i];
		    x2 = muitosy[j];
			ll cnt = 0;
			for(int y : pt[x1]) {
				if(pt[x2].find(y) != pt[x2].end()) {
					cnt++;		
				}
			}
			res += cnt*(cnt-1LL)/2LL;
		}
	}
	
	cout << res << endl;

	return 0;

}





