#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

ll sz[N];
vector<int> adj[N];
bool vis[N];

int dfs1(int now) {
	sz[now] = 1;
	vis[now] = 1;
	int last;
	for(int x : adj[now]) {
		if(vis[x] == 0) {
			last = dfs1(x);
			sz[now] += sz[x];
		} else return now;
	}
	return last;
}



int main () {
	
	int n;

	cin >> n;
	
	int x;
	for(int i=1;i<=n;i++) {
		cin >> x;
		adj[i].pb(x);
	}

	vector<ll> res;
	for(int i=1;i<=n;i++) {
		if(vis[i] == 0) {
			int last = dfs1(i);	
			res.pb(sz[adj[last][0]]);
		}
	}

	sort(res.begin(), res.end(), greater<ll>());
	ll aux = 0;
	
	if(res.size() == 1) {
		aux = res[0];
		aux *= aux;
	} else {
		aux = res[0] + res[1];
		aux *= aux;
		for(int i=2;i<res.size();i++) {
		 	ll x = res[i];
			aux += x*x;
		}
	}

	cout << aux << endl;

	return 0;

}



