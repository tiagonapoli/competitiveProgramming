#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 200100

int n;
int v[N];

int main () {

	cin >> n;
	int x;
	for(int i=0;i<N;i++) {
		v[i] = 100000000;
	}

	for(int i=0;i<n;i++) {
		cin >> x;
		v[x] = i;
	}
	int min = 10000000;
	int id;

	for(int i=0;i<N;i++) {
		if(v[i] < min) {
			min = v[i];
			id = i;
		}
	}

	cout << id << endl;


	return 0;

}



