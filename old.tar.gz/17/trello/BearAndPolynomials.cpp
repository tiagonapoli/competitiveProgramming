#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 200100

ll v[N];
int acum[N];
int pos[N][2];
int n;
int sz;
ll k;
bool analise(ll x, int i) {
	//printf("%lld %d\n\n", x,i);
	if(x == 0 and i == sz+1) return 0;
	return abs(x) <= k;
}

int main () {

	scanf("%d %lld", &n, &k);
	sz = n;

	for(int i=1;i<=n+1;i++) {
		scanf("%lld", &v[i]);
	}
	
	n += 50;
	int m = 0;
	for(int i=1;i<=n+1;i++) {
		if(v[i] < 0) {
			pos[i][1] = -v[i];
		} else {
			pos[i][0] = v[i];
		}
	}

	for(int i=1;i<=n-1;i++) {
		pos[i+1][0] += pos[i][0]/2;
		pos[i][0] %= 2;
		pos[i+1][1] += pos[i][1]/2;
		pos[i][1] %= 2;
	}

	for(int i=n;i>=1;i--) {
		if(pos[i][0] == pos[i][1]) continue;
		if(pos[i][0] < pos[i][1]) {
			m = 1;
			break;
		} else {
			m = 0;
			break;
		}
	}

	prin(m);
	for(int i=1;i<=20;i++) {
		//printf("%d ", pos[i][0]);
	}
	separa();
	for(int i=1;i<=20;i++) {
		//printf("%d ", pos[i][1]);
	}
	separa();

	for(int i=1;i<=n;i++) {
		if(pos[i][m] < pos[i][m^1]) {
			for(int j=i;j<=n;j++) {
				if(pos[j][m] != 0) {
					pos[j][m] = 0;
					break;
				} else pos[j][m] = 1;
			}
		} else pos[i][m] -= pos[i][m^1];
	}


	for(int i=1;i<=20;i++) {
		//printf("%d ", pos[i][m]);
	}
	separa();

	int a,b;
	a = 9999999;
	b = -1;

	for(int i=1;i<=n;i++) {
		if(pos[i][m] != 0) {
			a = min(a,i);
			b = max(b,i);
		}
	}

	if(b - a >= 30) {
		cout << 0 << endl;
		return 0;
	}

	a = max(b - 30, 1);
	prin(a);
	prin(b);

	ll x = 0;
	for(int i=b;i>=a;i--) {
		x *= 2;
		x += pos[i][m];
	}

	prin(x);
	int res = 0;
	for(int i=a;i<=min(b,sz+1);i++) {
		//printf("v[%d] = %lld\n", i,v[i]);
		if(m == 0) {
			if(analise(v[i] - x,i)) res++;
	 	} else if(analise(v[i] + x,i)) res++;
		if(x % 2 == 1) break;
		x /= 2;
	}

	

	cout << res << endl;



	return 0;

}



