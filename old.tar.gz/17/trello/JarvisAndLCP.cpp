#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 700000

int lcp[N], suf_arr[N];
int logg[N], pot[30];
int onde[N];
int P[32][N];
pair<ii, int> r[N];
string s;
int pos[N], rmq[30][N], rmqi[30][N];
string v[N];
int sz;

void pre() {
	logg[1] = 0;
	for(int i=2;i<N;i++) logg[i] = logg[i/2] + 1;
	pot[0] = 1;
	for(int i=1;i<30;i++) pot[i] = pot[i-1] * 2;
}

void build_lcp() {
	lcp[0] = -1;
	for(int i=1;i<sz;i++) {
		int a,b;
		a = suf_arr[i];
		b = suf_arr[i-1];
		lcp[i] = 0;
		for(int j=logg[sz]; j >= 0 and a < sz and b < sz; j--) {
			if(P[j][a] == P[j][b]) {
				lcp[i] += pot[j];
				a += pot[j];
				b += pot[j];
			}
		}
	}
}

void build_suf() {
	for(int i=0;i<sz;i++){
		r[i].fi.fi = s[i];
		r[i].se = i;
		if(i != sz-1) r[i].fi.se = s[i+1];
		P[0][r[i].se] = r[i].fi.fi;
	}
	sort(r,r+sz);
	for(int i=0;i<sz;i++) onde[r[i].se] = i;

	int cnt = 0;
	for(int k=2;k<=sz;k*=2) {
		cnt++;
		ii prev_r = r[0].fi;
		r[0].fi.fi = P[cnt][r[0].se] = 0;
		for(int i=1;i<sz;i++) {
			if(r[i].fi == prev_r) {
				r[i].fi.fi = r[i-1].fi.fi;
			} else {
				prev_r = r[i].fi;
				r[i].fi.fi = i;
			}
			P[cnt][r[i].se] = r[i].fi.fi;
		}
		for(int i=0;i<sz;i++) {
			if(r[i].se + k < sz) {
				r[i].fi.se = r[onde[r[i].se + k]].fi.fi;
			} else r[i].fi.se = -1;
		}
		sort(r,r+sz);
		for(int i=0;i<sz;i++) onde[r[i].se] = i;
	}

	for(int i=0;i<sz;i++) suf_arr[i] = r[i].se;
	build_lcp();

}

int query(int a, int b) {
	int l = b-a + 1;
	int res = 9999999;
	int j = 0;
	while(l > 0) {
		if(l & 1) {
			res = min(res, rmq[j][a]);
			a += 1 << j;
		}
		j++;
		l /= 2;
	}
	return res;
}

int bs(int a, int b) {
	int x;
	if(a == b) {
		x = v[a].size();
		a = onde[pos[a]];
		b = onde[pos[b]];
	} else {
		a = onde[pos[a]];
		b = onde[pos[b]];
		if(a > b) swap(a,b);
		x = query(a+1,b);
	}
	if(x == 0) return 0;

	prin(a);
	prin(b);
	prin(x);

	int ini,fim;
	ini = fim = a;
	for(int j=logg[sz-fim];j>=0;j--) {
	///	printf("rmq[%d][%d] = %d\n", j,fim,rmq[j][fim]);
		if(rmq[j][fim] >= x) {
			fim += pot[j];	
		}
	}
	for(int j=logg[ini+1];j >= 0; j--){
	//	printf("rmqi[%d][%d] = %d\n", j,ini,rmqi[j][ini]);
		if(rmqi[j][ini] >= x) {
			ini -= pot[j];
		}
	}
	prin(ini);
	prin(fim);
	separa();
	return fim - ini;

}

int main () {

	pre();
	int n;
	scanf("%d", &n);
	

	for(int i=0;i<n;i++) {
		cin >> v[i];
		pos[i] = s.size();
		s += v[i];
		if(i != n-1) s += '$';
	}
	sz = s.size();
	
	build_suf();
/*
	for(int i=0;i<sz;i++) {
		int aux = suf_arr[i];
		cout << i << " ";
		cout << s.substr(aux,s.size()-aux) << " " << lcp[i] << endl;
	}
	cout << endl;
*/	
	
	for(int i=sz-1; i>=0; i--) {
		rmq[0][i] = lcp[i];
		for(int j=1;j <= logg[sz-i]; j++) {
			rmq[j][i] = min(rmq[j-1][i], rmq[j-1][i+pot[j-1]]);
		}
	}
	for(int i=0;i<sz;i++) {
		rmqi[0][i] = lcp[i];
		for(int j=1; j <= logg[i+1]; j++) {
			rmqi[j][i] = min(rmqi[j-1][i], rmqi[j-1][i - pot[j-1]]);	
		}
	}

	int q;

	scanf("%d", &q);

	int a,b;
	while(q--) {
		scanf("%d %d", &a, &b);
		a--;
		b--;
		cout << bs(a,b) << endl;
	}

	return 0;

}



