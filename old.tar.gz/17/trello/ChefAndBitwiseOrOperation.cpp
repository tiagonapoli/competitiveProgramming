#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define debug(args...) if(debug) fprintf(stderr,args)
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define frrs(i,a,b) for(int i = (a); i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 5100

ll c[N][N];
ll dp[N][N];
ll v[N];
ll A[N][N];
int n;

void pre() {
	for(int i=1;i<=n;i++) {
		ll res = 0;
		for(int j=i;j<=n;j++) {
			res |= v[j];
			c[i][j] = res;
		}
	}
}

void fill(int g, int a, int b, int ka, int kb) {
	if(b < a or a <= 0 or b > n) return;
	if(g == 1) {
		for(int i=a;i<=b;i++) {
			dp[g][i] = c[1][i];
		}
		return;
	}
	int mid = (a + b)/2;
	dp[g][mid] = 0;
	ll aux;
	A[g][mid] = ka;
	int ate = min(mid-1,kb);
	for(int i=ka;i<=ate;i++) {
		aux = dp[g-1][i] + c[i+1][mid];
		if(dp[g][mid] < aux) {
			A[g][mid] = i;
			dp[g][mid] = aux;
		}
	}
	//mid ja foi preenchido
	fill(g,a,mid-1,ka,A[g][mid]);
	fill(g,mid+1,b,A[g][mid],kb);
}

int main () {

	int t;
	scanf("%d", &t);

	int k;
	while(t--) {
		scanf("%d %d", &n, &k);
			
		for(int i=1;i<=n;i++) {
			scanf("%lld", &v[i]);
		}
		pre();


		for(int i=1;i<=k;i++) {
			fill(i,1,n,1,n);
		}

		cout << dp[k][n] << endl;
	}

	return 0;

}



