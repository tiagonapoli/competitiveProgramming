

def main():

	n,m = map(int, input().split())

	s = input()
	s = list(s)
	for i in range(0,m):
		l,r,c1,c2 = input().split(' ')
		l = int(l)
		r = int(r)
		l -= 1
		r -= 1

		for j in range(l,r+1):
			if s[j] == c1:
				s[j] = c2

	s = ''.join(str(l) for l in s)	
	print(s)
	





main()
