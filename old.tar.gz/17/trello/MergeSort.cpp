#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define debug(args...) if(debug) fprintf(stderr,args)
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) cout << (a) << " -> " << (b) << endl;
#define separa() if(debug) cout << endl;
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define frrs(i,a,b) for(int i = (a); i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

int v[N];
bool sol(int l, int r, int a, int b, int k) {
	prin(k);
	rang(l,r);
	separa();
	if(l >= r) return 0;
	if(k <= 0) return 0;
	if(k == 1) {
		for(int i=l;i<r;i++) {
			v[i] = a;
			a++;
		}
		return 1;
	}
	if(r-l == 1) return 0;

	k-=3;
	int k1,k2;
	
	int x,y;
	int mid = (l+r)/2;
	int midx = (a+b)/2;
	
	if(midx - a < r - mid) {
		midx++;
	} else if(midx - a > r - mid) midx--;
	
	k1 = k/2;
	k2 = k-k1;
	k1++;
	k2++;
	if(k1 % 2 == 0) {
		k1--;
		k2++;
	}
	x = sol(l,mid,midx,b,k1);
	y = sol(mid,r,a,midx,k2);
	
	if(x and y) return 1;
	return 0;
	
}

int main () {

	int n,k;

	cin >> n >> k;

	
	if(sol(0,n,0,n,k) == 0) {
		cout << -1 << endl;
		return 0;
	}
	
	for(int i=0;i<n;i++) {
		printf("%d ", v[i]+1);
	}
	cout << endl;

	return 0;

}



