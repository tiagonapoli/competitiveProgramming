#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 10100

ll cut[2][N];
ll c;
ll p[N], s[N];
//Cut[i][j] -> ate o i-esimo vertice, o conjunto A do corte tem exatamente j caras
//cut[i][j] = min{cut[i-1][j] + pi + j * c, cut[i-1][j-1] + si} 
int n;

ll dp() {

	ll inf = 999999999999999LL;

	for(int now = 1; now <= n; now++) {
		cut[now%2][0] = cut[(now+1)%2][0] + p[now]; 
		for(int qtd=1;qtd <= n; qtd++) {
			cut[now%2][qtd] = min(cut[(now+1)%2][qtd] + p[now] + qtd * c, cut[(now+1)%2][qtd-1] + s[now]);
		}
	}


	ll res = inf;
	for(int qtd = 0; qtd <= n; qtd++) {
		res = min(res, cut[n%2][qtd]);
	}
	return res;
}


int main () {
	
	cin >> n >> c;

	for(int i=1;i<=n;i++) {
		cin >> p[i];
	}

	for(int i=1;i<=n;i++) {
		cin >> s[i];
	}
	
	cout << dp() << endl;


	return 0;

}



