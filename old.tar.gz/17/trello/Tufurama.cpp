#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 200100

vector<pii> sorted;
int v[N];
int bit[N];
int n;

int sum(int id) {
	int res = 0;
	while(id > 0) {
		res += bit[id];
		id -= id & -id;
	}
	return res;
}

void upd(int id, int x) {
	while(id < N) {
		bit[id] += x;
		id += id & -id;
	}
}

int query(int a, int b) {
	if(b < a) return 0;
	return sum(b) - sum(a-1);
}

int main () {

	scanf("%d", &n);

	for(int i=1;i<=n;i++) {
		scanf("%d", &v[i]);
		sorted.pb({v[i],i});
		upd(i,1);
	}
	
	sort(sorted.begin(), sorted.end(), greater<pii>());
	
	ll res = 0;
	for(int i=1;i<=n;i++) {
		
		while(sorted.size() > 0 and sorted.back().fi < i) {
			upd(sorted.back().se, -1);
			sorted.pop_back();
		}
		res += query(i+1,min(v[i],n));
	}
	
	cout << res << endl;


	return 0;

}



