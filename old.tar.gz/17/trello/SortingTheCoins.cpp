#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 300100

int pai[N];
int sz[N];

int find(int x) {
	if(pai[x] == x) return x;
	return pai[x] = find(pai[x]);
}

void join(int a, int b) {
	a = find(a);
	b = find(b);
	if(a != b) {
		pai[b] = a;
		sz[a] += sz[b];
	}
}

int v[N];
int main () {
	
	int n;
	scanf("%d", &n);

	pai[n+1] = n+1;
	v[n+1] = 1;

	int res = 0;
	int x;
	printf("%d ", 1);
	for(int i=0;i<n;i++) {
		scanf("%d", &x);
		v[x] = 1;
		pai[x] = x;
		sz[x] = 1;
		if(v[x+1] == 1) {
			join(x,x+1);
		} 
		if(v[x-1] == 1) {
			join(x,x-1);
		}

		printf("%d ", i+2-sz[find(n+1)]);
	}
	cout << endl;
	

	return 0;

}



