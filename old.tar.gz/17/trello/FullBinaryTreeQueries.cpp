#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100
#define BITS 64
ll v[70];

int logg(ll x) {
	return 63 - __builtin_clzll(x);
}

ll foo(int l, ll k) {
	if(k < 0) k += (abs(k)/(1LL<<l) + 1) * (1LL<<l);
	k %= (1LL << l);
	return k;
}

void shift1(int l, ll k) {
	v[l] += k;
	v[l] = foo(l, v[l]);
}

void shift2(int l, ll k) {
	for(int i=0;i+l<BITS;i++) {
		k = foo(i+l, k);
		prin(i+l);
		prin(k);
		prin(v[i+l]);
		v[i+l] += k;
		v[i+l] = foo(i+l,v[i+l]);
		prin(v[i+l]);
		separa();
		k *= 2LL;
	}
}

void print(int l, ll pos) {
	if(l == -1) {
		printf("\n");
		return;
	}

	printf("%lld ", (1LL<<l) + foo(l, pos + (1LL<<l)-v[l]));

	print(l-1,pos/2);
}


int main () {

	int q;

	scanf("%d", &q);
	prin(q);
	prin(logg(q));

	ll a,b,c;
	for(int i=0;i<q;i++) {
		scanf("%lld %lld", &a, &b);
		prin(logg(b));
		if(a == 1) {
			scanf("%lld", &c);
			shift1(logg(b),c);
		} else if(a == 2) {
			scanf("%lld", &c);
			shift2(logg(b),c);
		} else {
			int aux = logg(b);
			print(aux, foo(aux, b+v[aux]));
		}
	}



	return 0;

}



