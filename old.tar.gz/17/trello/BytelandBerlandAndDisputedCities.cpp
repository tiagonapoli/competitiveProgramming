#include "bits/stdc++.h"
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

vector<ll> pA;
vector<ll> pB;
vector<ll> pC;

bool check(int x, vector<ll> &p, ll a, ll b) {
	return (x >= 0) and (x < p.size()) and (p[x] >= a) and (p[x] <= b);
}

ll sol1(ll a, ll b, vector<ll> &p) {
	int fi = lower_bound(p.begin(), p.end(), a) - p.begin();
	if(check(fi,p,a,b)) return b-a;
	return 0;
}

ll sol2(ll a, ll b, vector<ll> &p) {
	ll maxi = 0;
	int fi = lower_bound(p.begin(), p.end(), a) - p.begin();
	int la = lower_bound(p.begin(), p.end(), b) - p.begin();
	la--;
	if(check(fi,p,a,b)) maxi = max(maxi, p[fi]-a);
	if(check(la,p,a,b)) maxi = max(maxi, b-p[la]); 
	for(int i=fi+1;i <= la; i++) {
		maxi = max(maxi, p[i] - p[i-1]);
	}
	return b-a-maxi;
}

ll sol(ll a, ll b) {

	int fi1 = lower_bound(pA.begin(), pA.end(),a) - pA.begin();
	int fi2 = lower_bound(pB.begin(), pB.end(),a) - pB.begin();
	
	if(check(fi1,pA,a,b) and check(fi2,pB,a,b)) {
		ll r1 = sol1(a,b,pA) + sol1(a,b,pB);
		ll r2 = b-a + sol2(a,b,pA) + sol2(a,b,pB);
		return min(r1,r2);

	} else if(check(fi1,pA,a,b)) {
		return b-a + sol2(a,b,pA);
	
	} else if(check(fi2,pB,a,b)) {
		return b-a + sol2(a,b,pB);
	
	} else return b-a;
}

ll init(vector<ll> &px) {
	ll res = 0;
	if(px.size() > 0 and pC.size() > 0) {
		if(pC[0] > px[0]) res += pC[0] - px[0];
		if(pC.back() < px.back()) res += px.back() - pC.back();
	}

	if(pC.size() == 0 and px.size() > 0) return px.back() - px[0];
	return res;
}


int main () {

	int n;

	scanf("%d", &n);
	
	int a;
	char b;
	for(int i=0;i<n;i++){
		scanf("%d %c", &a, &b);
		if(b == 'R') {
			pA.pb(a);
		} else if(b == 'P') {
			pC.pb(a);
		} else pB.pb(a);
	}

	ll res = init(pA) + init(pB);
	for(int i=1;i<pC.size();i++) {
		res += sol(pC[i-1], pC[i]);
	}

	cout << res << endl;

	return 0;

}



