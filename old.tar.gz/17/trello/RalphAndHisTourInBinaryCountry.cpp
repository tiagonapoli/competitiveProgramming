#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 1001000

int n,m;

vector<ll> acum[N];
vector<ll> tree[N];
ll edge[N];
ll aux1[N];
ll aux2[N];

int build(int x) {
    
    int sz1,sz2;
    sz1 = sz2 = 0;
    tree[x].pb(0LL);
    if(2*x+1 <= n) {
        sz1 = build(2*x);
        sz2 = build(2*x+1);
        prin(x);
        for(int i=0;i<sz1;i++) {
            aux1[i] = tree[2*x][i] + edge[2*x];
        }
        for(int i=0;i<sz2;i++) {
            aux2[i] = tree[2*x+1][i] + edge[2*x+1];
        }
        tree[x].resize(sz1 + sz2 + 1);
        merge(aux1, aux1+sz1, aux2, aux2+sz2, (++tree[x].begin()));
    } else if(2*x <= n) {
        sz1 = build(2*x);
        
        for(ll j : tree[2*x]) {
            tree[x].pb(j + edge[2*x]);    
        }
    }
    separa();
    return sz1 + sz2 + 1;
}

ll query(int a, ll h, ll dist, int origem) {
    if(a == 0 or h <= dist) return 0;
    ll res = 0;
    prin(a);
    if(2*a <= n && 2*a != origem && h-edge[2*a]-dist >= 0) {
        ll pos = lower_bound(tree[2*a].begin(), tree[2*a].end(), h-edge[2*a]-dist+1) - (tree[2*a].begin());
        prin(2*a);
        prin(pos-1);
		prin(pos * h);
		prin(dist * pos);
		prin(pos * edge[2*a]);
		prin(acum[2*a][pos-1]);
        res += pos * h - dist * pos - pos * edge[2*a] - acum[2*a][pos-1]; 
        prin(res);
    }  
    if(2*a + 1 <= n && 2*a+1 != origem && h-edge[2*a+1]-dist >= 0) {
        ll pos = lower_bound(tree[2*a+1].begin(), tree[2*a+1].end(), h-edge[2*a+1]-dist+1) - (tree[2*a+1].begin());
        prin(2*a+1);
        prin(pos-1);
        res += pos * h - dist * pos - (ll)pos * edge[2*a+1] - acum[2*a+1][pos-1]; 
        prin(res);
    }
	res += h - dist;
    separa();
    return res + query(a/2,h,edge[a]+dist,a);
}

int main () {

    scanf("%d %d", &n, &m); 


    for(int i=2;i<=n;i++) {
        scanf("%lld", &edge[i]);
    }
    build(1);
    
    for(int i=1;i<=n;i++) {
        acum[i].pb(0LL);
        for(int j=1;j<tree[i].size();j++) {
            acum[i].pb(tree[i][j] + acum[i][j-1]);
        }
    }
/*
    for(int i=1;i<=n;i++) {
        printf("%d: ",i);
        for(ll x : tree[i]) {
            printf("%lld ", x);
        }
        cout << endl;
    }
*/
    
	int a,b;
    for(int i=0;i<m;i++) {
        scanf("%d %d", &a, &b);
        printf("%lld\n", query(a,b,0,-1));
    }

	return 0;

}



