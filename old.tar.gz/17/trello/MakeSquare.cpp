#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

vector<int> v;
int dp[15][15]; 
string sx, sa;
char s1[15], s2[15];

int subsequence(int i, int j) {
	if(dp[i][j] != -1) return dp[i][j];
	if(i == sx.size() or j==sa.size()) return 0;
	int aux = max(subsequence(i+1,j), subsequence(i,j+1));
	if(sx[i] == sa[j]) {
		aux = max(aux, subsequence(i+1,j+1) + 1);
	}
	return dp[i][j] = aux;
}

int dist(ll x, ll a) {
	sprintf(s1, "%lld", x);
	sprintf(s2, "%lld", a);
	sx = string(s1);
	sa = string(s2);
	for(int i=0;i<15;i++) {
		for(int j=0;j<15;j++) dp[i][j] = -1;
	}

	prin(sx);
	prin(sa);
	prin(subsequence(0,0));
	separa();
	if(subsequence(0,0) == sa.size()) {
		return sx.size() - sa.size();
	}
	return 999;
}

int main () {

	ll n;
	cin >> n;
	for(int i=1;i*i<=n;i++) {
		v.pb(i*i);
	}

	int mini = 999;
	for(int i : v) {
		mini = min(mini, dist(n,i));
	}

	if(mini == 999) {
		printf("-1\n");
	} else printf("%d\n", mini);
	


	return 0;

}



