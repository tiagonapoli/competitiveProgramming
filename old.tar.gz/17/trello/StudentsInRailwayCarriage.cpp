#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 200100

int v[N];
string s;

int main () {

	int n,a,b;
	
	cin >> n >> a >> b;
	cin >> s;
	int cnt = 0;
	
	for(int i=0;i<n;i++) {
		if(s[i] == '*') {
			if(v[cnt] != 0) cnt++;
			continue;
		}
		v[cnt]++;
	}

	int tot = a+b;
	for(int i=0;i<=cnt;i++) {
		if(a < b) swap(a,b);
		a -= (v[i]+1)/2;
		b -= v[i]/2;
		a = max(0,a);
		b = max(0,b);
	}

	cout << (tot - a - b) << endl;


	return 0;

}



