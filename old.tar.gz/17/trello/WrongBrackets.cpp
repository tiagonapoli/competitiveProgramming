#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 35

ll dp[3*N][N][2];
int n;

ll sol(int q1, int q2, bool ruim) {
	if(q1 == n and q2 == n) {
		return ruim;
	} else if(q1 == n) {
		return ruim;
	} else if(q2 == n) {
		return 1;
	}
	if(dp[q1][q2][ruim] != -1LL) return dp[q1][q2][ruim];
	ll &res = dp[q1][q2][ruim];
	if(ruim == 0 and q1 == q2) {
		res = sol(q1+1,q2,0) + sol(q1,q2+1,1);
	} else res = sol(q1+1,q2,ruim) + sol(q1,q2+1,ruim);
//	printf("solve %d %d %d = %lld\n", q1,q2,ruim,res);
	return res;
}

string find(int q1, int q2, bool ruim, ll k) {
	if(q1 == n and q2 == n) {
		return "";
	} else if(q1 == n) {
		return ")" + find(q1,q2+1,ruim,k);
	} else if(q2 == n) {
		return "(" + find(q1+1,q2,ruim,k);
	}
/*	
	prin(q1);
	prin(q2);
	prin(ruim);
	prin(k);
	separa();
*/	if(ruim == 0 and q1 == q2) {
//		printf("chama sol %d %d %d\n", q1+1,q2,0);
		if(sol(q1+1,q2,0) < k) {
			return ")" + find(q1,q2+1,1,k-sol(q1+1,q2,0));
		} else return "(" + find(q1+1,q2,0,k);
	} else {
//		printf("chama sol %d %d %d\n", q1+1,q2,ruim);
		if(sol(q1+1,q2,ruim) < k) {
			return ")" + find(q1,q2+1,ruim,k-sol(q1+1,q2,ruim));
		} else return "(" + find(q1+1,q2,ruim,k);
	}

	
}

int main () {

	ll k;

	cin >> n >> k;
	
	for(int i=0;i<=n+1;i++) {
		for(int j=0;j<=n+1;j++) {
			dp[i][j][0] = dp[i][j][1] = -1LL;
		}
	}

	cout << find(0,0,0,k) << endl;

		

	return 0;

}



