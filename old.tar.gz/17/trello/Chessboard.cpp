#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
#define pll pair<ll, ll>
const ll MOD = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

int v[] = {0,1,2,3};
int n;
int t[5][110][110];


int check(int f) {
	bool now = f;
	int res = 0;
	for(int i=0;i<4;i++) {
		if(i == 2) now ^= 1;
		for(int j=0;j<n;j++) {
			for(int k=0;k<n;k++) {
				if(t[v[i]][j][k] != now) {
					res++;
				}
				now ^= 1;
			}
		}
	}
	return res;
}

int main () {

	scanf("%d", &n);
	char str[110];
	for(int i=0;i<4;i++) {
		for(int j=0;j<n;j++) {
			scanf(" %s", str);
			for(int k=0;k<n;k++) {
				t[i][j][k] = str[k] - '0';
			}
		}
	}

	int res = min(check(0), check(1));
	while(next_permutation(v,v+4)) {
		res = min(res, min(check(0), check(1)));
	}

	cout << res << endl;

	return 0;

}



