#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define debug(args...) if(debug) fprintf(stderr,args)
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define frrs(i,a,b) for(int i = (a); i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

//given an array of integers, make K groups such that the sum of their costs is minimized.
//A group cost is defined by the summation of each element multiplied by the group size.
//k<=20 N<=10^5
//Complexidade deve ser NKlogN
//Divide and Conquer Optimization

ll dp[30][N];
int A[30][N]; //optimal splitting point
ll sum[N];
int n,k;
ll inf = 10000000000LL;

ll cost(int ini, int fim) {
	if(fim < ini) return inf;
	return (sum[fim] - sum[ini-1]) * ((ll)(fim-ini+1));
}

//g - group
void fill(int g, int l, int r, int kl, int kr) {
	if(l <= 0 or r > n or l > r) return;
	prin(g);
	prin(l);
	prin(r);
	if(g == 1) {
		for(int i=l;i<=r;i++) {
			dp[g][i] = cost(l,i);
		}
		return;
	}
	int mid = (l+r)/2;
	prin(mid);
	dp[g][mid] = inf;
	ll aux;
	A[g][mid] = kl;
	for(int i=kl;i <= kr; i++) {
		aux = dp[g-1][i] + cost(i+1,mid);
		if(aux < dp[g][mid]) {
			dp[g][mid] = aux;
			A[g][mid] = i;
		}
	}
	fill(g,l,mid-1,kl,A[g][mid]);
	fill(g,mid+1,r, A[g][mid],kr);
}

int main () {
	
	cin >> n >> k;

	int v[N];
	for(int i=1;i<=n;i++) {
		cin >> v[i];
		sum[i] = sum[i-1] + v[i];
	}

	for(int i=1;i<=k;i++) {
		fill(i,1,n,1,n);
	/*	for(int j=1;j<=n;j++) {
			printf("[%d][%d] = %lld\n", i,j,dp[i][j]);
		}
		cout << endl;
	*/}
	
	cout << dp[k][n] << endl;


	return 0;

}



