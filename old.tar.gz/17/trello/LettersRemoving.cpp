#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 200100

int bit[N];
int n;
set<int> v[200];

void upd(int id,int x) {
	while(id < N) {
		bit[id] += x;
		id += id & (-id);
	}
}

int sum(int id) {
	int res = 0;
	while(id > 0) {
		res += bit[id];
		id -= id & (-id);
	}
	return res;
}

int bs(int x) {
	int i,f;
	i = 1;
	f = n+1;
	while(i < f) {
		int m = (i+f)/2;
		if(sum(m) >= x) {
			f = m;
		} else i = m+1;
	}
	return f;
}

int main () {

	int m;
	scanf("%d %d", &n, &m);
	
	string s;
	cin >> s;

	for(int i=1;i<=n;i++) {
		upd(i,1);
	}

	for(int i=0;i<s.size();i++) {
		v[s[i]].insert(i+1);
	}

	int a,b;
	char c;
	
	for(int i=0;i<m;i++) {
		scanf("%d %d %c", &a, &b, &c);
		a = bs(a);
		b = bs(b);
		prin(a);
		prin(b);
		separa();
		auto it1 = v[c].lower_bound(a);
		auto it2 = v[c].lower_bound(b);
		if(it2 != v[c].end() and *it2 == b) it2++;
//		printf("remove: ");
		for(auto it = it1; it != it2; it++) {
//			printf("%d ", *it);
			upd(*it,-1);
		}
		v[c].erase(it1,it2);
	}

	vector<pair<int,char> > res;
	for(int i=0;i<200;i++) {
		while(!v[i].empty()) {
			res.pb({*v[i].begin(), (char)i});
			v[i].erase(v[i].begin());
		}
	}

	sort(res.begin(), res.end());

	for(pair<int,char> i : res) {
		printf("%c",i.se);
	}
	cout << endl;
	

	

	return 0;

}



