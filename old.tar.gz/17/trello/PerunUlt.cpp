#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

map<ll, vector<ii> > ev;
ll vida[N], start[N], regen[N];
int n,m;
ll bounty, dano, inc;
bool vivo[N];

ll swp() {

	ll res = 0;
	ll cnt = 0;
	for(auto j = ev.begin();j != ev.end();j++) {
		ll t = j->fi;
		prin(t);
		res = max(res, (bounty + t * inc) * cnt);
		for(ii now : j->se) {
		//	printf("[%d][%d] ", now.fi, now.se);
			if(now.se == -1) continue;
			if(vivo[now.fi] == 0) {
				cnt++;
				vivo[now.fi] = 1;
			}
		}
		separa();		
		res = max(res, (bounty + t * inc) * cnt);
		for(ii now : j->se) {
			if(now.se == 1) continue;
			if(vivo[now.fi] == 1) {
				cnt--;
				vivo[now.fi] = 0;
			}
		}
		
		res = max(res, (bounty + t * inc) * cnt);
		prin(res);
		separa();
	}

	return res;
}


int main () {
	
	scanf("%d %d", &n, &m);
	scanf("%lld %lld %lld", &bounty, &inc, &dano);	

	vector<pair<ll,ll> > v[N];
	for(int i=0;i<n;i++) {
		scanf("%lld %lld %lld", &vida[i], &start[i], &regen[i]);
		v[i].pb({0, start[i]});	
	}

	
	ll a,b,c;
	for(int i=0;i<m;i++) {
		scanf("%lld %lld %lld", &a, &b, &c);
		b--;
		v[b].pb({a,c});
	}

	for(int i=0;i<n;i++) {
		sort(v[i].begin(), v[i].end());
	}

	int ultvida[N];
	for(int i=0;i<n;i++) {
		int who = i;
		for(int j=0;j<v[i].size();j++) {
			ll t = v[i][j].fi;
			ll h = v[i][j].se;
			ultvida[who] = h;
			if(h > dano) {
				ev[t-1].pb({who,-1});
			} else {
				if(vida[who] <= dano or regen[who] == 0) {
					ev[t].pb({who,1});
				} else {
					ev[t].pb({who,1});
					ll tt = t + (dano - h) / regen[who];
					if(j+1 == v[i].size() or v[i][j+1].fi > tt) {
						ev[tt].pb({who,-1});
					}
				}
			}
		}
	}

	for(int i=0;i<n;i++) {
		if(inc == 0) break;
		if((ultvida[i] <= dano and regen[i] == 0) or vida[i] <= dano) {
			cout << -1 << endl;
			return 0;
		}
	}

	cout << swp() << endl;

	return 0;

}



