#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 0;
#define debug(args...) if(debug) fprintf(stderr,args)
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define frrs(i,a,b) for(int i = (a); i>=(b);i--)
#define VAR(a,b) __typeof(b) a=b
#define frit(it,c) for(VAR(it,(c).begin());it!=(c).end();it++)
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 100100

int dp[110][2100];
int n;
struct asd {
	int v,d,t,id;
	bool operator< (const asd b) const {
		return d < b.d;
	}
} v[110];
bool pega[110][2100];

vector<int> res;

void print(int now, int time) {
	if(now >= n) return;
	if(time >= 2001) return;
	if(pega[now][time] == 1) {
		res.pb(v[now].id+1);
		print(now+1,time+v[now].t);
	} else print(now+1,time);
}

int solve(int now, int time) {
	if(now >= n) return 0;
	if(time >= 2001) return 0;
	prin(now);
	prin(time);
//	cout << endl;
	if(dp[now][time] != -1) return dp[now][time];
	dp[now][time] = solve(now+1,time);
	if(time + v[now].t < v[now].d) {
		if(dp[now][time] < v[now].v + solve(now+1,time+v[now].t)) {
			pega[now][time] = 1;
			dp[now][time] = v[now].v + solve(now+1,time+v[now].t);
		}
	}
	return dp[now][time];
}

int main () {

	cin >> n;

	fr(i,n) {
		cin >> v[i].t >> v[i].d >> v[i].v;
		v[i].id = i;
	}

	for(int i=0;i<=100;i++) {
		for(int j=0;j<=2001;j++) {
			dp[i][j] = -1;
		}
	}

	sort(v,v+n);

	cout << solve(0,0) << endl;
	
	print(0,0);

	cout << res.size() << endl;

	for(int x : res) {
		printf("%d ", x);
	}

	cout << endl;

	return 0;

}



