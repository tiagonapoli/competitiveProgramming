#include <bits/stdc++.h>
#define FILE_IN freopen("in", "r", stdin);
#define FILE_OUT freopen("out", "w", stdout);
bool debug = 1;
#define prin(a) if(debug) cout << #a << " = " << (a) << endl
#define rang(a,b) if(debug) printf("%d -> %d\n", (a), (b))
#define separa() if(debug) cout << endl
#define fr(i,n) for(int i = 0; i<(n); i++)
#define frr(i,a,b) for(int i = (a); i<=(b);i++) 
#define mk make_pair
#define pb push_back
#define fi first
#define se second
#define ii pair<int,int>
#define ll long long
#define MOD 1000000007
const double PI = acos(-1.0);
const double eps = 1e-9;
using namespace std;
#define N 300100

vector<int> adj[N];
vector<int> iadj[N]; 
int scc[N];
int v[N];

int add(int a, bool na, int b, bool nb) {
	if(na == 1) a ^= 1;
	if(nb == 1) b ^= 1;
	adj[a xor 1].pb(b);
	adj[b xor 1].pb(a);
//	printf("%d -> %d\n", a xor 1, b);
//	printf("%d -> %d\n\n", b xor 1, a);
	iadj[b].pb(a xor 1);
	iadj[a].pb(b xor 1);
}

stack<int> topo;
bool vis[N];
int cnt;
int dfs1(int now) {
	vis[now] = 1;
	for(int x : adj[now]) {
		if(vis[x] == 0) {
			dfs1(x);	
		}
	}
	topo.push(now);
}

int dfs2(int now) {
//	prin(now);
	vis[now] = 1;
	scc[now] = cnt;
	for(int x : iadj[now]) {
		if(vis[x] == 0) {
			dfs2(x);
		}
	}
}

int n,m;
bool sat() {
	for(int i=0;i<2*m;i++) {
		if(vis[i] == 0) dfs1(i);
	}

	for(int i=0;i<2*m;i++) {
		vis[i] = 0;
	}

	while(!topo.empty()) {
		int x = topo.top();
		//prin(x);
		topo.pop();
		if(vis[x] == 0) {
			dfs2(x);
			cnt++;
		}
	}
/*
	separa();
	for(int i=0;i<2*m;i++) {
		printf("%d -> %d\n", i, scc[i]);
	}
*/
	for(int i=0;i<2*m;i++) {
		if(scc[i] == scc[i xor 1]) return 0;
	}

	return 1;
}

int main () {
	
	scanf("%d %d", &n, &m);

	for(int i=1;i<=n;i++) {
		scanf("%d ", &v[i]);
	}

	int r;
	
	vector<int> asd[N];

	int a;
	for(int i=0;i<m;i++) {
		scanf("%d", &r);
		for(int j=0;j<r;j++) {
			scanf("%d", &a);
			asd[a].pb(i);
		}
	}

	int x,y;
	for(int i=1;i<=n;i++) {
		x = 2*asd[i][0];
		y = 2*asd[i][1];
		if(v[i] == 0) {
			add(x,1,y,1);
			add(x,0,y,0);
		} else {
			add(x,1,y,0);
			add(x,0,y,1);
		}
	}

	if(sat()) {
		printf("YES\n");
	} else printf("NO\n");
	

	return 0;

}



